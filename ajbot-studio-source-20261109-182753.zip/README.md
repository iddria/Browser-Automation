# Tauri + React + Typescript

This template should help get you started developing with Tauri, React and Typescript in Vite.

## Recommended IDE Setup

- [VS Code](https://code.visualstudio.com/) + [Tauri](https://marketplace.visualstudio.com/items?itemName=tauri-apps.tauri-vscode) + [rust-analyzer](https://marketplace.visualstudio.com/items?itemName=rust-lang.rust-analyzer)


## AJBOT STUDIO video-reference update

Read [IMPLEMENTATION_NOTES.md](IMPLEMENTATION_NOTES.md) for the screen-by-screen feature status, Windows run/build commands, preservation notes and validation limits. The original tools remain under **Original tools** in the new navigation.

## QA workspace

The QA workspace runs approved site checks through a local Node backend and a Chromium worker. The desktop app uses the same QA worker through Tauri.

From the project root, start the browser interface with Node 24 and npm.

```powershell
npm ci
npx playwright install chromium
npm run build
npm run qa:start
```

Open http://127.0.0.1:4173/?qa=1. The server listens on loopback for a single local operator. Keep one runtime per data directory. Its data is stored in `.ajbot-studio/qa-web` under your user home directory. The desktop app uses a separate `qa-workspace` folder beside its native profiles.

1. In **Sites**, register a staging origin or a local HTTP site. Publish the displayed token in `/.well-known/ajbot-qa.txt` and click **Verify site**. The runner also checks the token before a run.
2. In **Journeys**, discover routes, import same-site navigation paths from a saved workflow, or enter routes yourself. Choose Desktop or Mobile emulation, then save the checks.
3. Use **Run saved suite** and open **Runs** to follow progress, stop an active run, retry from its saved snapshot, or export its JSON report.

**Build with AI** drafts editable checks using a pretrained model. **Explain with AI** sends a compact summary of a completed run to the selected model and displays its interpretation beside the measured results. It sends check paths, types, outcomes and timings. Provider credentials and the verification token stay out of those prompts.

For local inference, start Ollama and select a model you already have. On desktop, use **Provider Keys** for cloud credentials. For the local web server, set the selected provider’s API key in the server process environment before starting it. Supported variables are `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `DEEPSEEK_API_KEY`, and `XAI_API_KEY`. The model is selected in the UI.

The QA runner uses fresh Chromium contexts and limits browser requests to GET and HEAD on the verified origin. Run reports reflect the browser checks. Mobile emulation changes Chromium’s viewport and touch settings. Physical device pairing and paid marketplace services are outside this local release.

Run `npm run test:qa` for the production frontend and backend integration checks after installing Chromium. The tests use a local website and controlled model replies. Windows native compilation and credential-backed model responses need verification on the target installation.

### Vision Lab

Open **QA workspace → Vision Lab** and select **Run YOLO demo** to classify a built-in 3×3 image puzzle. AJBOT reports each tile’s confidence and compares the selected tiles with the fixture’s answer. Inference runs on your machine through ONNX Runtime. The lab takes only its bundled image grid and needs no API key.

Install the optional dependencies with Python 3.10 or newer.

```powershell
python -m pip install -r browser-worker/vision-lab/requirements.txt
```

Download [recaptcha_classification_57k.onnx](https://huggingface.co/DannyLuna/recaptcha-classification-57k/blob/dd7500e/recaptcha_classification_57k.onnx) and save it to `browser-worker/vision-lab/recaptcha_classification_57k.onnx`. The uploaded solver ZIP references this model but does not include its weights. AJBOT verifies the SHA-256 supplied by the uploaded source before loading the model.

On Linux or macOS, use `python3` in the install command. To use a specific virtual environment, set `AJBOT_VISION_PYTHON` to its Python executable before starting Tauri or the local QA server. For example, on Windows PowerShell use `$env:AJBOT_VISION_PYTHON = (Resolve-Path .venv/Scripts/python.exe).Path`.

The sample grid uses crops from the uploaded solver’s bus image. Its license is included in `browser-worker/vision-lab/SOURCE-LICENSE.txt`.
