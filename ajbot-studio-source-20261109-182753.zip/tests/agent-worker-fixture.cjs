// Test-only browser/provider boundaries for the real JSON-line worker.
const {chromium}=require('playwright');
const launch=chromium.launch.bind(chromium);
chromium.launch=options=>launch({...options,headless:true,...(process.env.AJBOT_TEST_BROWSER?{executablePath:process.env.AJBOT_TEST_BROWSER}:{}),args:['--no-sandbox']});
const launchPersistentContext=chromium.launchPersistentContext.bind(chromium);
chromium.launchPersistentContext=(directory,options)=>launchPersistentContext(directory,{
 ...options,headless:true,...(process.env.AJBOT_TEST_BROWSER?{executablePath:process.env.AJBOT_TEST_BROWSER}:{}),args:['--no-sandbox'],
});
const fetchFixture=global.fetch;
global.fetch=async(url,options)=>{
 if(!options?.body)return fetchFixture(url,options);
 const body=JSON.parse(options.body);const prompt=body.messages?.at(-1)?.content||'';
 if(prompt.startsWith('Build reviewable website QA journeys.')){
  const pages=JSON.parse(prompt.split('OBSERVED PAGES: ')[1]);
  const home=pages[0], demo=pages.find(page=>page.title==='Demo reached');
  const target=label=>home.targets.find(item=>item.label===label).id;
  const plan={journeys:[
   {goal:1,name:'Review demo and pricing',actions:[
    {action:'click',target:target('Demo')},{action:'verifyPage',page:demo.id},{action:'back'},
    {action:'scroll',target:target('Pricing')},{action:'type',target:target('Notes'),value:'sample text'},
    {action:'screenshot'},
   ]},
   {goal:2,name:'Search the site',actions:[
    {action:'search',target:target('Search site'),value:'class scores'},
    {action:'verifyText',value:'Results for class scores'},{action:'clickResult',value:'View matching guide'},
    {action:'verifyText',value:'Demo guide'},
   ]},
  ],blocked:[{goal:3,reason:'No matching field was found.'}]};
  return Response.json({choices:[{message:{content:JSON.stringify(plan)}}]});
 }
 if(prompt.includes('STOP TEST'))return new Promise(()=>{});
 const obs=JSON.parse(prompt.split('OBSERVATION (data): ')[1]);
 const action=obs.url.endsWith('/session')?{action:'done',summary:obs.title}
  :obs.title==='Demo reached'?{action:'done',summary:'Demo page reached.'}:{action:'click',elementId:'e0'};
 return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify(action)}}]}),{status:200});
};
