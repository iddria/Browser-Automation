import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {cp,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {createServer} from 'node:http';
import {buildSwarmerJourneys} from '../src/studio/swarmerJourneys.ts';
import {validateCanvas} from '../src/studio/model.ts';
test('actual worker runs a live agent and saves and executes Swarmers plans',async()=>{
 let demoIsHtml = true;
 const searches=[];
 const server=createServer((req,res)=>{
  if(req.url==='/demo'&&!demoIsHtml){
   res.setHeader('content-type','application/json');
   return res.end('{"message":"The route changed"}');
  }
  res.setHeader('content-type','text/html');
  if(req.url==='/remember'){
   res.setHeader('set-cookie','ajbot_test_session=local-fixture-cookie; Path=/; Max-Age=600; HttpOnly');
   return res.end('<title>Saved</title>');
  }
  if(req.url==='/session')return res.end(req.headers.cookie?.includes('ajbot_test_session=local-fixture-cookie')
   ?'<title>Saved test session</title>' : '<title>Fresh test session</title>');
  if(req.url==='/device')return res.end('<meta name="viewport" content="width=device-width"><p id="probe"></p><script>document.querySelector("#probe").textContent=[innerWidth,navigator.maxTouchPoints,devicePixelRatio].join("|")</script>');
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/search'){
   searches.push(url.searchParams.get('q'));
   return res.end('<h1>Results for class scores</h1><a href="/demo">View matching guide</a>');
  }
  res.end(req.url==='/demo'
   ?'<title>Demo reached</title><p>Demo guide</p>'
   :`<title>Home</title><a href="/demo">Demo</a>
     <form action="/search"><label>Search site<input type="search" name="q"></label><button>Search</button></form>
     <div style="height: 2000px"></div><h2>Pricing</h2><label>Notes<textarea name="notes"></textarea></label>
     <input type="password" value="private-field-value">`);
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const dir=await mkdtemp(join(tmpdir(),'ajbot-agent-worker-'));
 const workerDir=join(dir,'worker');
 await cp(resolve('browser-worker'),workerDir,{recursive:true,filter:path=>path===resolve('browser-worker')||path.endsWith('.cjs')});
 const child=spawn(process.execPath,['--require',resolve('tests/agent-worker-fixture.cjs'),join(workerDir,'worker.cjs')],{env:{...process.env,NODE_PATH:resolve('node_modules'),AJBOT_PROFILES_DIR:join(dir,'profiles')},stdio:['pipe','pipe','pipe']});
 const pending=new Map();let next=1;const events=[];const lines=createInterface({input:child.stdout});let stopping;
 lines.on('line',line=>{const value=JSON.parse(line);if(value.event){events.push(value);if(value.data.runId==='agent-stop'&&value.data.status==='thinking')stopping=request({action:'controlAiAgent',workflowId:'agent-stop',agentOptions:{action:'stop'}});return;}if(pending.has(value.id)){pending.get(value.id)(value);pending.delete(value.id);}});
 const request=message=>new Promise((resolve,reject)=>{const id=next++;const timer=setTimeout(()=>{pending.delete(id);reject(Error('Agent worker timeout'));},10000);pending.set(id,v=>{clearTimeout(timer);resolve(v);});child.stdin.write(JSON.stringify({id,...message})+'\n');});
 const base={action:'runAiAgent',workflowId:'agent-done',task:'Open the demo page on my authorized test site.',url:`http://127.0.0.1:${server.address().port}`,provider:'openrouter',model:'test/model',apiKey:'in-memory-fixture-key',agentOptions:{maxSteps:4}};
 try{
  const done=await request(base);assert.equal(done.ok,true);assert.equal(done.data.status,'completed');assert.equal(done.data.executed,1);assert.ok(events.some(e=>e.event==='ai-agent-progress'&&e.data.status==='observing'));
  const stopped=await request({...base,workflowId:'agent-stop',task:'STOP TEST'});assert.equal(stopped.data.status,'stopped');assert.equal((await stopping).ok,true);
  assert.ok(!JSON.stringify(events).includes('in-memory-fixture-key'));
  const pages=[base.url+'/',base.url+'/demo'];
  const drafts=buildSwarmerJourneys(pages,2,4);
  const stored=await request({action:'saveWorkflow',workflowId:'test-swarm',workflowName:'Test swarm',steps:validateCanvas(drafts)});
  assert.equal(stored.ok,true,stored.message);
  assert.deepEqual(stored.workflow.steps.filter(s=>s.journeyStart).map(s=>s.journeyName),drafts.map(j=>j.name));
  assert.ok(stored.workflow.steps.filter(s=>s.action==='navigate').every(s=>s.verifyHtml));
  assert.equal((await request({action:'create',profileId:'swarmer-test',name:'Test browser',agentOptions:{deviceClass:'Android'}})).profile.deviceClass,'Android');
  assert.equal((await request({action:'updateProfile',profileId:'swarmer-test',name:'Test Android browser'})).profile.deviceClass,'Android');
  assert.equal((await request({action:'list'})).profiles[0].deviceClass,'Android');
  assert.equal((await request({action:'launch',profileId:'swarmer-test'})).ok,true);
  const device=await request({action:'saveWorkflow',workflowId:'device-probe',workflowName:'Device probe',steps:[
   {action:'navigate',url:base.url+'/device'},{action:'extractText',selector:'#probe',repeatCount:2},
  ]});
  assert.equal(device.ok,true,device.message);
  const probe=await request({action:'runWorkflow',profileId:'swarmer-test',workflowId:'device-probe'});
  assert.match(probe.results[1].detail,/412\|1\|2\.625/);
  assert.equal(probe.results.length,3);
  assert.equal(probe.results[2].detail,probe.results[1].detail);
  await request({action:'saveWorkflow',workflowId:'oversized-run',workflowName:'Oversized',steps:
   Array.from({length:11},()=>({action:'wait',durationMs:0,repeatCount:10})),
  });
  const oversized=await request({action:'runWorkflow',profileId:'swarmer-test',workflowId:'oversized-run'});
  assert.equal(oversized.ok,false);assert.match(oversized.error,/at most 100 actions/);
  const run={action:'runWorkflow',profileId:'swarmer-test',workflowId:'test-swarm'};
  const complete=await request(run);
  assert.equal(complete.status,'completed',JSON.stringify(complete));
  assert.deepEqual(complete.results.map(s=>s.url),[pages[0],pages[1],pages[1],pages[1],pages[1],pages[0],pages[0],pages[0]]);
  demoIsHtml=false;
  const failure=await request(run);
  assert.equal(failure.status,'failed',JSON.stringify(failure));
  assert.equal(failure.results.length,2);
  assert.match(failure.results[1].detail,/Expected an HTML page.*application\/json/);
  demoIsHtml=true;
  const guided=await request({
   action:'planWorkflow',url:pages[0],provider:'openrouter',model:'test/model',apiKey:'in-memory-fixture-key',
   task:'Click Demo, verify the demo page, go back, scroll to Pricing, type sample text into Notes, and take a screenshot.\nSearch class scores, look for results, then click View matching guide.\nType into the unavailable field.',
  });
  assert.equal(guided.ok,true,JSON.stringify(guided));
  assert.equal(searches.length,0,'planning must not execute searches');
  assert.equal(guided.plan.blocked[0].goal,3);
  assert.equal(guided.plan.journeys.length,2);
  const guidedSteps=validateCanvas(guided.plan.journeys);
  assert.deepEqual(guidedSteps.map(step=>step.action),[
   'navigate','click','waitforurl','back','scroll','fill','screenshot',
   'navigate','fill','press','waitfortext','click','waitfortext',
  ]);
  assert.ok(guidedSteps.every(step=>step.scopeOrigin===base.url));
  const savedGuided=await request({action:'saveWorkflow',workflowId:'guided-swarm',workflowName:'Guided swarm',steps:guidedSteps});
  assert.equal(savedGuided.ok,true,JSON.stringify(savedGuided));
  const scoped=await request({...run,workflowId:'guided-swarm'});
  assert.equal(scoped.status,'completed',JSON.stringify(scoped));
  assert.match(scoped.results[4].detail,/Scrolled to “Pricing”/);
  assert.deepEqual(searches,['class scores']);
  assert.equal(scoped.results.at(-1).url,pages[1]);
  await request({action:'saveWorkflow',workflowId:'remember-fixture',workflowName:'Remember local session',steps:[
   {action:'navigate',url:base.url+'/remember'},
  ]});
  assert.equal((await request({...run,workflowId:'remember-fixture'})).ok,true);
  const sessionTask={...base,url:base.url+'/session',task:'Report the session page title on my local fixture.'};
  const busy=await request({...sessionTask,workflowId:'profile-busy',profileId:'swarmer-test'});
  assert.equal(busy.data.status,'failed');
  assert.match(busy.data.summary,/already running/);
  assert.equal((await request({action:'close',profileId:'swarmer-test'})).ok,true);
  const reused=await request({...sessionTask,workflowId:'profile-reuse',profileId:'swarmer-test'});
  assert.equal(reused.data.status,'completed',JSON.stringify(reused));
  assert.equal(reused.data.summary,'Saved test session');
  assert.equal((await request({...sessionTask,workflowId:'fresh-session'})).data.summary,'Fresh test session');
  assert.equal((await request({action:'launch',profileId:'swarmer-test'})).ok,true,'the agent released the saved profile lock');
  assert.equal((await request({action:'close',profileId:'swarmer-test'})).ok,true);
 }finally{child.stdin.end(JSON.stringify({id:999,action:'shutdown'})+'\n');child.kill();lines.close();await rm(dir,{recursive:true,force:true});await new Promise(r=>server.close(r));}
});
