import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createRequire } from 'node:module';
const { callHostedPlanner, listModels }=createRequire(import.meta.url)('../browser-worker/planner-providers.cjs');
const key='sk-test-memory-only';
const reply={name:'Inspect',steps:[{action:'screenshot'}]};
const response=data=>({ok:true,json:async()=>data});
for(const provider of ['anthropic','gemini','openrouter','deepseek','grok']) test(`${provider} planner uses its documented request and response shape`,async()=>{
  let request;
  const fetchMock=async(url,options)=>{request={url,options,body:JSON.parse(options.body)};return response(provider==='anthropic'?{content:[{type:'text',text:JSON.stringify(reply)}]}:provider==='gemini'?{candidates:[{content:{parts:[{text:JSON.stringify(reply)}]}}]}:{choices:[{message:{content:JSON.stringify(reply)}}]});};
  const text=await callHostedPlanner(provider,'sample-model',key,'Create an inspection workflow',fetchMock);
  assert.deepEqual(JSON.parse(text),reply);assert.equal(request.options.redirect,'error');assert.ok(!request.url.includes(key));
  if(provider==='anthropic'){assert.equal(request.options.headers['x-api-key'],key);assert.equal(request.body.max_tokens,4096);}
  else if(provider==='gemini'){assert.equal(request.options.headers['x-goog-api-key'],key);assert.match(request.url,/:generateContent$/);}
  else {assert.equal(request.options.headers.Authorization,`Bearer ${key}`);assert.equal(request.body.model,'sample-model');}
});
test('model catalogues normalize paginated Gemini and OpenRouter text models',async()=>{
  const urls=[];
  const gemini=await listModels('gemini',key,async url=>{urls.push(url);return response(url.includes('pageToken')?{models:[{name:'models/gemini-two',supportedGenerationMethods:['generateContent']}]}:{models:[{name:'models/gemini-one',supportedGenerationMethods:['generateContent']},{name:'models/embedding-only',supportedGenerationMethods:['embedContent']}],nextPageToken:'next-page'});});
  assert.deepEqual(gemini.map(m=>m.id),['gemini-one','gemini-two']);assert.equal(urls.length,2);
  const router=await listModels('openrouter','',async()=>response({data:[{id:'text/model',architecture:{output_modalities:['text']}},{id:'image/model',architecture:{output_modalities:['image']}}]}));
  assert.deepEqual(router.map(m=>m.id),['text/model']);
});
test('provider errors redact keys, reject redirects and empty model output',async()=>{
  await assert.rejects(()=>callHostedPlanner('grok','model',key,'task',async()=>({ok:false,status:401,json:async()=>({error:{message:`Rejected ${key}`}})})),e=>!e.message.includes(key)&&e.message.includes('[redacted]'));
  await assert.rejects(()=>callHostedPlanner('gemini','../../other',key,'task',async()=>{throw new Error('must not request');}),/model ID/);
  await assert.rejects(()=>callHostedPlanner('openrouter','model',key,'task',async()=>response({choices:[]})),/no workflow text/);
  await assert.rejects(()=>callHostedPlanner('deepseek','model','','task',async()=>{throw new Error('must not request');}),/API key/);
});
