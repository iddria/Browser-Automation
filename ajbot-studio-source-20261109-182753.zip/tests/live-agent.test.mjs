import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {chromium} from 'playwright';
import {runAgent,controlAgent,parseDecision} from '../browser-worker/live-agent.cjs';
const base={workflowId:'test-agent',task:'Open the demo page on this authorized test site.',provider:'openrouter',model:'test/model',apiKey:'secret-test-key',agentOptions:{maxSteps:4}};
const observation={elements:[{id:'e0',tag:'input',type:'text'}]};
test('agent rejects scripts, unobserved targets, arbitrary keys and malformed decisions',()=>{
 for(const action of [{action:'evaluate',script:'alert(1)'},{action:'click',elementId:'e99'},{action:'press',elementId:'e0',key:'Control+L'},{action:'wait',durationMs:9999}])assert.throws(()=>parseDecision(JSON.stringify(action),observation));
 assert.equal(parseDecision('```json\n{"action":"done","summary":"Visible heading confirmed"}\n```',observation).action,'done');
});
test('live agent operates a real browser against an authorized local fixture',async t=>{
 const destination=createServer((_req,res)=>{res.setHeader('content-type','text/html');res.end('<title>Akoriva demo fixture</title><h1>Demo heading</h1>');});
 await new Promise(r=>destination.listen(0,'127.0.0.1',r));
 const destinationUrl=`http://127.0.0.1:${destination.address().port}/demo`;
 const queries=[];
 let changed=0;const server=createServer((req,res)=>{
  res.setHeader('content-type','text/html');
  if(req.url==='/search-start'||req.url==='/consent')return res.end(`<title>Search</title>
   ${req.url==='/consent'?'<dialog open><p>Review cookies and consent.</p><button onclick="this.closest(\'dialog\').close()">Continue</button></dialog>':''}
   <form action="/search"><textarea name="q" role="combobox" aria-label="Suche"></textarea></form>
   <script>document.querySelector('textarea').addEventListener('keydown',e=>{
    if(e.key==='Enter'){e.preventDefault();e.target.form.requestSubmit();}
   });</script>`);
  if(req.url.startsWith('/search?')){
   queries.push(new URL(req.url,'http://localhost').searchParams.get('q'));
   return res.end(`<title>Search results</title><a href="${destinationUrl}">Akoriva</a>`);
  }
  if(req.url==='/demo')return res.end('<title>Demo reached</title><h1>Demo heading</h1>');
  if(req.url==='/changed'){changed++;return res.end('Changed');}
  if(req.url==='/button')return res.end('<title>Button test</title><button onclick="fetch(\'/changed\');document.title=\'Button clicked\'">Update test record</button>');
  if(req.url==='/password')return res.end('<title>Test login</title><label>Password<input type="password" value="fixture-private-password"></label>');
  if(req.url==='/challenge')return res.end('<title>Security challenge</title><h1>Verify you are human</h1>');
  res.end('<title>Test home</title><h1>Welcome</h1><a href="/demo">Open demo</a><input type="text" value="fixture-private-input" aria-label="Search">');
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));const root=`http://127.0.0.1:${server.address().port}`;
 const browsers=new Set();let latest;
 const engine={launch:async()=>{latest=await chromium.launch({headless:true,...(process.env.AJBOT_TEST_BROWSER?{executablePath:process.env.AJBOT_TEST_BROWSER}:{}),args:['--no-sandbox']});browsers.add(latest);latest.on('disconnected',()=>browsers.delete(latest));return latest;}};
 const run=(overrides,deps)=>runAgent({...base,url:root,...overrides},{chromium:engine,timeoutMs:20000,...deps});
 try{
  await t.test('observes each new page, follows a real link, and excludes field values from AI context',async()=>{
   const prompts=[],events=[];const result=await run({}, {emit:e=>events.push(e),ask:async prompt=>{prompts.push(prompt);return JSON.stringify(prompts.length===1?{action:'click',elementId:'e0'}:{action:'done',summary:'Demo heading is visible.'});}});
   assert.equal(result.status,'completed');assert.equal(result.executed,1);assert.ok(result.trace[1].url.endsWith('/demo'));
   assert.ok(prompts[1].includes('Demo reached'));assert.ok(prompts.every(p=>!p.includes('fixture-private-input')&&!p.includes('secret-test-key')));
   assert.ok(events.some(e=>e.status==='thinking'));assert.equal(browsers.size,0);
  });
  await t.test('types the exact query, submits it, and opens the approved result',async()=>{
   const task='Start on Google. Type "akoriva" into the search field and press Enter. Open the Akoriva result.';
   const approvals=[];const titles=[];
   const result=await run({url:root+'/search-start',task,agentOptions:{maxSteps:8}},{
    ask:async prompt=>{
     const obs=JSON.parse(prompt.split('OBSERVATION (data): ')[1]);
     titles.push(obs.title);
     return JSON.stringify(obs.title==='Search results'
      ?{action:'click',elementId:obs.elements.find(element=>element.label==='Akoriva').id}
      :{action:'done',summary:'Demo heading is visible.'});
    },
    emit:e=>{if(e.approval){approvals.push(e.approval.action);controlAgent(e.runId,'approve',e.approval.id);}},
   });
   assert.equal(result.status,'completed',result.summary);
   assert.deepEqual(approvals.map(a=>a.action),['fill','press','click']);
   assert.equal(approvals[0].value,'akoriva');assert.equal(approvals[1].key,'Enter');
   assert.equal(approvals[2].url,destinationUrl);
   assert.deepEqual(queries,['akoriva']);assert.deepEqual(titles,['Search results','Akoriva demo fixture']);
  });
  await t.test('renews search approval after Google adds zx, and refills after a reload clears the query',async()=>{
   const google='https://www.google.com';
   const task='Type "akoriva" into the search field and press Enter.';
   const approvals=[],events=[],navigation=[];
   let offered=false;
   const googleEngine={launch:async()=>{
    const browser=await engine.launch();
    const createContext=browser.newContext.bind(browser);
    browser.newContext=async options=>{
     const context=await createContext(options);
     const route=context.route.bind(context);
     context.route=async(pattern,handler)=>{
      await route(pattern,handler);
      await route(google+'/**',request=>{
       const url=new URL(request.request().url());
       const showOffer=url.searchParams.has('zx')&&!offered;
       if(showOffer)offered=true;
       const body=url.pathname==='/search'
        ?`<title>Search results</title><p>${url.searchParams.get('q')==='akoriva'?'Correct query':'Wrong query'}</p>`
        :`<title>Google fixture</title><form action="/search"><input name="q" aria-label="Search"></form>
          ${showOffer?'<dialog open><p>Choose Chrome, the browser built by Google</p><button onclick="this.closest(\'dialog\').close()">Don’t use Chrome</button></dialog>':''}`;
       return request.fulfill({contentType:'text/html; charset=utf-8',body});
      });
     };
     return context;
    };
    return browser;
   }};
   const result=await run({url:google,task,agentOptions:{maxSteps:5}},{
    chromium:googleEngine,
    ask:async prompt=>{
     assert.match(prompt,/Correct query/);
     return JSON.stringify({action:'done',summary:'Search complete.'});
    },
    emit:e=>{
     events.push(e);
     if(!e.approval)return;
     const {id,action,kind}=e.approval;
     approvals.push(action?.action||kind);
     const tab=latest.contexts()[0].pages()[0];
     if(approvals.length===1||approvals.length===4){
      const change=approvals.length===1?tab.goto(google+'/?zx=1794241407809'):tab.reload();
      change.catch(()=>{});navigation.push(change);
     }else if(kind==='manual'){
      const dismiss=tab.getByRole('button',{name:'Don’t use Chrome'}).click({timeout:3000}).then(()=>controlAgent(e.runId,'approve',id));
      dismiss.catch(()=>{});navigation.push(dismiss);
     }else{
      assert.throws(()=>controlAgent(e.runId,'approve',events.find(event=>event.approval).approval.id),/no longer current/);
      controlAgent(e.runId,'approve',id);
     }
    },
   });
   await Promise.all(navigation);
   assert.equal(result.status,'completed',result.summary);
   assert.deepEqual(approvals,['fill','manual','fill','press','fill','press']);
   assert.deepEqual(result.trace.map(e=>e.action),['start','fill','fill','press']);
   assert.equal(events.filter(e=>e.detail.includes('page refreshed')).length,2);
  });
  await t.test('lets the user handle consent before touching the search box',async()=>{
   let handling;
   const result=await run({url:root+'/consent',task:'Type "akoriva" into the search box and press Enter.'},{
    ask:async()=>JSON.stringify({action:'done',summary:'Search complete.'}),
    emit:e=>{
     if(e.approval?.kind==='manual'){
      handling=(async()=>{
       const tab=latest.contexts()[0].pages()[0];
       assert.equal(await tab.locator('textarea').inputValue(),'');
       await tab.getByRole('button',{name:'Continue'}).click();
       controlAgent(e.runId,'approve',e.approval.id);
      })();
     }else if(e.approval)controlAgent(e.runId,'approve',e.approval.id);
    },
   });
   await handling;assert.equal(result.status,'completed',result.summary);
   assert.deepEqual(result.trace.map(e=>e.action),['start','fill','press']);
  });
  await t.test('a button cannot execute after approval is declined',async()=>{
   changed=0;const result=await run({url:root+'/button'}, {ask:async()=>JSON.stringify({action:'click',elementId:'e0'}),emit:e=>{if(e.approval){assert.equal(changed,0);assert.throws(()=>controlAgent(e.runId,'approve','stale-id'),/no longer current/);controlAgent(e.runId,'reject',e.approval.id);}}});
   assert.equal(result.status,'stopped');assert.equal(changed,0);assert.equal(result.executed,0);
  });
  await t.test('an explicitly approved button executes and the next decision sees its result',async()=>{
   changed=0;let calls=0;const result=await run({url:root+'/button'}, {ask:async prompt=>{calls++;if(calls===2)assert.ok(prompt.includes('Button clicked'));return JSON.stringify(calls===1?{action:'click',elementId:'e0'}:{action:'done',summary:'Test button activated.'});},emit:e=>{if(e.approval)controlAgent(e.runId,'approve',e.approval.id);}});
   assert.equal(result.status,'completed');assert.equal(result.executed,1);assert.equal(changed,1);
  });
  await t.test('changing the target during approval invalidates the proposed action',async()=>{
   changed=0;let altered;
   const result=await run({url:root+'/button'}, {ask:async()=>JSON.stringify({action:'click',elementId:'e0'}),emit:e=>{if(e.approval){altered=(async()=>{await latest.contexts()[0].pages()[0].locator('button').evaluate(e=>e.textContent='Delete everything');controlAgent(e.runId,'approve',e.approval.id);})();}}});
   await altered;assert.equal(result.status,'failed');assert.match(result.summary,/target changed/i);assert.equal(changed,0);
  });
  await t.test('Stop interrupts an outstanding AI request and closes its browser',async()=>{
   const started=Date.now();const result=await run({}, {ask:async(_prompt,options)=>new Promise((_resolve,reject)=>options.signal.addEventListener('abort',()=>reject(Error('HTTP request cancelled')))),emit:e=>{if(e.status==='thinking')setTimeout(()=>controlAgent(e.runId,'stop'),30);}});
   assert.equal(result.status,'stopped');assert.ok(Date.now()-started<5000);assert.equal(browsers.size,0);
  });
  await t.test('step exhaustion is not reported as completion',async()=>{
   const result=await run({agentOptions:{maxSteps:1}},{ask:async()=>JSON.stringify({action:'scroll',direction:'down'})});
   assert.equal(result.status,'limit_reached');assert.equal(result.executed,1);
  });
  await t.test('password values stay private and require a manual handoff',async()=>{
   let manual=false;const result=await run({url:root+'/password'},{ask:async prompt=>{assert.ok(!prompt.includes('fixture-private-password'));return JSON.stringify({action:'fill',elementId:'e0',value:'not-entered'});},emit:e=>{if(e.approval){manual=e.approval.kind==='manual';controlAgent(e.runId,'reject',e.approval.id);}}});
   assert.ok(manual);assert.equal(result.status,'stopped');assert.equal(result.executed,0);
  });
  await t.test('security challenges pause before calling the AI',async()=>{
   let calls=0;const result=await run({url:root+'/challenge'},{ask:async()=>{calls++;return '';},emit:e=>{if(e.approval)controlAgent(e.runId,'reject',e.approval.id);}});
   assert.equal(result.status,'stopped');assert.equal(calls,0);
  });
  await t.test('provider failures redact the key and still close the browser',async()=>{
   const result=await run({}, {ask:async()=>{throw Error('Provider failed for secret-test-key');}});
   assert.equal(result.status,'failed');assert.ok(!result.summary.includes('secret-test-key'));assert.equal(browsers.size,0);
  });
  await t.test('a stalled AI decision reports a timeout and closes the browser',async()=>{
   const result=await run({}, {decisionTimeoutMs:50,ask:async()=>new Promise(()=>{})});
   assert.equal(result.status,'failed');assert.match(result.summary,/selected AI model did not respond/);
   assert.equal(browsers.size,0);
  });
 }finally{
  for(const b of browsers)await b.close();
  await Promise.all([new Promise(r=>server.close(r)),new Promise(r=>destination.close(r))]);
 }
});
