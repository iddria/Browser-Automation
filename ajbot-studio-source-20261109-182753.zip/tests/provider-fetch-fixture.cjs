// Test-only network boundary. The worker protocol test never reaches a provider.
global.fetch = async (url, options) => {
  if (options.method === 'GET') return new Response(JSON.stringify({data:[{id:'test/model',name:'Fixture model',architecture:{output_modalities:['text']}}]}),{status:200});
  return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify({name:'Inspection draft',steps:[{action:'navigate',url:'https://example.com'}]})}}]}),{status:200});
};
