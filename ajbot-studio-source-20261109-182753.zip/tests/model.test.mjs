import assert from 'node:assert/strict';
import { test } from 'node:test';
import { validUrl, validateCanvas, learningTemplate, normalizeStepActions } from '../src/studio/model.ts';

test('normalizes HTTP websites and blocks executable or credential URLs', () => {
  assert.equal(validUrl('example.com'), 'https://example.com/');
  assert.equal(validUrl('http://localhost:8080/demo'), 'http://localhost:8080/demo');
  for (const u of ['javascript:alert(1)','file:///etc/passwd','https://user:password@example.com','data:text/html,test','']) assert.throws(() => validUrl(u));
});
test('journeys compile in visible order and preserve step options', () => {
  const steps = validateCanvas([
    { name:'One', startUrl:'example.com', steps:[{action:'fill',selector:'#name',value:'Classroom'},{action:'screenshot',fullPage:true}] },
    { name:'Two', startUrl:'https://example.org', steps:[{action:'wait',durationMs:500}] },
  ]);
  assert.deepEqual(steps.map(s=>s.action),['navigate','fill','screenshot','navigate','wait']);
  assert.equal(steps[0].url,'https://example.com/'); assert.equal(steps[2].fullPage,true);
});
test('invalid selectors, waits and oversized journeys cannot be saved', () => {
  const wrap = steps => [{name:'Test',startUrl:'example.com',steps}];
  assert.throws(()=>validateCanvas(wrap([{action:'fill',value:'x'}])),/selector/);
  assert.throws(()=>validateCanvas(wrap([{action:'wait',durationMs:30001}])),/Wait/);
  assert.throws(()=>validateCanvas(wrap(Array.from({length:50},()=>({action:'screenshot'})))),/50 steps/);
});
test('learning templates inspect pages without manufacturing engagement', () => {
  for (const platform of ['Google','YouTube']) {
    const flow=learningTemplate('Student',platform);
    assert.deepEqual(flow.steps.map(s=>s.action),['navigate','wait','screenshot']);
  }
});

test('native lowercase actions round-trip into portable workflow definitions', () => {
  assert.deepEqual(normalizeStepActions([{action:'newtab',url:'https://example.com'},{action:'iftext',thenSteps:[{action:'clickrole'}]}]), [{action:'newTab',url:'https://example.com'},{action:'ifText',thenSteps:[{action:'clickRole'}]}]);
});

import { defaultCapacity, normalizeCapacity, parseCapacity, profileBatchError, sessionCapacityReached } from '../src/studio/capacity.ts';

test('capacity defaults remove the former three-session and fifty-profile gates', () => {
  assert.deepEqual(defaultCapacity, {concurrentSessions:0,profilesPerBatch:0});
  assert.equal(sessionCapacityReached(10,0),false);
  assert.equal(profileBatchError({Windows:1000,iPhone:25},0),'');
});
test('owner-selected capacity applies at the boundary', () => {
  assert.equal(sessionCapacityReached(1,2),false);
  assert.equal(sessionCapacityReached(2,2),true);
  assert.equal(profileBatchError({Windows:52,iPhone:8},60),'');
  assert.match(profileBatchError({Windows:52,iPhone:9},60),/60 profiles/);
});
test('count parsing rejects invalid values without inventing a paid restriction', () => {
  for (const value of ['', '-1','2.5','Infinity','NaN','9007199254740992']) assert.throws(()=>parseCapacity(value,'Capacity'));
  assert.equal(parseCapacity('0','Capacity'),0); assert.equal(parseCapacity('1000','Capacity'),1000);
  assert.match(profileBatchError({Windows:-1},0),/whole numbers/);
  assert.match(profileBatchError({Windows:.5},0),/whole numbers/);
  assert.match(profileBatchError({Windows:Number.MAX_SAFE_INTEGER,Mac:1},0),/too large/);
});
test('saved capacity recovers defaults for missing or corrupted fields', () => {
  assert.deepEqual(normalizeCapacity(null),defaultCapacity);
  assert.deepEqual(normalizeCapacity({concurrentSessions:4,profilesPerBatch:-1}),{concurrentSessions:4,profilesPerBatch:0});
});

import { activityCounts } from '../src/studio/activity.ts';
import { profileDevice, sessionWaves, validateDeviceRanges } from '../src/studio/sessionDevices.ts';
import { plannerProviders, modelChoices } from '../src/studio/providerCatalog.ts';
test('activity cards show real saved totals and handle empty workspaces', () => {
  const now=Date.now();const flows=[{name:'Swarmer · example.com',createdAt:now},{name:'Student · Google',createdAt:now-40*86400000},{name:'Custom',createdAt:now}];
  assert.deepEqual(activityCounts(flows,[{createdAt:now}],[{}],'All',now).map(x=>x.count),[1,1,1,3,1]);
  assert.deepEqual(activityCounts(flows,[{createdAt:now}],[{}],'7d',now).map(x=>x.count),[1,0,1,2,0]);
  assert.deepEqual(activityCounts([],[],[],'All').map(x=>x.count),[0,0,0,0,0]);
});
test('device ranges exclude categories and bound per-device parallelism', () => {
  const profiles=['w1','w2','w3','i1','a1'].map(id=>({id}));const pod={profiles:profiles.map(p=>p.id),devices:{w1:'Windows',w2:'Windows',w3:'Windows',i1:'iPhone',a1:'Android'}};
  assert.equal(sessionWaves({},pod,profiles).length,5);
  const waves=sessionWaves({deviceRanges:{Windows:{min:1,max:2},iPhone:{min:0,max:0},Android:{min:0,max:1}}},pod,profiles);
  assert.deepEqual(waves.map(w=>w.map(p=>p.id)),[['a1','w1','w2'],['w3']]);
  assert.throws(()=>sessionWaves({deviceRanges:{Windows:{min:4,max:4}}},pod,profiles),/available: 3/);
  assert.throws(()=>validateDeviceRanges({iPhone:{min:2,max:1}}),/minimum cannot/);
  assert.throws(()=>validateDeviceRanges({Mac:{min:0,max:1.5}}),/whole numbers/);
  assert.equal(profileDevice({id:'i1'},[pod]),'iPhone');
});
test('all cloud providers and local Ollama offer model selection without duplicate IDs', () => {
  assert.equal(plannerProviders.length,7);
  assert.deepEqual(plannerProviders.slice(0,6).map(p=>p.presets.length),[6,8,7,22,6,3]);
  const list=modelChoices('openrouter',[{id:'new/model',name:'New model'},{id:'openai/gpt-4o-mini',name:'Mini'}]);
  assert.equal(list[0].id,'new/model');assert.equal(list.filter(m=>m.id==='openai/gpt-4o-mini').length,1);
});

test('Activity counts installed warmer templates across all six platform filters',()=>{
 const flows=['Google','YouTube','Facebook','Instagram','TikTok','Amazon'].map(p=>({name:`Student · ${p}`}));
 assert.equal(activityCounts(flows,[],[],'All').find(c=>c.label==='Warmers').count,6);
});
