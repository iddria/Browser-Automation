import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createServer } from 'node:http';
import { test } from 'node:test';
import { chromium } from 'playwright';
import { createQaWorkspace, parseModelChecks } from '../browser-worker/qa-workspace.cjs';
import { scoreFixture } from '../browser-worker/vision-lab.cjs';
import { startQaServer } from '../server/qa-server.cjs';

const launchOptions = process.env.AJBOT_TEST_BROWSER ? { executablePath: process.env.AJBOT_TEST_BROWSER } : {};

function fixture(handler) {
  const server = createServer(handler);
  return new Promise(resolve => {
    server.listen(0, '127.0.0.1', () => resolve({
      origin: 'http://127.0.0.1:' + server.address().port,
      close: () => {
        server.closeAllConnections();
        return new Promise(done => server.close(done));
      },
    }));
  });
}

async function until(predicate) {
  for (let attempt = 0; attempt < 150; attempt++) {
    const value = await predicate();
    if (value) return value;
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('The expected job state did not arrive.');
}

test('a model response cannot expand the route catalogue or add browser actions', () => {
  const origin = 'https://owned.example';
  assert.deepEqual(parseModelChecks('{"checks":[{"path":"/docs","type":"heading"}]}', origin, ['/docs']),
    [{ path: '/docs', type: 'heading', expected: '' }]);
  for (const item of [
    { path: '/admin', type: 'page' },
    { path: '//unowned.example', type: 'page' },
    { path: '/', type: 'click' },
    { path: '/?token=secret', type: 'page' },
    { path: '/', type: 'title', expected: '' },
  ]) assert.throws(() => parseModelChecks(JSON.stringify({ checks: [item] }), origin, ['/']));
});

test('Vision Lab reports matches and mismatches and rejects invalid scores', () => {
  const matching = [0.01, 0.94, 0.04, 0.1, 0.02, 0.1, 0.5, 0.03, 0.05];
  assert.deepEqual(scoreFixture(matching).selected, [2, 7]);
  assert.equal(scoreFixture(matching).passed, true);
  assert.equal(scoreFixture([0.8, ...matching.slice(1)]).passed, false);
  assert.equal(scoreFixture(matching.map((score, index) => index === 6 ? 0.4 : score)).passed, false);
  assert.throws(() => scoreFixture([0.9]), /invalid tile scores/);
  assert.throws(() => scoreFixture([NaN, ...matching.slice(1)]), /invalid tile scores/);
});

test('a local backend verifies ownership, uses the model draft, executes checks, and records actual results', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'ajbot-qa-'));
  let token = 'wrong';
  let outsideRequests = 0;
  let modelCalls = 0;
  const outside = await fixture((_request, response) => { outsideRequests++; response.end('Outside scope'); });
  const site = await fixture((request, response) => {
    if (request.url === '/.well-known/ajbot-qa.txt') return response.end(token);
    if (request.url === '/redirect') {
      response.writeHead(302, { location: outside.origin });
      return response.end();
    }
    if (request.url === '/slow') return;
    if (request.url === '/docs') {
      response.setHeader('Content-Type', 'text/html');
      return response.end('<title>Docs</title><h1>Documentation</h1><img src="' + outside.origin + '/tracking">');
    }
    response.setHeader('Content-Type', 'text/html');
    response.end('<title>Home</title><h1>Welcome</h1><a href="/docs">Docs</a>');
  });
  const runtime = startQaServer({
    directory, port: 0, launchOptions,
    ask: async (prompt, options) => {
      modelCalls++;
      assert.ok(prompt.includes('"/docs"'));
      assert.equal(options.provider, 'ollama');
      if (prompt.startsWith('Explain')) {
        assert.ok(prompt.includes('"passed":true'));
        assert.ok(!prompt.includes(token));
        return '{"summary":"Both documentation checks passed."}';
      }
      return '{"checks":[{"path":"/docs","type":"heading"},{"path":"/docs","type":"title","expected":"Docs"}]}';
    },
  });
  let reopened;
  try {
    const local = await runtime.listen();
    const headers = { 'Content-Type': 'application/json', 'X-AJBOT-QA': '1', Origin: local };
    async function command(operation, input = {}, origin = local) {
      const response = await fetch(origin + '/api/qa', {
        method: 'POST', headers: { ...headers, Origin: origin }, body: JSON.stringify({ operation, input }),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error);
      return payload.data;
    }
    const crossSite = await fetch(local + '/api/qa', {
      method: 'POST', headers: { ...headers, Origin: outside.origin },
      body: JSON.stringify({ operation: 'status', input: {} }),
    });
    assert.equal(crossSite.status, 403);
    await assert.rejects(command('runVisionLab', { url: site.origin }), /built-in sample grid/);
    await assert.rejects(command('addSite', { name: 'Control plane', origin: local }), /separate application/);
    const entry = await command('addSite', { name: 'Staging', origin: site.origin });
    await assert.rejects(command('discover', { siteId: entry.id }), /Verify control/);
    await assert.rejects(command('verifySite', { siteId: entry.id }), /does not match/);
    token = entry.token;
    await command('verifySite', { siteId: entry.id });
    const paths = await command('discover', { siteId: entry.id });
    assert.ok(paths.includes('/docs'));
    const draft = await command('draft', { siteId: entry.id, goal: 'Find a heading and title Docs', paths, provider: 'ollama', model: 'fixture-model' });
    assert.equal(modelCalls, 1);
    assert.equal((await command('status')).suites.length, 0, 'a model draft must not save or run itself');
    const suite = await command('saveSuite', { siteId: entry.id, name: 'Documentation', viewport: 'mobile', checks: draft.checks });
    await assert.rejects(command('saveSuite', { ...suite, revision: 0 }), /changed/);
    const { id } = await command('runSuite', { suiteId: suite.id });
    const completed = await until(async () => (await command('status')).jobs.find(job => job.id === id && ['passed', 'failed'].includes(job.status)));
    assert.equal(completed.status, 'passed', completed.error || JSON.stringify(completed.results));
    assert.equal(completed.viewport, 'mobile');
    assert.equal(completed.results.length, 2);
    const analysis = await command('explainRun', { jobId: id, provider: 'ollama', model: 'fixture-model' });
    assert.equal(analysis.summary, 'Both documentation checks passed.');
    assert.equal(modelCalls, 2);
    assert.equal(outsideRequests, 0);

    const blocked = await command('saveSuite', { siteId: entry.id, name: 'Redirect', checks: [{ path: '/redirect', type: 'page' }] });
    const blockedJob = await command('runSuite', { suiteId: blocked.id });
    const failed = await until(async () => (await command('status')).jobs.find(job => job.id === blockedJob.id && job.status === 'failed'));
    assert.equal(failed.results[0].passed, false);
    assert.equal(outsideRequests, 0);
    const slow = await command('saveSuite', { siteId: entry.id, name: 'Slow', checks: [{ path: '/slow', type: 'page' }] });
    const running = await command('runSuite', { suiteId: slow.id });
    await assert.rejects(command('runSuite', { suiteId: slow.id }), /already has an active run/);
    const queued = await command('retry', { jobId: blockedJob.id });
    await command('cancel', { jobId: queued.id });
    await command('cancel', { jobId: running.id });
    await until(async () => (await command('status')).jobs.find(job => job.id === running.id && job.status === 'cancelled'));
    await runtime.close();

    const filename = join(directory, 'qa-workspace.json');
    const saved = JSON.parse(await readFile(filename, 'utf8'));
    saved.jobs.find(job => job.id === running.id).status = 'running';
    await writeFile(filename, JSON.stringify(saved));
    reopened = createQaWorkspace({ directory, chromium, ask: async () => '' });
    const restored = await reopened.command('status');
    assert.equal(restored.suites.length, 3);
    assert.equal(restored.jobs.find(job => job.id === running.id).status, 'interrupted');
    assert.equal(restored.jobs.find(job => job.id === id).results.length, 2);
  } finally {
    await reopened?.close();
    await runtime.close();
    await site.close();
    await outside.close();
    await rm(directory, { recursive: true, force: true });
  }
});

test('the production UI registers a site, runs a saved journey and exports its report', async () => {
  let token = '';
  const directory = await mkdtemp(join(tmpdir(), 'ajbot-qa-ui-'));
  const site = await fixture((request, response) => {
    if (request.url === '/.well-known/ajbot-qa.txt') return response.end(token);
    response.setHeader('Content-Type', 'text/html');
    response.end('<title>Test site</title><h1>Local browser test</h1>');
  });
  const runtime = startQaServer({ directory, port: 0, launchOptions });
  let browser;
  try {
    const origin = await runtime.listen();
    browser = await chromium.launch({ headless: true, ...launchOptions });
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    await page.goto(origin + '/?qa=1');
    await page.getByRole('heading', { name: 'QA workspace' }).waitFor();
    await page.getByRole('tab', { name: 'Vision Lab' }).click();
    const vision = page.getByRole('tabpanel', { name: 'Vision Lab' });
    await vision.getByRole('listitem').first().waitFor();
    assert.equal(await vision.getByRole('listitem').count(), 9);
    const imageResponse = await page.request.get(await vision.getByRole('listitem').first().evaluate(tile =>
      getComputedStyle(tile).backgroundImage.slice(5, -2)));
    assert.equal(imageResponse.headers()['content-type'], 'image/jpeg');
    await page.route('**/api/qa', async route => {
      if (route.request().postDataJSON().operation !== 'runVisionLab') return route.continue();
      const confidences = [0.1, 0.95, 0.1, 0.1, 0.1, 0.1, 0.91, 0.1, 0.1];
      await route.fulfill({ json: { data: scoreFixture(confidences) } });
    });
    await vision.getByRole('button', { name: 'Run YOLO demo' }).click();
    await vision.getByText('Puzzle solved').waitFor();
    await vision.getByText('Tile 2 · 95% ✓').waitFor();
    await page.unroute('**/api/qa');
    await page.getByRole('tab', { name: 'Sites' }).click();
    await page.getByLabel('Site name').fill('Local testing');
    await page.getByLabel('Site origin').fill(site.origin);
    await page.getByRole('button', { name: 'Add site' }).click();
    const proof = page.getByLabel('Verification token');
    await proof.waitFor();
    token = await proof.inputValue();
    await page.getByRole('button', { name: 'Verify site' }).click();
    await page.getByRole('button', { name: 'Build journeys' }).click();
    await page.getByLabel('Suite name').fill('Home journey');
    await page.getByRole('button', { name: 'Save suite' }).click();
    await page.getByRole('button', { name: 'Run saved suite' }).click();
    await page.getByText('1 passed · 1 of 1 checked').waitFor();
    const download = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Export report' }).click();
    assert.match((await download).suggestedFilename(), /^qa-.*\.json$/);
    await page.reload();
    await page.getByRole('tab', { name: 'Runs' }).click();
    await page.getByText('1 passed · 1 of 1 checked').waitFor();
    if (process.env.AJBOT_QA_SCREENSHOT) await page.screenshot({ path: process.env.AJBOT_QA_SCREENSHOT });
  } finally {
    await browser?.close();
    await runtime.close();
    await site.close();
    await rm(directory, { recursive: true, force: true });
  }
});
