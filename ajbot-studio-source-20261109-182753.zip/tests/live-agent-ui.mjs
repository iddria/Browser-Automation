// UI/native-boundary test. Real browser-agent execution is covered separately.
import assert from 'node:assert/strict';
import {createServer} from 'vite';
import {chromium} from 'playwright';
import {mkdir} from 'node:fs/promises';
const server=await createServer({server:{host:'127.0.0.1',port:1432,strictPort:true}});await server.listen();
const browser=await chromium.launch({headless:true,...(process.env.AJBOT_TEST_BROWSER?{executablePath:process.env.AJBOT_TEST_BROWSER}:{}),args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.addInitScript(()=>{
 window.isTauri=true;window.calls=[];window.callbacks={};window.handlers={};let callbackId=0;
 window.__TAURI_EVENT_PLUGIN_INTERNALS__={unregisterListener:()=>{}};
 window.emitAgent=e=>{for(const id of window.handlers['ai-agent-progress']||[])window.callbacks[id]?.({event:'ai-agent-progress',id:1,payload:e});};
 window.__TAURI_INTERNALS__={transformCallback:cb=>{const id=++callbackId;window.callbacks[id]=cb;return id;},unregisterCallback:id=>delete window.callbacks[id],invoke:async(command,args={})=>{
  window.calls.push({command,args});
  if(command==='plugin:event|listen'){(window.handlers[args.event]||=[]).push(args.handler);return args.handler;}
  if(command==='plugin:event|unlisten'){for(const event of Object.keys(window.handlers))window.handlers[event]=window.handlers[event].filter(id=>id!==args.eventId);return;}
  if(command==='list_browser_profiles')return [{id:'closed-profile',name:'Local test profile',running:false},{id:'open-profile',name:'Open profile',running:true}];
  if(['list_browser_workflows','list_run_history','list_provider_keys'].includes(command))return [];
  if(command==='run_ai_agent')return new Promise(resolve=>{window.agent={runId:args.runId,resolve};});
  if(command==='control_ai_agent'){
   if(args.action==='approve'&&args.approvalId==='approval-one'){
    window.emitAgent({runId:args.runId,seq:3,status:'needs_approval',detail:'Submit search',step:1,approval:{id:'approval-two',kind:'action',detail:'Press Enter in search',action:{action:'press',label:'Search',key:'Enter'}}});
    return {status:'resuming'};
   }
   if(args.action==='approve'||args.action==='stop'||args.action==='reject'){
    const result={runId:args.runId,status:args.action==='approve'?'completed':'stopped',summary:args.action==='approve'?'Test goal finished.':'Agent stopped.',executed:args.action==='approve'?1:0,trace:[]};
    window.emitAgent({runId:args.runId,seq:9,status:result.status,detail:result.summary,step:result.executed,result});window.agent.resolve(result);
   }return {status:'accepted'};
  }
  throw Error(`Unexpected command: ${command}`);
 }};
});
const nav=async name=>page.getByRole('navigation').getByRole('button',{name,exact:true}).click();
try{
 await mkdir('test-results',{recursive:true});await page.goto('http://127.0.0.1:1432');await nav('Custom');
 await page.getByRole('button',{name:'Run AI Agent',exact:true}).click();let modal=page.getByRole('dialog',{name:'Run AI Agent (live)'});
 await modal.getByLabel('Goal',{exact:true}).fill('Inspect my authorized demo website.');await modal.getByLabel('Start URL',{exact:true}).fill('https://example.com');
 assert.equal(await modal.getByLabel('Max steps',{exact:true}).inputValue(),'12');
 await modal.getByRole('combobox',{name:'Provider',exact:true}).selectOption('openrouter');
 await modal.getByRole('combobox',{name:'Model',exact:true}).selectOption('');
 await page.screenshot({path:'test-results/live-agent-form.png'});
 await modal.getByRole('button',{name:'Run agent',exact:true}).click();await page.waitForFunction(()=>!!window.agent);
 const run=await page.evaluate(()=>window.calls.find(c=>c.command==='run_ai_agent'));
 assert.equal(run.args.goal,'Inspect my authorized demo website.');assert.equal(run.args.maxSteps,12);assert.equal(run.args.provider,'openrouter');assert.ok(run.args.model);
 assert.equal(run.args.profileId,null);
 assert.equal(await page.evaluate(()=>window.calls.some(c=>c.command==='save_browser_workflow'||c.command==='plan_browser_workflow')),false);
 await page.evaluate(()=>window.emitAgent({runId:window.agent.runId,seq:2,status:'needs_approval',detail:'Review text entry',step:0,approval:{id:'approval-one',kind:'action',detail:'Fill the test input',action:{action:'fill',label:'Demo field',value:'Demo data'}}}));
 await modal.getByRole('button',{name:'Approve this action',exact:true}).waitFor();
 assert.equal(await modal.getByLabel('Text to enter',{exact:true}).inputValue(),'Demo data');
 await page.screenshot({path:'test-results/live-agent-approval.png'});
 await modal.getByRole('button',{name:'Hide',exact:true}).click();await nav('Overview');
 await page.getByRole('button',{name:'Waiting for you · Open agent',exact:true}).click();modal=page.getByRole('dialog',{name:'Run AI Agent (live)'});
 await modal.getByRole('button',{name:'Approve this action',exact:true}).click();
 await modal.getByText('Key: Enter',{exact:true}).waitFor();
 await modal.getByRole('button',{name:'Approve this action',exact:true}).click();
 await modal.getByRole('status').filter({hasText:'Agent finished'}).waitFor();
 const approved=await page.evaluate(()=>window.calls.find(c=>c.command==='control_ai_agent'));assert.equal(approved.args.approvalId,'approval-one');assert.equal(approved.args.action,'approve');
 assert.equal(await page.evaluate(()=>window.calls.filter(c=>c.command==='control_ai_agent'&&c.args.approvalId==='approval-two').length),1);
 // Late progress from a completed run cannot revive the old approval.
 await page.evaluate(()=>window.emitAgent({runId:window.agent.runId,seq:3,status:'needs_approval',detail:'Stale event',step:0,approval:{id:'stale',kind:'action',detail:'Stale',action:null}}));
 assert.equal(await modal.getByRole('button',{name:'Approve this action',exact:true}).count(),0);
 const profilePicker=modal.getByRole('combobox',{name:'Browser profile'});
 assert.equal(await profilePicker.locator('option[value="open-profile"]').isDisabled(),true);
 await profilePicker.selectOption('closed-profile');
 await modal.getByRole('button',{name:'Run agent',exact:true}).click();await page.waitForFunction(()=>window.calls.filter(c=>c.command==='run_ai_agent').length===2);
 assert.equal(await page.evaluate(()=>window.calls.filter(c=>c.command==='run_ai_agent')[1].args.profileId),'closed-profile');
 await modal.getByRole('button',{name:'Stop agent',exact:true}).click();await modal.getByRole('status').filter({hasText:'Stopped'}).waitFor();
 await modal.getByLabel('Max steps',{exact:true}).fill('0');await modal.getByRole('button',{name:'Run agent',exact:true}).click();
 await modal.getByRole('alert').filter({hasText:'whole number from 1 to 50'}).waitFor();
 assert.equal(await page.evaluate(()=>window.calls.filter(c=>c.command==='run_ai_agent').length),2);
 assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('ajbot-studio-live-agent-history')).length),2);
 assert.equal(await page.evaluate(()=>JSON.stringify(localStorage).includes('Demo data')),false);
 assert.equal(errors.length,0,errors.join('\n'));
 console.log('PASS: video agent form, native run dispatch, per-action approval, hidden-run persistence, Stop, limits, stale events and private input boundary.');
}finally{await browser.close();await server.close();}
