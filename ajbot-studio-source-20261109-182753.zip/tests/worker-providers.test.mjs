import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
test('worker protocol discovers models and validates new-provider workflow plans',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'ajbot-provider-test-'));
  const child=spawn(process.execPath,['--require',resolve('tests/provider-fetch-fixture.cjs'),resolve('browser-worker/worker.cjs')],{env:{...process.env,AJBOT_PROFILES_DIR:join(dir,'profiles')},stdio:['pipe','pipe','pipe']});
  const pending=new Map();let next=1;const lines=createInterface({input:child.stdout});
  lines.on('line',line=>{try{const value=JSON.parse(line);if(pending.has(value.id)){pending.get(value.id)(value);pending.delete(value.id);}}catch{}});
  const request=message=>new Promise((resolve,reject)=>{const id=next++;const timer=setTimeout(()=>{pending.delete(id);reject(new Error('Worker protocol timeout'));},5000);pending.set(id,value=>{clearTimeout(timer);resolve(value);});child.stdin.write(JSON.stringify({id,...message})+'\n');});
  try{
    const models=await request({action:'listProviderModels',provider:'openrouter'});
    assert.equal(models.ok,true);assert.equal(models.data[0].id,'test/model');
    const plan=await request({action:'planWorkflow',provider:'openrouter',model:'test/model',apiKey:'test-key-memory-only',task:'Inspect example.com'});
    assert.equal(plan.ok,true);assert.equal(plan.plan.steps[0].action,'navigate');assert.equal(plan.plan.steps[0].url,'https://example.com/');
    assert.ok(!JSON.stringify(models).includes('test-key-memory-only'));
  }finally{child.stdin.end(JSON.stringify({id:999,action:'shutdown'})+'\n');child.kill();lines.close();await rm(dir,{recursive:true,force:true});}
});
