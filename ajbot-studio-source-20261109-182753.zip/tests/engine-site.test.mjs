import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdtemp,writeFile,rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import {verifyEngine,repairEngine} from '../browser-worker/engine.cjs';
import {discoverPages} from '../browser-worker/site-pages.cjs';
import {countryHint} from '../src/studio/deviceCountry.ts';
import {validateCanvas} from '../src/studio/model.ts';
import {buildSwarmerJourneys} from '../src/studio/swarmerJourneys.ts';
test('device country follows timezone, explicit locale, and leaves ambiguous UTC unknown',()=>{
 assert.equal(countryHint('Africa/Accra',['en-US']),'GH');
 assert.equal(countryHint('Europe/London',['en-US']),'GB');
 assert.equal(countryHint('UTC',['fr-CA']),'CA');
 assert.equal(countryHint('UTC',['en']),'');
});
test('Type & Enter compiles into executable fill and press actions',()=>{
 const steps=validateCanvas([{name:'Test',startUrl:'https://example.com',steps:[{action:'fillAndEnter',selector:'#search',value:'test'}]}]);
 assert.deepEqual(steps.map(s=>s.action),['navigate','fill','press']);assert.equal(steps[2].key,'Enter');
 assert.throws(()=>validateCanvas([{name:'Test',startUrl:'https://example.com',steps:[{action:'fillAndEnter',selector:'#search'}]}]),/selector and text/);
});
test('engine reports a missing browser and verifies a real launch when available',async t=>{
 const missing=await verifyEngine({playwright:{chromium:{executablePath:()=>'/not-an-ajbot-browser'}}});
 assert.equal(missing.ok,false);assert.equal(missing.checks.find(c=>c.name==='Chromium files').ok,false);
 if(process.env.AJBOT_TEST_BROWSER){const report=await verifyEngine({browserPath:process.env.AJBOT_TEST_BROWSER});assert.equal(report.ok,true,JSON.stringify(report));assert.ok(report.checks.some(c=>c.name==='Browser launch'&&c.ok));}
 else t.diagnostic('Real launch skipped: set AJBOT_TEST_BROWSER to a supported Chromium executable.');
});
test('repair surfaces installer failure instead of claiming success',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'ajbot-engine-test-'));try{
 const cli=path.join(dir,'cli.cjs');await writeFile(cli,"process.stderr.write('Installation failed: network unavailable');process.exitCode=1;");
 await assert.rejects(repairEngine({cliPath:cli}),/network unavailable/);
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('site discovery deduplicates same-origin HTML and nested sitemap pages without off-site requests',async()=>{
 const calls=[];const docs={
 'https://example.com/':`<link rel="manifest" href="/manifest.json"><link rel="canonical" href="/metadata">
   <script>const sample = '<a href="/fake">Fake</a>';</script>
   <a href=/about>About</a><a href="https://other.test/x">Other</a><a href="/about#top">Same</a>
   <a href="/file.zip">Download</a><a href="/download" download>Export</a><a href="/data">Data</a>
   <a href="/gone">Redirect</a><a href="/missing">Missing</a><a data-href="/fake">No href</a>`,
 'https://example.com/about':'<p>About without an H1</p>',
 'https://example.com/contact':'<p>Contact</p>',
 'https://example.com/data':'{"value":1}',
 'https://example.com/sitemap.xml':'<sitemapindex><sitemap><loc>https://example.com/pages.xml</loc></sitemap><sitemap><loc>https://other.test/map.xml</loc></sitemap></sitemapindex>',
 'https://example.com/pages.xml':'<urlset><url><loc>https://example.com/contact</loc></url><url><loc>https://example.com/about</loc></url><url><loc>https://example.com/manifest.json</loc></url></urlset>'};
 const pages=await discoverPages('https://example.com/#features',{fetcher:async(url,options)=>{
   calls.push(url);
   assert.equal(options.redirect,'manual');
   if (url.endsWith('/gone')) return new Response(null,{status:302,headers:{location:'https://other.test/'}});
   const type = url.endsWith('.xml') ? 'application/xml' : url.endsWith('/data') ? 'application/json' : 'text/html; charset=utf-8';
   return new Response(docs[url]||'',{status:docs[url]?200:404,headers:{'content-type':type}});
 }});
 assert.deepEqual(pages,['https://example.com/','https://example.com/about','https://example.com/contact']);
 assert.deepEqual(calls.map(url=>new URL(url).pathname).sort(),['/','/about','/contact','/data','/gone','/missing','/pages.xml','/sitemap.xml'].sort());
 assert.ok(calls.every(u=>new URL(u).origin==='https://example.com'));
});
test('discovery surfaces target failures, tolerates absent sitemap, and rejects credential URLs',async()=>{
 await assert.rejects(discoverPages('https://example.com',{fetcher:async()=>new Response('',{status:403})}),/403/);
 await assert.rejects(discoverPages('https://example.com/manifest.json',{fetcher:async()=>Response.json({name:'Akoriva'})}),/must return an HTML page/);
 assert.deepEqual(await discoverPages('https://example.com/',{fetcher:async u=>u.endsWith('.xml')?new Response('',{status:404}):new Response('<h1>Test</h1>',{headers:{'content-type':'text/html'}})}),['https://example.com/']);
 await assert.rejects(discoverPages('https://user:secret@example.com/'),/Invalid/);
});
test('swarmer drafts visit different pages in order and preserve journey boundaries', () => {
 const pages = ['/', '/demo.html', '/contact.html', '/privacy.html', '/terms.html'].map(path => 'https://example.com' + path);
 const drafts = buildSwarmerJourneys(pages, 24, 6);
 assert.equal(drafts.length, 20);
 assert.equal(new Set(drafts.map(j => j.name)).size, drafts.length);
 assert.equal(drafts[0].startUrl, pages[0]);
 assert.equal(drafts[1].startUrl, pages[1]);
 for (const draft of drafts) {
   const steps = validateCanvas([draft]);
   assert.deepEqual(steps.map(s => s.action), ['navigate','navigate','navigate','navigate','extractLinks','screenshot']);
   assert.equal(steps[0].journeyName, draft.name);
   assert.equal(steps.filter(s => s.journeyStart).length, 1);
   const visits = steps.slice(0, 4);
   assert.ok(visits.every(s => s.verifyHtml && pages.includes(s.url)));
   assert.equal(new Set(visits.map(s => s.url)).size, 4);
 }
 const twoPageSteps = validateCanvas(buildSwarmerJourneys(pages.slice(0, 2), 1, 6));
 assert.deepEqual(twoPageSteps.map(s => s.action), ['navigate','extractLinks','screenshot','navigate','extractLinks','screenshot']);
 assert.equal(validateCanvas(buildSwarmerJourneys(pages.slice(0, 1), 24, 6)).length, 3);
});
