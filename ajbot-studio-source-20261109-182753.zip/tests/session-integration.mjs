// Exercise the actual React session controller through a mocked Tauri boundary.
// This does not substitute for a Windows native build or real-browser acceptance.
import assert from 'node:assert/strict';
import { createServer } from 'vite';
import { chromium } from 'playwright';
const server=await createServer({server:{host:'127.0.0.1',port:1431,strictPort:true}});await server.listen();
const browser=await chromium.launch({headless:true,...(process.env.AJBOT_TEST_BROWSER?{executablePath:process.env.AJBOT_TEST_BROWSER}:{}),args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.addInitScript(()=>{
  window.isTauri=true;
  window.testCalls=[];window.testProfiles=Array.from({length:4},(_,i)=>({id:`p${i+1}`,name:`Classroom ${i+1}`,startUrl:'https://example.com',running:false}));
  window.testPending={};window.testKeyIds=[];window.testSchedules=[];window.testWorkflows=[{id:'w1',name:'Inspect',steps:[{action:'screenshot'}]}];
  window.testHistory=[];
  const callbacks=new Map(), listeners=new Map();let callbackId=0,listenerId=0;
  window.testEmit=(event,payload)=>{for(const [id,entry] of listeners)if(entry.event===event)callbacks.get(entry.handler)?.({event,id,payload});};
  const pods=Array.from({length:4},(_,i)=>({id:`pod${i+1}`,name:`Classroom ${i+1}`,profiles:[`p${i+1}`],devices:{[`p${i+1}`]:'Windows'}}));
  pods.push({id:'device-pod',name:'Device range pod',profiles:['p1','p2','p3','p4'],devices:{p1:'Windows',p2:'Windows',p3:'Android',p4:'Mac'}});
  localStorage.setItem('ajbot-studio-pods',JSON.stringify(pods));
  const base={type:'Custom',podId:'pod1',workflowId:'w1',proxyId:'proxy1',provider:'ollama',model:'qwen2.5:7b',incognito:false,vision:false};
  localStorage.setItem('ajbot-studio-sessions',JSON.stringify([{...base,id:'s1',name:'First session'},{...base,id:'s2',name:'Second session',incognito:true},...Array.from({length:3},(_,i)=>({...base,id:`extra${i}`,podId:`pod${i+2}`,name:`Extra session ${i+1}`}))]));
  window.__TAURI_EVENT_PLUGIN_INTERNALS__={unregisterListener:()=>{}};
  window.__TAURI_INTERNALS__={transformCallback:callback=>{callbacks.set(++callbackId,callback);return callbackId;},invoke:async(command,args={})=>{
    window.testCalls.push({command,args});
    switch(command){
      case 'plugin:event|listen': listeners.set(++listenerId,args);return listenerId;
      case 'plugin:event|unlisten': listeners.delete(args.eventId);return;
      case 'list_browser_profiles':return structuredClone(window.testProfiles);
      case 'list_browser_workflows':return structuredClone(window.testWorkflows);
      case 'save_browser_workflow':{const w={id:args.workflowId,name:args.name,steps:args.steps.map(s=>({...s,action:s.action.toLowerCase()}))};window.testWorkflows=[...window.testWorkflows.filter(old=>old.id!==w.id),w];return w;}
      case 'delete_browser_workflow':window.testWorkflows=window.testWorkflows.filter(w=>w.id!==args.workflowId);return;
      case 'discover_site_pages':return ['https://example.com/','https://example.com/about','https://example.com/contact','https://example.com/privacy'];
      case 'list_run_history':return structuredClone(window.testHistory);
      case 'list_proxies':return [{id:'proxy1',name:'Test proxy'}];
      case 'list_schedules':return structuredClone(window.testSchedules);
      case 'list_schedule_runs':return [];
      case 'save_schedule':{
        const job={...args,enabled:true,running:false,nextRunAt:args.scheduledAt};
        window.testSchedules=[...window.testSchedules.filter(item=>item.id!==job.id),job];return job;
      }
      case 'get_profile_proxy':return 'original-proxy';
      case 'assign_proxy_to_profile':return;
      case 'launch_browser_profile':window.testProfiles.find(p=>p.id===args.profileId).running=true;return;
      case 'close_browser_profile':window.testProfiles.find(p=>p.id===args.profileId).running=false;return;
      case 'create_browser_profile':{const p={id:args.profileId,name:args.name,startUrl:args.startUrl,deviceClass:args.deviceClass,running:false};window.testProfiles.push(p);if(window.pauseCreation) await new Promise(resolve=>window.pendingCreate=resolve);return p;}
      case 'update_browser_profile':{const p=window.testProfiles.find(profile=>profile.id===args.profileId);p.name=args.name;p.startUrl=args.startUrl;return p;}
      case 'start_browser_recording':return {status:'recording',actions:[]};
      case 'control_browser_recording':return {status:'stopped',actions:[
        {id:'rec-1',action:'click',url:'https://example.com/',selector:'#fixture-link'},
      ]};
      case 'backup_browser_profile':return {path:'fixture-profile.zip'};
      case 'verify_browser_profile_backup':return {valid:true,profileName:'Classroom 1',fileCount:2};
      case 'search_web':return {query:args.query,providers:[],results:[
        {title:'Fixture site',url:'https://example.com/research',description:'Local test result',providers:['brave']},
      ]};
      case 'delete_browser_profile':window.testProfiles=window.testProfiles.filter(p=>p.id!==args.profileId);return;
      case 'run_browser_workflow':return new Promise(resolve=>{window.testPending[args.profileId]=resolve;});
      case 'control_browser_workflow':
        if(args.action==='stopWorkflow'){window.testPending[args.profileId]?.({results:[]});delete window.testPending[args.profileId];}
        return 'Control accepted';
      case 'verify_browser_engine':return {ok:false,checks:[{name:'Chromium files',ok:false,detail:'Browser binary missing'}]};
      case 'repair_browser_engine':return {ok:true,checks:[{name:'Browser launch',ok:true,detail:'Launch check passed'}]};
      case 'device_country':return 'GH';
      case 'list_provider_keys':return window.testKeyIds;
      case 'save_provider_key':window.testKeyIds=[args.provider];return;
      case 'list_provider_models':return [{id:'new/model',name:'New model'}];
      case 'plan_browser_workflow':{
        if(!args.startUrl)return {name:'Provider draft',steps:[{action:'screenshot'}]};
        const scopeOrigin=new URL(args.startUrl).origin;
        return {journeys:[{name:'Find scores',startUrl:args.startUrl,scopeOrigin,steps:[
          {action:'fill',selector:'input[type=search]',targetLabel:'Search site',value:'class scores',scopeOrigin},
          {action:'press',selector:'input[type=search]',targetLabel:'Search site',key:'Enter',scopeOrigin},
          {action:'waitfortext',value:'Results',scopeOrigin},
        ]}],blocked:[{goal:2,reason:'The control is missing.'}]};
      }
      default:throw new Error(`Unexpected native command: ${command}`);
    }
  }};
});
const nav=async name=>page.getByRole('navigation').getByRole('button',{name,exact:true}).click();
const start=async name=>{await page.locator('.aj-session-card').filter({has:page.getByRole('heading',{name,exact:true})}).getByRole('button',{name:'Start',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Confirm & run'}).click();};
try{
  await page.goto('http://127.0.0.1:1431');await nav('Sessions');await start('First session');
  await page.waitForFunction(()=>Object.keys(window.testPending).length===1);
  await nav('Overview');await nav('Sessions');
  assert.match(await page.locator('.aj-session-card').first().innerText(),/Running/);
  await page.locator('.aj-session-card').first().getByRole('button',{name:'Pause',exact:true}).click();
  await page.locator('.aj-session-card').first().getByText('Paused',{exact:true}).waitFor();
  await page.locator('.aj-session-card').first().getByRole('button',{name:'Resume',exact:true}).click();
  await start('Second session');await page.getByRole('status').filter({hasText:'already used by another session'}).waitFor();
  await page.locator('.aj-session-card').first().getByRole('button',{name:'Stop',exact:true}).click();
  await page.locator('.aj-session-card').first().getByText('Session stopped.',{exact:true}).waitFor();
  let calls=await page.evaluate(()=>window.testCalls);
  assert.ok(calls.some(c=>c.command==='control_browser_workflow'));
  assert.ok(calls.some(c=>c.command==='launch_browser_profile'&&c.args.proxyId==='proxy1'&&c.args.deviceClass==='Windows'));
  assert.ok(calls.some(c=>c.command==='control_browser_workflow'&&c.args.action==='pauseWorkflow'));
  assert.ok(calls.some(c=>c.command==='control_browser_workflow'&&c.args.action==='resumeWorkflow'));
  assert.ok(!calls.some(c=>c.command==='assign_proxy_to_profile'),'session leaves the permanent assignment untouched');
  await start('Second session');await page.waitForFunction(()=>Object.keys(window.testPending).length===1);
  const temp=await page.evaluate(()=>Object.keys(window.testPending)[0]);assert.ok(temp.startsWith('ephemeral-'));
  await page.evaluate(id=>{window.testPending[id]({results:[{ok:true}]});delete window.testPending[id];},temp);
  await page.locator('.aj-session-card').nth(1).getByText('All profiles finished.',{exact:true}).waitFor();
  calls=await page.evaluate(()=>window.testCalls);
  assert.ok(calls.some(c=>c.command==='delete_browser_profile'&&c.args.profileId===temp));
  assert.ok(calls.filter(c=>c.command==='run_browser_workflow').every(c=>c.args.approveConsequential===false));
  assert.equal(await page.evaluate(()=>window.testProfiles.length),4);
  await start('First session');await page.waitForFunction(()=>Object.keys(window.testPending).length===1);
  await page.evaluate(()=>{const id=Object.keys(window.testPending)[0];window.testPending[id]({ok:false,status:'failed',message:'Failure before first action',results:[]});delete window.testPending[id];});
  await page.locator('.aj-session-card').first().getByText('Failed',{exact:true}).waitFor();
  assert.equal(await page.evaluate(()=>window.testProfiles[0].running),false);
  await nav('Provider Keys');await page.getByRole('textbox',{name:'OpenAI API key',exact:true}).fill('sk-educational-test-value');
  await page.locator('.aj-provider').filter({has:page.getByRole('heading',{name:'OpenAI',exact:true})}).getByRole('button',{name:'Save',exact:true}).click();
  await page.getByRole('status').filter({hasText:'Key saved using Windows encryption'}).waitFor();
  assert.equal(await page.evaluate(()=>JSON.stringify(localStorage).includes('sk-educational-test-value')),false);
  await page.getByRole('button',{name:'Verify Engine',exact:true}).click();
  await page.getByRole('status').filter({hasText:'Engine needs attention'}).waitFor();
  await page.getByRole('button',{name:'Repair Engine',exact:true}).click();
  await page.getByRole('status').filter({hasText:'Engine ready'}).waitFor();
  assert.ok((await page.evaluate(()=>window.testCalls)).some(c=>c.command==='repair_browser_engine'));
  // Owner-selected caps take effect without remounting active session controllers.
  await nav('Settings');await page.getByLabel('Concurrent sessions (0 = no fixed cap)',{exact:true}).fill('2');
  await page.getByRole('button',{name:'Save capacity settings'}).click();await nav('Sessions');
  await start('First session');await start('Extra session 1');
  await page.waitForFunction(()=>Object.keys(window.testPending).length===2);
  await start('Extra session 2');await page.getByRole('status').filter({hasText:'Your setting allows 2 concurrent sessions'}).waitFor();
  assert.equal(await page.evaluate(()=>Object.keys(window.testPending).length),2);
  await nav('Settings');await page.getByLabel('Concurrent sessions (0 = no fixed cap)',{exact:true}).fill('0');
  await page.getByRole('button',{name:'Save capacity settings'}).click();await nav('Sessions');
  await start('Extra session 2');await start('Extra session 3');
  await page.waitForFunction(()=>Object.keys(window.testPending).length===4);
  assert.equal(await page.locator('.aj-session-card').getByText('Running',{exact:true}).count(),4);
  await page.screenshot({path:'test-results/capacity-sessions.png'});
  for(const name of ['First session','Extra session 1','Extra session 2','Extra session 3']) {
    await page.locator('.aj-session-card').filter({has:page.getByRole('heading',{name,exact:true})}).getByRole('button',{name:'Stop',exact:true}).click();
  }
  await page.waitForFunction(()=>Object.keys(window.testPending).length===0&&window.testProfiles.every(p=>!p.running));
  await nav('Sessions');await page.getByRole('button',{name:'New Session',exact:true}).click();
  let dialog=page.getByRole('dialog');await dialog.getByLabel('Name',{exact:true}).fill('Device range session');
  await dialog.getByRole('combobox',{name:'Session pod',exact:true}).selectOption('device-pod');
  for(const device of ['iPhone','Android','Mac']) await dialog.getByRole('spinbutton',{name:`${device} maximum active`}).fill('0');
  await dialog.getByRole('spinbutton',{name:'Windows minimum active'}).fill('1');
  await dialog.getByRole('spinbutton',{name:'Windows maximum active'}).fill('2');
  await page.screenshot({path:'test-results/session-devices.png'});
  await dialog.getByRole('button',{name:'Save Session'}).click();await start('Device range session');
  await page.waitForFunction(()=>Object.keys(window.testPending).length===2);
  assert.deepEqual((await page.evaluate(()=>Object.keys(window.testPending))).sort(),['p1','p2']);
  await page.locator('.aj-session-card').filter({has:page.getByRole('heading',{name:'Device range session',exact:true})}).getByRole('button',{name:'Stop',exact:true}).click();
  await page.waitForFunction(()=>Object.keys(window.testPending).length===0&&window.testProfiles.every(p=>!p.running));
  await page.getByRole('button',{name:'Edit Device range session',exact:true}).click();
  await page.getByRole('dialog').getByRole('spinbutton',{name:'Windows minimum active'}).fill('3');
  await page.getByRole('dialog').getByRole('spinbutton',{name:'Windows maximum active'}).fill('3');
  await page.getByRole('dialog').getByRole('button',{name:'Save Session'}).click();await start('Device range session');
  await page.getByRole('status').filter({hasText:'available: 2'}).waitFor();
  assert.equal(await page.evaluate(()=>Object.keys(window.testPending).length),0);
  await page.getByRole('button',{name:'Edit Device range session',exact:true}).click();
  await page.getByRole('dialog').getByRole('spinbutton',{name:'Windows maximum active'}).fill('1');
  await page.getByRole('dialog').getByRole('button',{name:'Save Session'}).click();
  await page.getByRole('dialog').getByRole('alert').filter({hasText:'minimum cannot exceed maximum'}).waitFor();
  await page.getByRole('dialog').getByRole('button',{name:'Cancel',exact:true}).click();
  await nav('Custom');await page.getByRole('button',{name:'Advanced editor',exact:true}).click();
  dialog=page.getByRole('dialog');await dialog.getByRole('combobox',{name:'AI provider',exact:true}).selectOption('openrouter');
  await dialog.getByRole('button',{name:'Refresh provider models'}).click();
  await dialog.getByRole('status').filter({hasText:'1 models loaded'}).waitFor();
  await dialog.getByRole('combobox',{name:'AI model',exact:true}).selectOption('new/model');
  await dialog.getByLabel('Provider API key (memory only)',{exact:true}).fill('sk-new-provider-key');
  await dialog.getByLabel('Task instructions',{exact:true}).fill('Inspect the page');
  await dialog.getByRole('button',{name:'Generate AI draft'}).click();
  await page.waitForFunction(()=>window.testCalls.some(c=>c.command==='plan_browser_workflow'));
  const plan=await page.evaluate(()=>window.testCalls.find(c=>c.command==='plan_browser_workflow'));
  assert.equal(plan.args.provider,'openrouter');assert.equal(plan.args.model,'new/model');
  assert.equal(await page.evaluate(()=>JSON.stringify(localStorage).includes('sk-new-provider-key')),false);
  await dialog.getByRole('button',{name:'Close',exact:true}).click();
  await page.getByRole('button',{name:'Build with AI',exact:true}).click();
  dialog=page.getByRole('dialog',{name:'Build with AI'});
  await dialog.getByLabel('Describe your task',{exact:true}).fill('Inspect this authorized test site');
  await dialog.getByRole('button',{name:'Generate draft',exact:true}).click();
  await page.getByRole('status').filter({hasText:'AI draft created'}).waitFor();
  assert.equal(await page.getByRole('textbox',{name:'Workflow name',exact:true}).inputValue(),'Provider draft');
  assert.equal(await page.locator('.aj-compact-node').count(),1);
  await page.getByRole('button',{name:'Add step',exact:true}).click();
  await page.getByRole('dialog',{name:'Add step'}).getByRole('button',{name:'AI Click Object',exact:true}).click();
  await page.getByRole('dialog',{name:'Build with AI'}).getByLabel('Describe your task').fill('Inspect the heading on the test page');
  await page.getByRole('dialog',{name:'Build with AI'}).getByRole('button',{name:'Generate draft',exact:true}).click();
  await page.waitForFunction(()=>JSON.parse(localStorage.getItem('ajbot-studio-canvas')).journeys[0].steps.length===2);
  await page.getByRole('button',{name:'Run saved workflow',exact:true}).click();
  await page.getByRole('dialog',{name:'Run saved workflow'}).getByRole('button',{name:'Review in runner',exact:true}).click();
  await page.getByRole('dialog',{name:'Workflow builder'}).getByRole('status').filter({hasText:'Canvas workflow loaded'}).waitFor();
  assert.equal(await page.getByRole('dialog',{name:'Workflow builder'}).getByRole('textbox',{name:'Workflow name',exact:true}).inputValue(),'Provider draft');
  await page.getByRole('button',{name:'Close',exact:true}).click();
  await nav('Swarmers');await page.getByPlaceholder('https://example.com',{exact:true}).fill('https://example.com');
  await page.getByRole('button',{name:'Generate',exact:true}).click();
  await page.getByRole('status').filter({hasText:'4 pages found · 3 inspection journeys generated'}).waitFor();
  assert.equal(await page.locator('.aj-route-list').count(),3);
  const firstRoute=await page.locator('.aj-route-list').first().locator('li').allTextContents();
  assert.deepEqual(firstRoute.slice(0,4).map(line=>line.split(' · ')[1]),['https://example.com/','https://example.com/contact','https://example.com/privacy','https://example.com/about']);
  assert.deepEqual(firstRoute.slice(4),['List links on this page','Capture a full-page screenshot']);
  await page.getByRole('button',{name:'Save as one swarm'}).click();
  await page.getByRole('status').filter({hasText:'3 inspection journeys saved'}).waitFor();
  await page.evaluate(()=>localStorage.removeItem('ajbot-studio-journey-library'));
  await page.locator('.aj-activity-row').filter({hasText:'Swarmer · example.com'}).getByRole('button',{name:'Open',exact:true}).click();
  assert.equal(await page.locator('.aj-journey-tabs .aj-pill').count(),3);
  assert.match(await page.locator('.aj-journey-tabs .aj-pill').first().innerText(),/\/ → \/about/);
  assert.equal(await page.getByRole('textbox',{name:'Workflow name',exact:true}).inputValue(),'Swarmer · example.com');
  await nav('Swarmers');
  await page.getByRole('button',{name:'Build from goals',exact:true}).click();
  await page.getByPlaceholder('https://example.com',{exact:true}).fill('https://school.example');
  await page.getByRole('textbox',{name:'Journey goals'}).fill('Search for class scores and check Results.\nType in a missing field.');
  await page.getByRole('button',{name:'Build journeys',exact:true}).click();
  await page.getByRole('status').filter({hasText:'1 guided journey ready to review'}).waitFor();
  assert.deepEqual(await page.locator('.aj-route-list li').allTextContents(),[
    'Open target · https://school.example/',
    'Enter “class scores” in “Search site”',
    'Press Enter in “Search site” to search',
    'Check for visible text “Results”',
  ]);
  await page.getByRole('alert').filter({hasText:'Goal 2 needs more detail'}).waitFor();
  await page.getByRole('button',{name:'Save as one swarm'}).click();
  await page.getByRole('status').filter({hasText:'1 guided journey saved'}).waitFor();
  const guided=await page.evaluate(()=>window.testWorkflows.find(w=>w.name==='Swarmer · school.example'));
  assert.deepEqual(guided.steps.map(s=>s.action),['navigate','fill','press','waitfortext']);
  assert.equal(guided.steps[0].scopeOrigin,'https://school.example');
  assert.equal(guided.steps[1].value,'class scores');
  // Cancelling a large batch retains the in-flight profile and its group checkpoint.
  await nav('Pods');await page.getByRole('spinbutton',{name:'Windows profiles to create'}).fill('10');
  await page.getByLabel('Pod name').fill('Cancelled batch');await page.evaluate(()=>window.pauseCreation=true);
  await page.getByRole('button',{name:'Create Browsers'}).click();await page.waitForFunction(()=>!!window.pendingCreate);
  await page.getByRole('button',{name:'Cancel batch'}).click();await page.evaluate(()=>window.pendingCreate());
  await page.getByRole('status').filter({hasText:'1 browser profile definitions created in Cancelled batch. Batch cancelled'}).waitFor();
  assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('ajbot-studio-pods')).find(p=>p.name==='Cancelled batch').profiles.length),1);
  assert.equal(await page.evaluate(()=>window.testProfiles.length),5);
  await page.evaluate(()=>window.pauseCreation=false);
  await page.getByRole('button',{name:/Manage Pods/}).click();
  const podRow=page.locator('.aj-pod-row').filter({has:page.getByRole('textbox',{name:'Pod name Classroom 1',exact:true})});
  await podRow.getByRole('button',{name:'Configure',exact:true}).click();
  const podDialog=page.getByRole('dialog',{name:'Configure pod'});
  await podDialog.getByLabel('Pod workflow').selectOption('w1');
  await podDialog.getByLabel('Pod proxy').selectOption('proxy1');
  await podDialog.getByRole('button',{name:'Save pod schedule'}).click();
  await page.getByRole('status').filter({hasText:'Schedule saved for 1 pod profile'}).waitFor();
  const podJob=await page.evaluate(()=>window.testSchedules[0]);
  assert.equal(podJob.podId,'pod1');assert.equal(podJob.proxyId,'proxy1');
  assert.deepEqual(podJob.members,[{profileId:'p1',deviceClass:'Windows'}]);
  await podRow.getByRole('button',{name:'Clone',exact:true}).click();
  await page.getByRole('status').filter({hasText:'profile definitions created in Classroom 1 copy'}).waitFor();
  const cloned=await page.evaluate(()=>JSON.parse(localStorage.getItem('ajbot-studio-pods')).find(p=>p.name==='Classroom 1 copy'));
  assert.equal(cloned.workflowId,'w1');assert.equal(cloned.proxyId,'proxy1');assert.notEqual(cloned.profiles[0],'p1');
  await podRow.getByRole('button',{name:'Run pod',exact:true}).click();
  await page.getByRole('dialog',{name:'Review session: Classroom 1'}).getByRole('button',{name:'Cancel',exact:true}).click();
  await page.getByRole('group',{name:'Session tools'}).getByRole('button',{name:'Scheduler',exact:true}).click();
  const scheduleCard=page.locator('.scheduler-job').filter({hasText:'Pod · Classroom 1'});
  await scheduleCard.waitFor();
  assert.match(await scheduleCard.innerText(),/Pod members\s+1 profile/);
  await nav('Pods');
  await page.getByRole('button',{name:'Create 100 training pods',exact:true}).click();
  await page.getByRole('status').filter({hasText:'100 of 100 training pods are ready'}).waitFor();
  await page.getByRole('button',{name:'Training pods ready',exact:true}).waitFor();
  const training=await page.evaluate(()=>{
    const pods=JSON.parse(localStorage.getItem('ajbot-studio-pods')).filter(pod=>pod.id.startsWith('pod-training-'));
    return pods.map(pod=>({
      id:pod.id,profiles:pod.profiles,
      device:pod.devices[pod.profiles[0]],
      startUrl:window.testProfiles.find(profile=>profile.id===pod.profiles[0])?.startUrl,
    }));
  });
  assert.equal(training.length,100);
  assert.equal(new Set(training.flatMap(pod=>pod.profiles)).size,100);
  assert.ok(training.every(pod=>pod.profiles.length===1&&pod.startUrl==='https://accounts.google.com/'));
  for(const device of ['iPhone','Android','Mac','Windows'])assert.equal(training.filter(pod=>pod.device===device).length,25);
  assert.equal(await page.getByRole('button',{name:'Training pods ready',exact:true}).isDisabled(),true);
  await page.getByRole('button',{name:/Manage Pods/}).click();
  const trainingRow=page.locator('.aj-pod-row').filter({has:page.getByRole('textbox',{name:'Pod name Training Pod 001',exact:true})});
  await trainingRow.getByRole('button',{name:'Configure',exact:true}).click();
  await page.getByRole('dialog',{name:'Configure pod'}).getByText('pod-001@example.test',{exact:true}).waitFor();
  await page.getByRole('dialog',{name:'Configure pod'}).getByRole('button',{name:'Cancel',exact:true}).click();
  await nav('Solo Mode');
  const classroomRow=page.getByRole('row').filter({hasText:'Classroom 1'}).first();
  await classroomRow.getByRole('button',{name:'Edit',exact:true}).click();
  const profileEditor=page.getByRole('dialog',{name:'Edit browser profile'});
  await profileEditor.getByLabel('Starting website').fill('https://example.com/start');
  await profileEditor.getByRole('button',{name:'Save changes'}).click();
  await classroomRow.getByText('https://example.com/start',{exact:true}).waitFor();
  await classroomRow.getByRole('button',{name:'Backup',exact:true}).click();
  await page.getByRole('status').filter({hasText:'fixture-profile.zip'}).waitFor();
  await classroomRow.getByRole('checkbox').check();
  await page.getByRole('button',{name:'Power up',exact:true}).click();
  await page.getByRole('status').filter({hasText:'Browser state updated'}).waitFor();
  await page.getByRole('button',{name:'Active',exact:true}).click();
  await classroomRow.getByRole('button',{name:'Record',exact:true}).click();
  await nav('Overview');await nav('Solo Mode');
  const recorder=page.getByRole('region',{name:'Browser recorder'});
  await recorder.getByText(/recording · 0 actions/).waitFor();
  await recorder.getByRole('button',{name:'Stop recording',exact:true}).click();
  page.once('dialog',dialog=>dialog.accept());
  await recorder.getByRole('button',{name:'Open in Custom',exact:true}).click();
  assert.equal(await page.getByRole('textbox',{name:'Workflow name',exact:true}).inputValue(),'Recording · Classroom 1');
  assert.equal(await page.getByLabel('Starting URL',{exact:true}).inputValue(),'https://example.com/');
  await nav('Backup');
  await page.getByRole('button',{name:'Verify backup',exact:true}).click();
  await page.getByRole('status').filter({hasText:'2 files checked'}).waitFor();
  await nav('Overview');await page.getByRole('button',{name:'Activity',exact:true}).click();
  const history=page.getByRole('region',{name:'Run history',exact:true});
  await page.evaluate(()=>{
    const run={id:'run-fixture',workflowName:'Fixture workflow',profileId:'p1',source:'manual',status:'running',startedAt:Date.now(),totalSteps:3};
    window.testEmit('workflow-progress',{type:'run_started',run});
    window.testEmit('workflow-progress',{type:'step_started',runId:run.id,currentStep:2,totalSteps:3,step:{action:'navigate'}});
  });
  await history.getByText(/Step 2 of 3 · navigate/).waitFor();
  await page.evaluate(()=>{
    const run={id:'run-fixture',workflowName:'Fixture workflow',profileId:'p1',source:'manual',status:'completed',startedAt:Date.now(),steps:[{step:1,action:'navigate',ok:true,detail:'Fixture completed'}]};
    window.testHistory=[run];
    window.testEmit('workflow-progress',{type:'run_finished',run});
  });
  await history.getByLabel('Filter run history').selectOption('completed');
  await history.getByLabel('Search run history').fill('Fixture workflow');
  await history.getByText('Fixture workflow',{exact:true}).click();
  await history.getByText('Fixture completed',{exact:true}).waitFor();
  await page.getByRole('button',{name:'Web search',exact:true}).click();
  await page.getByRole('textbox',{name:'Search query',exact:true}).fill('Fixture');
  await page.getByRole('button',{name:'Research',exact:true}).click();
  page.once('dialog',dialog=>dialog.accept());
  await page.getByRole('button',{name:'Use in workflow',exact:true}).click();
  assert.equal(await page.getByLabel('Starting URL',{exact:true}).inputValue(),'https://example.com/research');
  assert.equal(errors.length,0,errors.join('\n'));
  console.log('PASS: native session command sequence, stop, navigation persistence, profile exclusion, proxy restoration, temporary profile cleanup, approval gate and credential boundary.');
}finally{await browser.close();await server.close();}
