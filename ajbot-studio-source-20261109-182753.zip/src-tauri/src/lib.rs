use std::ffi::c_void;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashMap;
use std::{
    fs,
    sync::Arc,
    thread,
    time::{Duration, SystemTime, UNIX_EPOCH},
    io::{BufRead, BufReader, Write},
    sync::atomic::{AtomicU64, Ordering},
    sync::mpsc::{self, Sender},
    path::{Path, PathBuf},
    process::{Child, ChildStdin, Command, Stdio},
    sync::Mutex,
};
use tauri::{Emitter, Manager, State};
use zip::{ZipArchive, ZipWriter, write::SimpleFileOptions};
#[cfg(windows)]
#[repr(C)]
struct DataBlob {
    cb_data: u32,
    pb_data: *mut u8,
}

#[cfg(windows)]
#[link(name = "Crypt32")]
unsafe extern "system" {
    fn CryptProtectData(
        input: *const DataBlob,
        description: *const u16,
        entropy: *const DataBlob,
        reserved: *mut c_void,
        prompt: *mut c_void,
        flags: u32,
        output: *mut DataBlob,
    ) -> i32;

    fn CryptUnprotectData(
        input: *const DataBlob,
        description: *mut *mut u16,
        entropy: *const DataBlob,
        reserved: *mut c_void,
        prompt: *mut c_void,
        flags: u32,
        output: *mut DataBlob,
    ) -> i32;
}

#[cfg(windows)]
#[link(name = "Kernel32")]
unsafe extern "system" {
    fn LocalFree(memory: *mut c_void) -> *mut c_void;
}

#[cfg(windows)]
fn protect_proxy_password(password: &str) -> Result<Vec<u8>, String> {
    let input_bytes = password.as_bytes();

    let input = DataBlob {
        cb_data: input_bytes.len() as u32,
        pb_data: input_bytes.as_ptr() as *mut u8,
    };

    let mut output = DataBlob {
        cb_data: 0,
        pb_data: std::ptr::null_mut(),
    };

    let success = unsafe {
        CryptProtectData(
            &input,
            std::ptr::null(),
            std::ptr::null(),
            std::ptr::null_mut(),
            std::ptr::null_mut(),
            0,
            &mut output,
        )
    };

    if success == 0 || output.pb_data.is_null() {
        return Err("Windows could not encrypt the proxy password.".into());
    }

    let encrypted = unsafe {
        std::slice::from_raw_parts(
            output.pb_data,
            output.cb_data as usize,
        )
        .to_vec()
    };

    unsafe {
        LocalFree(output.pb_data as *mut c_void);
    }

    Ok(encrypted)
}

#[cfg(windows)]
fn unprotect_proxy_password(encrypted: &[u8]) -> Result<String, String> {
    let input = DataBlob {
        cb_data: encrypted.len() as u32,
        pb_data: encrypted.as_ptr() as *mut u8,
    };

    let mut output = DataBlob {
        cb_data: 0,
        pb_data: std::ptr::null_mut(),
    };

    let success = unsafe {
        CryptUnprotectData(
            &input,
            std::ptr::null_mut(),
            std::ptr::null(),
            std::ptr::null_mut(),
            std::ptr::null_mut(),
            0,
            &mut output,
        )
    };

    if success == 0 || output.pb_data.is_null() {
        return Err("Windows could not decrypt the proxy password.".into());
    }

    let password = unsafe {
        String::from_utf8(
            std::slice::from_raw_parts(
                output.pb_data,
                output.cb_data as usize,
            )
            .to_vec(),
        )
    }
    .map_err(|_| "The decrypted proxy password is invalid.".to_string());

    unsafe {
        LocalFree(output.pb_data as *mut c_void);
    }

    password
}
struct WorkerConnection {
    child: Child,
    stdin: Arc<Mutex<ChildStdin>>,
    pending: Arc<Mutex<HashMap<u64, Sender<WorkerResponse>>>>,
    next_id: AtomicU64,
}

impl Drop for WorkerConnection {
    fn drop(&mut self) {
        if let Ok(mut stdin) = self.stdin.lock() {
            let _ = stdin.write_all(b"{\"id\":0,\"action\":\"shutdown\"}\n");
            let _ = stdin.flush();
        }
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

#[derive(Clone)]
struct WorkerState {
    connection: Arc<Mutex<Option<WorkerConnection>>>,
    app: Arc<Mutex<Option<tauri::AppHandle>>>,
}

#[derive(Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct ScheduledMember {
    profile_id: String,
    device_class: Option<String>,
}

#[derive(Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct ScheduledJob {
    id: String,
    name: String,
    workflow_id: String,
    profile_id: String,
    #[serde(default)]
    pod_id: Option<String>,
    #[serde(default)]
    members: Vec<ScheduledMember>,
    #[serde(default)]
    proxy_id: Option<String>,
    repeat: String,
    scheduled_at: u64,
    next_run_at: u64,
    enabled: bool,
    #[serde(default)]
    running: bool,
    #[serde(default)]
    last_run_at: Option<u64>,
    #[serde(default)]
    last_status: Option<String>,
    #[serde(default)]
    last_message: Option<String>,
    created_at: u64,
}

#[derive(Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct ScheduledRun {
    id: String,
    schedule_id: String,
    schedule_name: String,
    workflow_id: String,
    profile_id: String,
    started_at: u64,
    finished_at: u64,
    status: String,
    message: String,
}

#[derive(Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
struct SchedulerData {
    #[serde(default)]
    schedules: Vec<ScheduledJob>,
    #[serde(default)]
    runs: Vec<ScheduledRun>,
}

#[derive(Clone)]
struct SchedulerState {
    data: Arc<Mutex<SchedulerData>>,
    file: PathBuf,
}

fn now_ms() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() as u64
}

fn save_scheduler_data(state: &SchedulerState) -> Result<(), String> {
    let data = state.data.lock().map_err(|e| e.to_string())?;
    if let Some(parent) = state.file.parent() {
        fs::create_dir_all(parent).map_err(|e| format!("Could not create scheduler data folder: {e}"))?;
    }
    let temp = state.file.with_extension("json.tmp");
    fs::write(&temp, serde_json::to_vec_pretty(&*data).map_err(|e| e.to_string())?)
        .map_err(|e| format!("Could not write scheduler data: {e}"))?;
    fs::rename(&temp, &state.file).map_err(|e| format!("Could not replace scheduler data: {e}"))?;
    Ok(())
}

fn load_scheduler_data(file: &PathBuf) -> SchedulerData {
    let mut data = fs::read_to_string(file).ok()
        .and_then(|raw| serde_json::from_str::<SchedulerData>(&raw).ok())
        .unwrap_or_default();
    let now = now_ms();
    for job in &mut data.schedules {
        job.running = false;
        if job.enabled && job.next_run_at <= now {
            match job.repeat.as_str() {
                "daily" | "weekly" => {
                    let interval = if job.repeat == "daily" { 86_400_000 } else { 604_800_000 };
                    while job.next_run_at <= now {
                        job.next_run_at = job.next_run_at.saturating_add(interval);
                    }
                    job.last_status = Some("missed_skipped".into());
                    job.last_message = Some("Missed occurrences while Ajbot Studio was closed were skipped; the next occurrence is scheduled.".into());
                }
                _ => {
                    job.enabled = false;
                    job.last_status = Some("missed_skipped".into());
                    job.last_message = Some("This one-time schedule passed while Ajbot Studio was closed and was not run.".into());
                }
            }
        }
    }
    data
}

fn run_scheduled_job(worker: &WorkerState, job: &ScheduledJob) -> (&'static str, String) {
    let is_group = !job.members.is_empty();
    let members = if is_group { job.members.clone() } else {
        vec![ScheduledMember { profile_id: job.profile_id.clone(), device_class: None }]
    };
    for (index, member) in members.iter().enumerate() {
        let result = (|| -> Result<WorkerResponse, String> {
            let proxy = match &job.proxy_id {
                Some(id) => proxy_config(id)?,
                None => assigned_proxy_config(&member.profile_id)?,
            };
            let launched = match send_worker_request_options(
                worker, "launch", Some(member.profile_id.clone()), None, None,
                None, None, None, None, None, None, None, None, None, proxy,
                Some(serde_json::json!({ "deviceClass": member.device_class })),
            ) {
                Ok(_) => true,
                Err(error) if !is_group && error.to_ascii_lowercase().contains("already running") => false,
                Err(error) => return Err(error),
            };
            let result = send_worker_request(
                worker, "runWorkflowScheduled", Some(member.profile_id.clone()), None, None,
                Some(job.workflow_id.clone()), None, None, None, None, None, None, Some(false),
            );
            if is_group && launched {
                send_worker_request(
                    worker, "close", Some(member.profile_id.clone()), None, None,
                    None, None, None, None, None, None, None, None,
                )?;
            }
            result
        })();
        let (status, message) = match result {
            Ok(response) if response.ok => ("completed", response.message.unwrap_or_else(|| "Scheduled workflow finished.".into())),
            Ok(response) => {
                let needs_approval = response.results.as_ref().and_then(Value::as_array)
                    .is_some_and(|items| items.iter().any(|item| item.get("requiresApproval").and_then(Value::as_bool) == Some(true)));
                (if needs_approval { "needs_approval" } else { "failed" },
                    response.message.or(response.error).unwrap_or_else(|| "Scheduled workflow stopped.".into()))
            }
            Err(error) => ("failed", error),
        };
        if !is_group { return (status, message); }
        if status != "completed" {
            return (status, format!("Profile {}/{}: {message}", index + 1, members.len()));
        }
    }
    ("completed", format!("Scheduled workflow completed on {} pod profiles.", members.len()))
}

fn start_scheduler(worker: WorkerState, scheduler: SchedulerState, app: tauri::AppHandle) {
    thread::spawn(move || loop {
        let now = now_ms();
        let due = {
            let mut data = match scheduler.data.lock() { Ok(v) => v, Err(_) => { thread::sleep(Duration::from_secs(10)); continue; } };
            let mut due = Vec::new();
            for job in &mut data.schedules {
                if job.enabled && !job.running && job.next_run_at <= now {
                    job.running = true;
                    due.push(job.clone());
                }
            }
            drop(data);
            let _ = save_scheduler_data(&scheduler);
            due
        };

        for job in due {
            let started = now_ms();
            let _ = app.emit("scheduler-updated", serde_json::json!({ "scheduleId": job.id, "status": "running" }));
            let (status, message) = run_scheduled_job(&worker, &job);
            let finished = now_ms();
            if let Ok(mut data) = scheduler.data.lock() {
                if let Some(saved) = data.schedules.iter_mut().find(|item| item.id == job.id) {
                    saved.running = false;
                    saved.last_run_at = Some(started);
                    saved.last_status = Some(status.into());
                    saved.last_message = Some(message.clone());
                    match saved.repeat.as_str() {
                        "daily" => {
                            saved.next_run_at = saved.next_run_at.saturating_add(86_400_000);
                            while saved.next_run_at <= finished { saved.next_run_at = saved.next_run_at.saturating_add(86_400_000); }
                        }
                        "weekly" => {
                            saved.next_run_at = saved.next_run_at.saturating_add(604_800_000);
                            while saved.next_run_at <= finished { saved.next_run_at = saved.next_run_at.saturating_add(604_800_000); }
                        }
                        _ => { saved.enabled = false; }
                    }
                }
                data.runs.insert(0, ScheduledRun {
                    id: format!("scheduled-run-{started}"), schedule_id: job.id.clone(), schedule_name: job.name.clone(),
                    workflow_id: job.workflow_id.clone(), profile_id: job.profile_id.clone(), started_at: started,
                    finished_at: finished, status: status.into(), message: message.clone(),
                });
                data.runs.truncate(200);
            }
            let _ = save_scheduler_data(&scheduler);
            let _ = app.emit("scheduler-updated", serde_json::json!({ "scheduleId": job.id, "status": status, "message": message }));
        }
        thread::sleep(Duration::from_secs(10));
    });
}


#[derive(Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct WorkflowStep {
    action: String,

    #[serde(default)]
    url: Option<String>,

    #[serde(default)]
    selector: Option<String>,

    #[serde(default)]
    value: Option<String>,

    #[serde(default)]
    key: Option<String>,

    #[serde(default)]
    role: Option<String>,

    #[serde(default)]
    label: Option<String>,

    #[serde(default)]
    direction: Option<String>,

    #[serde(default)]
    duration_ms: Option<u64>,

    #[serde(default)]
    amount: Option<u32>,

    #[serde(default)]
    state: Option<String>,

    #[serde(default)]
    index: Option<usize>,

    #[serde(default)]
    full_page: Option<bool>,

    #[serde(default)]
    requires_approval: bool,

    #[serde(default)]
    risk_reason: Option<String>,
    // Preserve Batch 3 workflow fields (variables, branches, retries) losslessly.
    #[serde(flatten)]
    extra: HashMap<String, Value>,
}

#[derive(Serialize)]
struct WorkerRequest {
    id: u64,
    action: String,

    #[serde(rename = "profileId")]
    profile_id: Option<String>,

    name: Option<String>,
    url: Option<String>,

    #[serde(rename = "workflowId")]
    workflow_id: Option<String>,

    #[serde(rename = "workflowName")]
    workflow_name: Option<String>,

    steps: Option<Vec<WorkflowStep>>,
    task: Option<String>,
    provider: Option<String>,
    model: Option<String>,

    #[serde(rename = "apiKey")]
    api_key: Option<String>,

    #[serde(rename = "approveConsequential")]
    approve_consequential: Option<bool>,

    #[serde(rename = "stepMode")]
    step_mode: Option<bool>,

        proxy: Option<Value>,
    #[serde(rename = "agentOptions")]
    agent_options: Option<Value>,

    #[serde(rename = "runSource")]
    run_source: Option<String>,
}

#[derive(Deserialize)]
struct WorkerResponse {
    id: Option<u64>,
    status: Option<String>,
    ok: bool,
    error: Option<String>,
    profile: Option<Value>,
    profiles: Option<Value>,
    workflow: Option<Value>,
    workflows: Option<Value>,
    results: Option<Value>,
    result: Option<Value>,
    message: Option<String>,
    plan: Option<Value>,
    event: Option<String>,
    data: Option<Value>,
    runs: Option<Value>,
}

fn send_worker_request(
    state: &WorkerState,
    action: &str,
    profile_id: Option<String>,
    name: Option<String>,
    url: Option<String>,
    workflow_id: Option<String>,
    workflow_name: Option<String>,
    steps: Option<Vec<WorkflowStep>>,
    task: Option<String>,
    provider: Option<String>,
    model: Option<String>,
    api_key: Option<String>,
    approve_consequential: Option<bool>,
) -> Result<WorkerResponse, String> {
    send_worker_request_mode(
    state, action, profile_id, name, url, workflow_id, workflow_name,
    steps, task, provider, model, api_key, approve_consequential, None, None
    )
}

fn send_worker_request_mode(
    state: &WorkerState, action: &str, profile_id: Option<String>, name: Option<String>,
    url: Option<String>, workflow_id: Option<String>, workflow_name: Option<String>,
    steps: Option<Vec<WorkflowStep>>, task: Option<String>, provider: Option<String>,
    model: Option<String>, api_key: Option<String>, approve_consequential: Option<bool>,
    step_mode: Option<bool>, proxy: Option<Value>
) -> Result<WorkerResponse, String> {
    send_worker_request_options(state, action, profile_id, name, url, workflow_id, workflow_name,
        steps, task, provider, model, api_key, approve_consequential, step_mode, proxy, None)
}

fn send_worker_request_options(
    state: &WorkerState, action: &str, profile_id: Option<String>, name: Option<String>,
    url: Option<String>, workflow_id: Option<String>, workflow_name: Option<String>,
    steps: Option<Vec<WorkflowStep>>, task: Option<String>, provider: Option<String>,
    model: Option<String>, api_key: Option<String>, approve_consequential: Option<bool>,
    step_mode: Option<bool>, proxy: Option<Value>, agent_options: Option<Value>
) -> Result<WorkerResponse, String> {
    let (stdin, pending, request_id) = {
        let mut slot = state.connection.lock().map_err(|e| e.to_string())?;
        if slot.is_none() {
            let worker_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                .parent().ok_or("Could not locate project root")?
                .join("browser-worker").join("worker.cjs");
            let profiles_root = browser_profiles_root()?;
let mut child = Command::new("node")
    .arg(worker_path)
    .env("AJBOT_PROFILES_DIR", &profiles_root)                .stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::inherit())
                .spawn().map_err(|e| format!("Could not start browser worker: {e}"))?;
            let stdin = child.stdin.take().ok_or("Could not open worker input")?;
            let stdout = child.stdout.take().ok_or("Could not open worker output")?;
            let stdin = Arc::new(Mutex::new(stdin));
            let pending: Arc<Mutex<HashMap<u64, Sender<WorkerResponse>>>> = Arc::new(Mutex::new(HashMap::new()));
            let reader_pending = pending.clone();
            let event_app = state.app.clone();
            thread::spawn(move || {
                let reader = BufReader::new(stdout);
                for line in reader.lines() {
                    let Ok(line) = line else { break };
                    let Ok(response) = serde_json::from_str::<WorkerResponse>(&line) else { continue };
                    if let (Some(event), Some(data)) = (response.event.as_deref(), response.data.as_ref()) {
                        if matches!(event, "workflow-progress" | "recorder-event" | "ai-agent-progress") {
                            if let Some(app) = event_app.lock().ok().and_then(|slot| slot.as_ref().cloned()) {
                                let _ = app.emit(event, data.clone());
                                #[cfg(desktop)]
                                if event == "ai-agent-progress"
                                    && data.get("status").and_then(Value::as_str) == Some("needs_approval")
                                {
                                    if let Some(window) = app.get_webview_window("main") {
                                        let _ = window.unminimize();
                                        let _ = window.set_focus();
                                    }
                                }
                            }
                        }
                        continue;
                    }
                    if let Some(id) = response.id {
                        if let Ok(mut map) = reader_pending.lock() {
                            if let Some(tx) = map.remove(&id) { let _ = tx.send(response); }
                        }
                    }
                }
                if let Ok(mut map) = reader_pending.lock() { map.clear(); }
            });
            *slot = Some(WorkerConnection { child, stdin, pending, next_id: AtomicU64::new(0) });
        }
        let connection = slot.as_ref().ok_or("Browser worker is unavailable")?;
        (connection.stdin.clone(), connection.pending.clone(), connection.next_id.fetch_add(1, Ordering::Relaxed) + 1)
    };
    let request = WorkerRequest {
    id: request_id,
    action: action.to_string(),
    profile_id,
    name,
    url,
    workflow_id,
    workflow_name,
    steps,
    task,
    provider,
    model,
    api_key,
    approve_consequential,
    step_mode,
    proxy,
    agent_options,
    run_source: Some(
        if action == "runWorkflowScheduled" {
            "scheduled".into()
        } else {
            "manual".into()
        }
    ),
};
 let mut line = serde_json::to_string(&request).map_err(|e| e.to_string())?;
    line.push('\n');
    let (tx, rx) = mpsc::channel();
    pending.lock().map_err(|e| e.to_string())?.insert(request_id, tx);
    {
        let mut writer = stdin.lock().map_err(|e| e.to_string())?;
        if let Err(error) = writer.write_all(line.as_bytes()).and_then(|_| writer.flush()) {
            pending.lock().ok().map(|mut map| map.remove(&request_id));
            return Err(format!("Could not send worker request: {error}"));
        }
    }
    let response = rx.recv_timeout(Duration::from_secs(60 * 60))
        .map_err(|_| "Timed out waiting for the browser worker response.".to_string())?;
    if !response.ok && !matches!(action, "runWorkflow" | "runWorkflowScheduled") {
        return Err(response.error.unwrap_or_else(|| "Worker request failed.".into()));
    }
    Ok(response)
}

fn request(
    state: &WorkerState,
    action: &str,
    profile_id: Option<String>,
    name: Option<String>,
    url: Option<String>,
    workflow_id: Option<String>,
    workflow_name: Option<String>,
    steps: Option<Vec<WorkflowStep>>,
) -> Result<WorkerResponse, String> {
    send_worker_request(
        state,
        action,
        profile_id,
        name,
        url,
        workflow_id,
        workflow_name,
        steps,
        None,
        None,
        None,
        None,
        None,
    )
}

#[tauri::command]
fn search_web(
    query: String,
    provider: Option<String>,
) -> Result<Value, String> {
    let query = query.trim();

    if query.is_empty() || query.chars().count() > 600 {
        return Err(
            "Enter a search query between 1 and 600 characters.".into()
        );
    }

    let provider = provider
        .unwrap_or_else(|| "all".to_string())
        .trim()
        .to_ascii_lowercase();

    if !["all", "google", "brave", "bing"].contains(&provider.as_str()) {
        return Err("Choose All engines, Google, Brave, or Bing.".into());
    }

    let script_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or("Could not locate project root")?
        .join("browser-worker")
        .join("search.cjs");

    let mut child = Command::new("node")
        .arg(script_path)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| {
            format!("Could not start the search service with Node.js: {e}")
        })?;

    {
        let mut stdin = child.stdin.take()
            .ok_or("Could not open search-service input")?;

        let request = serde_json::json!({
            "query": query,
            "provider": provider
        });

        serde_json::to_writer(&mut stdin, &request)
            .map_err(|e| format!("Could not prepare search request: {e}"))?;

        stdin.write_all(b"\n")
            .map_err(|e| format!("Could not send search request: {e}"))?;
    }

    let output = child.wait_with_output()
        .map_err(|e| format!("Could not read search-service response: {e}"))?;

    if !output.status.success() {
        let message = String::from_utf8_lossy(&output.stderr)
            .trim()
            .to_string();

        return Err(if message.is_empty() {
            "Web research failed. Check Node.js and your search provider configuration.".into()
        } else {
            message.chars().take(500).collect()
        });
    }

    let payload: Value = serde_json::from_slice(&output.stdout)
        .map_err(|_| {
            "The research service returned an invalid response.".to_string()
        })?;

    if !payload.is_object() {
        return Err(
            "The research service returned an unexpected response.".into()
        );
    }

    Ok(payload)
}

#[tauri::command]
fn check_node() -> Result<String, String> {
    let output = Command::new("node")
        .arg("--version")
        .output()
        .map_err(|e| format!("Could not start Node.js: {e}"))?;

    if output.status.success() {
        Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
    } else {
        Err(String::from_utf8_lossy(&output.stderr).trim().to_string())
    }
}

// Read-only engine diagnostics and bounded site discovery run away from the UI thread.
fn studio_helper(script: &str, argument: &str) -> Result<Value, String> {
    let path = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("..").join("browser-worker").join(script);
    let output = Command::new("node").arg(path).arg(argument).output()
        .map_err(|e| format!("Could not start Node.js. Install Node.js 20 or newer, restart the app, then retry. {e}"))?;
    if !output.status.success() { return Err(String::from_utf8_lossy(&output.stderr).chars().take(1000).collect()); }
    serde_json::from_slice(&output.stdout).map_err(|e| format!("Invalid engine response: {e}"))
}
#[tauri::command]
async fn verify_browser_engine() -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(|| studio_helper("engine.cjs", "verify")).await
        .map_err(|e| format!("Engine check failed: {e}"))?
}
#[tauri::command]
async fn repair_browser_engine() -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(|| studio_helper("engine.cjs", "repair")).await
        .map_err(|e| format!("Engine repair failed: {e}"))?
}
#[tauri::command]
async fn discover_site_pages(url: String) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || studio_helper("site-pages.cjs", &url)).await
        .map_err(|e| format!("Site discovery failed: {e}"))?
}
#[tauri::command]
async fn device_country() -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(|| {
        #[cfg(windows)] {
            let output = Command::new("powershell.exe").args(["-NoProfile", "-NonInteractive", "-Command", "[System.Globalization.RegionInfo]::CurrentRegion.TwoLetterISORegionName"]).output()
                .map_err(|e| format!("Device region unavailable: {e}"))?;
            let country = String::from_utf8_lossy(&output.stdout).trim().to_uppercase();
            if output.status.success() && country.len() == 2 && country.bytes().all(|b| b.is_ascii_uppercase()) { Ok(country) }
            else { Err("Device region is unavailable. Enter your country code.".to_string()) }
        }
        #[cfg(not(windows))] { Ok(String::new()) }
    }).await.map_err(|e| format!("Region detection failed: {e}"))?
}

const AUTOMATIC_BACKUP_TASK: &str = "Ajbot Studio Automatic Profile Backup";
const DEFAULT_BACKUP_RETENTION: usize = 7;
const MAX_BACKUP_HISTORY: usize = 200;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct AutomaticBackupSettings {
    enabled: bool,
    schedule: String,
    time: String,
    backup_directory: String,
    retention_count: usize,
}

impl Default for AutomaticBackupSettings {
    fn default() -> Self {
        Self {
            enabled: false,
            schedule: "daily".into(),
            time: "02:00".into(),
            backup_directory: String::new(),
            retention_count: DEFAULT_BACKUP_RETENTION,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct AutomaticBackupRecord {
    profile_id: String,
    profile_name: String,
    status: String,
    message: String,
    backup_path: Option<String>,
    created_at: u64,
    bytes: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
struct AutomaticBackupData {
    settings: AutomaticBackupSettings,
    history: Vec<AutomaticBackupRecord>,
}

const MAX_BACKUP_ENTRIES: usize = 100_000;
const MAX_BACKUP_UNCOMPRESSED: u64 = 20 * 1024 * 1024 * 1024;
const MAX_BACKUP_FILE: u64 = 4 * 1024 * 1024 * 1024;
const MAX_BACKUP_ARCHIVE: u64 = 4 * 1024 * 1024 * 1024;
const MAX_MANIFEST_SIZE: u64 = 64 * 1024;
const MAX_PROFILE_METADATA_SIZE: u64 = 1024 * 1024;

static PROFILE_IO_COUNTER: AtomicU64 = AtomicU64::new(1);

fn next_profile_io_id() -> u64 {
    PROFILE_IO_COUNTER.fetch_add(1, Ordering::Relaxed)
}

fn validate_profile_id(profile_id: &str) -> Result<(), String> {
    if profile_id.is_empty()
        || profile_id.len() > 128
        || !profile_id
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
    {
        return Err("The browser profile ID is invalid.".into());
    }

    Ok(())
}


fn browser_profiles_root() -> Result<PathBuf, String> {
    let data_root = if let Some(path) = std::env::var_os("LOCALAPPDATA") {
        PathBuf::from(path).join("com.ajbot.studio")
    } else if let Some(path) = std::env::var_os("HOME") {
        PathBuf::from(path).join(".local").join("share").join("com.ajbot.studio")
    } else {
        return Err("Could not locate the application data directory.".into());
    };

    fs::create_dir_all(&data_root)
        .map_err(|e| format!("Could not create application data directory: {e}"))?;

    let destination = data_root.join("profiles");
    let marker = data_root.join("profiles-migration-v1.complete");

    if marker.exists() {
        if !destination.is_dir() {
            return Err("Profile migration marker exists, but profile storage is missing. Original profiles have not been deleted.".into());
        }

        return destination.canonicalize()
            .map_err(|e| format!("Could not access profile storage: {e}"));
    }

    let source = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or("Could not locate the project directory")?
        .join("browser-worker")
        .join("profiles");

    if destination.exists() {
        let mut entries = fs::read_dir(&destination)
            .map_err(|e| format!("Could not inspect destination profiles: {e}"))?;

        if entries.next().is_some() {
            return Err(
                "Profile storage already contains data but has no migration marker. \
                Nothing was overwritten. Please resolve the storage conflict before continuing."
                .into()
            );
        }

        fs::remove_dir(&destination)
            .map_err(|e| format!("Could not prepare profile storage: {e}"))?;
    }

    let staging = data_root.join(format!(
        "profiles-migration-{}",
        PROFILE_IO_COUNTER.fetch_add(1, Ordering::Relaxed)
    ));

    if source.is_dir() {
        let source_stats = copy_profile_tree(&source, &staging)?;
        let copied_stats = inspect_profile_tree(&staging)?;

        if source_stats != copied_stats {
            let _ = fs::remove_dir_all(&staging);
            return Err("Profile migration verification failed. Original profiles remain untouched.".into());
        }
    } else {
        fs::create_dir_all(&staging)
            .map_err(|e| format!("Could not create profile storage: {e}"))?;
    }

    fs::rename(&staging, &destination)
        .map_err(|e| {
            let _ = fs::remove_dir_all(&staging);
            format!("Could not activate migrated profile storage: {e}")
        })?;

    fs::write(&marker, b"version=1\n")
        .map_err(|e| format!("Profiles were copied, but the migration marker could not be written: {e}"))?;

    destination.canonicalize()
        .map_err(|e| format!("Could not access profile storage: {e}"))
}

#[derive(Serialize, Deserialize, Default)]
struct ProxyStore {
    proxies: Vec<StoredProxy>,
}

#[derive(Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct StoredProxy {
    id: String,
    name: String,
    server: String,
    username: Option<String>,
    encrypted_password: Option<String>,
}

#[derive(Serialize, Deserialize, Default)]
struct ProxyAssignments {
    assignments: HashMap<String, String>,
}

fn proxy_data_path(filename: &str) -> Result<PathBuf, String> {
    let profiles = browser_profiles_root()?;
    let root = profiles
        .parent()
        .ok_or("Could not locate application data directory.")?;

    Ok(root.join(filename))
}

fn load_proxy_store() -> Result<ProxyStore, String> {
    let path = proxy_data_path("proxies.json")?;

    if !path.exists() {
        return Ok(ProxyStore::default());
    }

    let content = fs::read_to_string(path)
        .map_err(|e| format!("Could not read proxy storage: {e}"))?;

    serde_json::from_str(&content)
        .map_err(|e| format!("Proxy storage is invalid: {e}"))
}

fn save_proxy_store(store: &ProxyStore) -> Result<(), String> {
    let path = proxy_data_path("proxies.json")?;
    let temporary = path.with_extension("json.tmp");

    let content = serde_json::to_string_pretty(store)
        .map_err(|e| e.to_string())?;

    fs::write(&temporary, content)
        .map_err(|e| format!("Could not write proxy storage: {e}"))?;

    fs::rename(&temporary, &path)
        .map_err(|e| format!("Could not save proxy storage: {e}"))?;

    Ok(())
}

fn load_proxy_assignments() -> Result<ProxyAssignments, String> {
    let path = proxy_data_path("proxy-assignments.json")?;

    if !path.exists() {
        return Ok(ProxyAssignments::default());
    }

    let content = fs::read_to_string(path)
        .map_err(|e| format!("Could not read proxy assignments: {e}"))?;

    serde_json::from_str(&content)
        .map_err(|e| format!("Proxy assignments are invalid: {e}"))
}

fn save_proxy_assignments(
    assignments: &ProxyAssignments,
) -> Result<(), String> {
    let path = proxy_data_path("proxy-assignments.json")?;
    let temporary = path.with_extension("json.tmp");

    let content = serde_json::to_string_pretty(assignments)
        .map_err(|e| e.to_string())?;

    fs::write(&temporary, content)
        .map_err(|e| format!("Could not write proxy assignments: {e}"))?;

    fs::rename(&temporary, &path)
        .map_err(|e| format!("Could not save proxy assignments: {e}"))?;

    Ok(())
}

fn valid_proxy_id(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 80
        && id.chars().all(|c| {
            c.is_ascii_alphanumeric() || c == '-' || c == '_'
        })
}

fn validate_proxy_server(server: &str) -> Result<(), String> {
    let server = server.trim();

    let authority = if let Some(value) = server.strip_prefix("http://") {
        value
    } else if let Some(value) = server.strip_prefix("https://") {
        value
    } else if let Some(value) = server.strip_prefix("socks5://") {
        value
    } else {
        return Err(
            "Proxy must use http://, https:// or socks5://.".into()
        );
    };

    if authority.is_empty()
        || authority.contains('@')
        || authority.contains(char::is_whitespace)
        || authority.contains('/')
        || authority.contains('?')
        || authority.contains('#')
    {
        return Err("Proxy server address is invalid.".into());
    }

    let (_, port) = authority
        .rsplit_once(':')
        .ok_or("Proxy server must include a port.")?;

    let port: u16 = port
        .parse()
        .map_err(|_| "Proxy port must be between 1 and 65535.")?;

    if port == 0 {
        return Err("Proxy port must be between 1 and 65535.".into());
    }

    Ok(())
}

fn proxy_public_value(proxy: &StoredProxy) -> Value {
    serde_json::json!({
        "id": proxy.id,
        "name": proxy.name,
        "server": proxy.server,
        "username": proxy.username,
        "hasPassword": proxy.encrypted_password.is_some()
    })
}

fn assigned_proxy_config(profile_id: &str) -> Result<Option<Value>, String> {
    let assignments = load_proxy_assignments()?;

    let Some(proxy_id) = assignments.assignments.get(profile_id) else {
        return Ok(None);
    };

    proxy_config(proxy_id)
}

fn proxy_config(proxy_id: &str) -> Result<Option<Value>, String> {
    let store = load_proxy_store()?;
    let proxy = store.proxies
        .iter()
        .find(|proxy| proxy.id == proxy_id)
        .ok_or("The selected proxy no longer exists.")?;

    let password = match &proxy.encrypted_password {
        Some(encrypted) => {
            let bytes = hex_decode(encrypted)?;
            Some(unprotect_proxy_password(&bytes)?)
        }
        None => None,
    };

    Ok(Some(serde_json::json!({
        "server": proxy.server,
        "username": proxy.username,
        "password": password
    })))
}

fn hex_encode(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";

    let mut output = String::with_capacity(bytes.len() * 2);

    for byte in bytes {
        output.push(HEX[(byte >> 4) as usize] as char);
        output.push(HEX[(byte & 0x0f) as usize] as char);
    }

    output
}

fn hex_decode(value: &str) -> Result<Vec<u8>, String> {
    if value.len() % 2 != 0 {
        return Err("Encrypted proxy password is invalid.".into());
    }

    let mut result = Vec::with_capacity(value.len() / 2);

    for pair in value.as_bytes().chunks_exact(2) {
        let high = (pair[0] as char)
            .to_digit(16)
            .ok_or("Encrypted proxy password is invalid.")?;

        let low = (pair[1] as char)
            .to_digit(16)
            .ok_or("Encrypted proxy password is invalid.")?;

        result.push(((high << 4) | low) as u8);
    }

    Ok(result)
}

#[tauri::command]
fn list_proxies() -> Result<Value, String> {
    let store = load_proxy_store()?;

    let proxies: Vec<Value> = store.proxies
        .iter()
        .map(proxy_public_value)
        .collect();

    Ok(Value::Array(proxies))
}

#[tauri::command]
fn save_proxy(
    id: String,
    name: String,
    server: String,
    username: Option<String>,
    password: Option<String>,
) -> Result<Value, String> {
    if !valid_proxy_id(&id) {
        return Err("Proxy ID is invalid.".into());
    }

    let name = name.trim();
    let server = server.trim();

    if name.is_empty() || name.len() > 80 {
        return Err("Proxy name must contain 1–80 characters.".into());
    }

    validate_proxy_server(server)?;

    let username = username
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty());

    if username.as_ref().is_some_and(|value| value.len() > 256) {
        return Err("Proxy username is too long.".into());
    }

    if password.as_ref().is_some_and(|value| value.len() > 1024) {
        return Err("Proxy password is too long.".into());
    }

    let mut store = load_proxy_store()?;

    let existing = store.proxies.iter().find(|proxy| proxy.id == id);

    let encrypted_password = match password {
        Some(value) if !value.is_empty() => {
            Some(hex_encode(&protect_proxy_password(&value)?))
        }
        _ => existing.and_then(|proxy| proxy.encrypted_password.clone()),
    };

    let proxy = StoredProxy {
        id: id.clone(),
        name: name.to_string(),
        server: server.to_string(),
        username,
        encrypted_password,
    };

    if let Some(index) = store.proxies.iter().position(|item| item.id == id) {
        store.proxies[index] = proxy.clone();
    } else {
        if store.proxies.len() >= 500 {
            return Err("The proxy list is limited to 500 entries.".into());
        }

        store.proxies.push(proxy.clone());
    }

    save_proxy_store(&store)?;

    Ok(proxy_public_value(&proxy))
}

#[tauri::command]
fn delete_proxy(id: String) -> Result<(), String> {
    let mut store = load_proxy_store()?;

    let original_length = store.proxies.len();
    store.proxies.retain(|proxy| proxy.id != id);

    if store.proxies.len() == original_length {
        return Err("Proxy not found.".into());
    }

    let mut assignments = load_proxy_assignments()?;
    assignments.assignments.retain(|_, proxy_id| proxy_id != &id);

    save_proxy_store(&store)?;
    save_proxy_assignments(&assignments)?;

    Ok(())
}

#[tauri::command]
fn assign_proxy_to_profile(
    profile_id: String,
    proxy_id: Option<String>,
) -> Result<(), String> {
    if !valid_proxy_id(&profile_id) {
        return Err("Browser profile ID is invalid.".into());
    }

    let profiles_root = browser_profiles_root()?;
    let profile_path = profiles_root.join(&profile_id);

    let metadata = fs::symlink_metadata(&profile_path)
        .map_err(|_| "Browser profile was not found.".to_string())?;

    if !metadata.is_dir() || metadata.file_type().is_symlink() {
        return Err("Browser profile directory is invalid.".into());
    }

    let mut assignments = load_proxy_assignments()?;

    if let Some(proxy_id) = proxy_id {
        if !valid_proxy_id(&proxy_id) {
            return Err("Proxy ID is invalid.".into());
        }

        let store = load_proxy_store()?;

        if !store.proxies.iter().any(|proxy| proxy.id == proxy_id) {
            return Err("Proxy not found.".into());
        }

        assignments.assignments.insert(profile_id, proxy_id);
    } else {
        assignments.assignments.remove(&profile_id);
    }

    save_proxy_assignments(&assignments)
}

#[tauri::command]
fn get_profile_proxy(profile_id: String) -> Result<Option<String>, String> {
    let assignments = load_proxy_assignments()?;
    Ok(assignments.assignments.get(&profile_id).cloned())
}

fn automatic_backup_data_file() -> Result<PathBuf, String> {
    let profiles_root = browser_profiles_root()?;

    let data_dir = profiles_root
        .parent()
        .ok_or("Could not locate Ajbot Studio data directory.")?;

    Ok(data_dir.join("automatic-backups.json"))
}

fn load_automatic_backup_data() -> AutomaticBackupData {
    let result = automatic_backup_data_file()
        .and_then(|path| {
            if !path.exists() {
                return Ok(AutomaticBackupData::default());
            }

            let bytes = fs::read(path)
                .map_err(|e| format!("Could not read backup settings: {e}"))?;

            serde_json::from_slice(&bytes)
                .map_err(|e| format!("Could not parse backup settings: {e}"))
        });

    result.unwrap_or_default()
}


fn save_automatic_backup_data(
    data: &AutomaticBackupData,
) -> Result<(), String> {
    let path = automatic_backup_data_file()?;

    let bytes = serde_json::to_vec_pretty(data)
        .map_err(|e| format!("Could not serialize backup settings: {e}"))?;

    let temporary = path.with_extension(format!(
        "json.tmp-{}",
        std::process::id()
    ));

    fs::write(&temporary, bytes)
        .map_err(|e| format!("Could not save backup settings: {e}"))?;

    if path.exists() {
        fs::remove_file(&path)
            .map_err(|e| format!("Could not replace backup settings: {e}"))?;
    }

    fs::rename(&temporary, &path)
        .map_err(|e| format!("Could not finalize backup settings: {e}"))?;

    Ok(())
}


#[cfg(windows)]
fn backup_process_is_running(pid: u32) -> Option<bool> {
    if pid == 0 {
        return None;
    }

    let output = std::process::Command::new("tasklist.exe")
        .args([
            "/FI",
            &format!("PID eq {pid}"),
            "/FO",
            "CSV",
            "/NH",
        ])
        .output()
        .ok()?;

    if !output.status.success() {
        return None;
    }

    let text = String::from_utf8_lossy(&output.stdout);

    if text.to_lowercase().contains("no tasks are running") {
        return Some(false);
    }

    Some(text.lines().any(|line| {
        let columns: Vec<&str> = line.split(',').collect();

        columns.get(1)
            .map(|value| value.trim().trim_matches('"') == pid.to_string())
            .unwrap_or(false)
    }))
}

#[cfg(windows)]
struct BackupProfileLock {
    path: PathBuf,
}

#[cfg(windows)]
impl Drop for BackupProfileLock {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.path);
    }
}

#[cfg(windows)]
fn acquire_automatic_backup_lock(
    profiles_root: &Path,
    profile_id: &str,
) -> Result<Option<BackupProfileLock>, String> {
    validate_profile_id(profile_id)?;

    let locks_root = profiles_root
        .parent()
        .ok_or("Could not locate profile lock directory.")?
        .join("profile-locks");

    fs::create_dir_all(&locks_root)
        .map_err(|e| format!("Could not create profile lock directory: {e}"))?;

    let lock_path = locks_root.join(format!("{profile_id}.lock"));

    if lock_path.exists() {
        let existing = fs::read(&lock_path)
            .map_err(|e| format!("Could not read existing profile lock: {e}"))?;

        let Some(pid) = serde_json::from_slice::<Value>(&existing)
            .ok()
            .and_then(|value| value.get("pid").and_then(Value::as_u64))
            .and_then(|value| u32::try_from(value).ok())
        else {
            // Unknown lock ownership: never remove an unreadable lock.
            return Ok(None);
        };

        match backup_process_is_running(pid) {
            Some(true) | None => return Ok(None),
            Some(false) => {
                fs::remove_file(&lock_path)
                    .map_err(|e| format!("Could not clear stale profile lock: {e}"))?;
            }
        }
    }

    let lock_data = serde_json::json!({
        "pid": std::process::id(),
        "profileId": profile_id,
        "createdAt": now_ms()
    });

    let bytes = serde_json::to_vec(&lock_data)
        .map_err(|e| format!("Could not create profile lock: {e}"))?;

    let mut file = match fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&lock_path)
    {
        Ok(file) => file,
        Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {
            return Ok(None);
        }
        Err(error) => {
            return Err(format!("Could not acquire profile lock: {error}"));
        }
    };

    if let Err(error) = file.write_all(&bytes).and_then(|_| file.sync_all()) {
        let _ = fs::remove_file(&lock_path);
        return Err(format!("Could not write profile lock: {error}"));
    }

    Ok(Some(BackupProfileLock { path: lock_path }))
}

fn automatic_backup_directory(
    settings: &AutomaticBackupSettings,
) -> Result<PathBuf, String> {
    let profiles_root = browser_profiles_root()?;
    let data_root = profiles_root
        .parent()
        .ok_or("Could not locate Ajbot Studio data directory.")?;

    let requested = if settings.backup_directory.trim().is_empty() {
        data_root.join("automatic-backups")
    } else {
        PathBuf::from(settings.backup_directory.trim())
    };

    fs::create_dir_all(&requested)
        .map_err(|e| format!("Could not create backup directory: {e}"))?;

    let directory = requested
        .canonicalize()
        .map_err(|e| format!("Could not verify backup directory: {e}"))?;

    let profiles_root = profiles_root
        .canonicalize()
        .map_err(|e| format!("Could not verify profiles directory: {e}"))?;

    if directory.starts_with(&profiles_root) {
        return Err(
            "Automatic backups must be stored outside the browser profiles folder.".into()
        );
    }

    Ok(directory)
}

fn prune_automatic_profile_backups(
    directory: &Path,
    profile_id: &str,
    retention_count: usize,
) -> Result<(), String> {
    let prefix = format!("ajbot-{profile_id}-");
    let mut backups: Vec<(String, PathBuf)> = Vec::new();

    for item in fs::read_dir(directory)
        .map_err(|e| format!("Could not read backup directory: {e}"))?
    {
        let item = item.map_err(|e| e.to_string())?;
        let path = item.path();

        let metadata = fs::symlink_metadata(&path)
            .map_err(|e| format!("Could not inspect backup entry: {e}"))?;

        if !metadata.is_file() || metadata.file_type().is_symlink() {
            continue;
        }

        let Some(name) = path.file_name().and_then(|value| value.to_str()) else {
            continue;
        };

        let Some(suffix) = name
            .strip_prefix(&prefix)
            .and_then(|value| value.strip_suffix(".zip"))
        else {
            continue;
        };

        // Automatic names must contain exactly two numeric parts:
        // timestamp and unique backup ID.
        let mut parts = suffix.split('-');

        let valid_timestamp = parts
            .next()
            .and_then(|value| value.parse::<u64>().ok())
            .is_some();

        let valid_id = parts
            .next()
            .and_then(|value| value.parse::<u64>().ok())
            .is_some();

        if valid_timestamp && valid_id && parts.next().is_none() {
            backups.push((name.to_string(), path));
        }
    }

    // Newest timestamped automatic backups first.
    backups.sort_by(|a, b| b.0.cmp(&a.0));

    for (_, old_path) in backups.into_iter().skip(retention_count) {
        fs::remove_file(&old_path)
            .map_err(|e| format!("Could not remove an old automatic backup: {e}"))?;
    }

    Ok(())
}

fn create_automatic_profile_backup(
    profile_id: &str,
    profile_dir: &Path,
    destination_dir: &Path,
) -> Result<(PathBuf, String, u64), String> {
    validate_profile_id(profile_id)?;

    let profile_meta = fs::symlink_metadata(profile_dir)
        .map_err(|_| "Browser profile directory is unavailable.")?;

    if !profile_meta.is_dir() || profile_meta.file_type().is_symlink() {
        return Err("Profile directory is not a safe local directory.".into());
    }

    let canonical_profile = profile_dir
        .canonicalize()
        .map_err(|e| format!("Could not verify profile directory: {e}"))?;

    let profiles_root = browser_profiles_root()?
        .canonicalize()
        .map_err(|e| format!("Could not verify profiles root: {e}"))?;

    if !canonical_profile.starts_with(&profiles_root) {
        return Err("Profile directory is outside the permitted storage location.".into());
    }

    let metadata_path = canonical_profile.join("profile.json");
    let metadata_info = fs::symlink_metadata(&metadata_path)
        .map_err(|_| "Profile metadata is missing.")?;

    if !metadata_info.is_file()
        || metadata_info.file_type().is_symlink()
        || metadata_info.len() > MAX_PROFILE_METADATA_SIZE
    {
        return Err("Profile metadata is not a valid or safe file.".into());
    }

    let metadata: Value = serde_json::from_slice(
        &fs::read(&metadata_path)
            .map_err(|e| format!("Could not read profile metadata: {e}"))?,
    )
    .map_err(|_| "Profile metadata contains invalid JSON.")?;

    if !metadata.is_object() {
        return Err("Profile metadata has an unexpected format.".into());
    }

    let profile_name = metadata
        .get("name")
        .and_then(Value::as_str)
        .unwrap_or(profile_id)
        .to_string();

    let created_at = now_ms();

    let manifest = serde_json::json!({
        "format": "ajbot-profile-backup",
        "version": 1,
        "createdAt": created_at,
        "profileId": profile_id,
        "profileName": profile_name,
        "startUrl": metadata.get("startUrl").cloned().unwrap_or(Value::Null),
        "app": "Ajbot Studio"
    });

    let manifest_bytes = serde_json::to_vec_pretty(&manifest)
        .map_err(|e| format!("Could not serialize backup manifest: {e}"))?;

    if manifest_bytes.len() as u64 > MAX_MANIFEST_SIZE {
        return Err("Backup manifest exceeds the allowed size.".into());
    }

    let destination_name = format!(
        "ajbot-{profile_id}-{created_at}-{}.zip",
        next_profile_io_id()
    );

    let destination = destination_dir.join(&destination_name);
    let temporary = destination_dir.join(format!(
        ".{destination_name}.tmp-{}",
        std::process::id()
    ));

    let result = (|| -> Result<u64, String> {
        let file = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary)
            .map_err(|e| format!("Could not create backup archive: {e}"))?;

        let mut writer = ZipWriter::new(file);
        let mut entry_count = 1usize;
        let mut total_size = manifest_bytes.len() as u64;

        writer
            .start_file("ajbot-backup.json", SimpleFileOptions::default())
            .map_err(|e| format!("Could not write backup manifest: {e}"))?;

        writer
            .write_all(&manifest_bytes)
            .map_err(|e| format!("Could not write backup manifest: {e}"))?;

        zip_directory(
            &mut writer,
            &canonical_profile,
            &canonical_profile,
            &mut entry_count,
            &mut total_size,
        )?;

        let finished = writer
            .finish()
            .map_err(|e| format!("Could not finish backup archive: {e}"))?;

        finished
            .sync_all()
            .map_err(|e| format!("Could not finalize backup archive: {e}"))?;

        let bytes = finished.metadata()
            .map_err(|e| format!("Could not inspect backup archive: {e}"))?
            .len();

        if bytes > MAX_BACKUP_ARCHIVE {
            return Err("Backup archive exceeds the 4 GB limit.".into());
        }

        drop(finished);

        // Reuse the same strict verifier as manual backup verification.
        let verification = verify_backup_file(&temporary)?;

        if verification.get("valid").and_then(Value::as_bool) != Some(true) {
            return Err("New backup did not pass verification.".into());
        }

        if destination.exists() {
            return Err("Backup destination already exists.".into());
        }

        fs::rename(&temporary, &destination)
            .map_err(|e| format!("Could not finalize backup: {e}"))?;

        Ok(bytes)
    })();

    match result {
        Ok(bytes) => Ok((destination, profile_name, bytes)),
        Err(error) => {
            let _ = fs::remove_file(&temporary);
            Err(error)
        }
    }
}

#[cfg(windows)]
pub fn run_backup_runner() -> Result<(), String> {
    let settings_file = automatic_backup_data_file()?;
    let mut data = load_automatic_backup_data();

    if !data.settings.enabled {
        return Ok(());
    }

    let profiles_root = browser_profiles_root()?;
    let canonical_root = profiles_root
        .canonicalize()
        .map_err(|e| format!("Could not access browser profiles: {e}"))?;

    let backup_dir = automatic_backup_directory(&data.settings)?;
    let retention = data.settings.retention_count.clamp(1, 100);

    let entries = fs::read_dir(&canonical_root)
        .map_err(|e| format!("Could not list browser profiles: {e}"))?;

    for entry in entries {
        let entry = match entry {
            Ok(entry) => entry,
            Err(_) => continue,
        };

        let profile_dir = entry.path();

        let metadata = match fs::symlink_metadata(&profile_dir) {
            Ok(metadata) => metadata,
            Err(_) => continue,
        };

        if !metadata.is_dir() || metadata.file_type().is_symlink() {
            continue;
        }

        let Some(profile_id) = profile_dir
            .file_name()
            .and_then(|value| value.to_str())
            .map(str::to_string)
        else {
            continue;
        };

        if validate_profile_id(&profile_id).is_err() {
            continue;
        }

        let profile_name = fs::read(profile_dir.join("profile.json"))
            .ok()
            .and_then(|bytes| serde_json::from_slice::<Value>(&bytes).ok())
            .and_then(|value| value.get("name").and_then(Value::as_str).map(str::to_string))
            .unwrap_or_else(|| profile_id.clone());

        let created_at = now_ms();

        let lock = match acquire_automatic_backup_lock(&canonical_root, &profile_id) {
            Ok(Some(lock)) => lock,
            Ok(None) => {
                data.history.insert(0, AutomaticBackupRecord {
                    profile_id,
                    profile_name,
                    status: "skipped".into(),
                    message: "Profile is currently in use; no backup was made.".into(),
                    backup_path: None,
                    created_at,
                    bytes: None,
                });

                data.history.truncate(MAX_BACKUP_HISTORY);
                let _ = save_automatic_backup_data(&data);
                continue;
            }
            Err(error) => {
                data.history.insert(0, AutomaticBackupRecord {
                    profile_id,
                    profile_name,
                    status: "failed".into(),
                    message: error,
                    backup_path: None,
                    created_at,
                    bytes: None,
                });

                data.history.truncate(MAX_BACKUP_HISTORY);
                let _ = save_automatic_backup_data(&data);
                continue;
            }
        };

        let outcome = create_automatic_profile_backup(
            &profile_id,
            &profile_dir,
            &backup_dir,
        );

        drop(lock);

        match outcome {
            Ok((path, name, bytes)) => {
                let prune_result = prune_automatic_profile_backups(
                    &backup_dir,
                    &profile_id,
                    retention,
                );

                data.history.insert(0, AutomaticBackupRecord {
                    profile_id,
                    profile_name: name,
                    status: if prune_result.is_ok() { "success" } else { "failed" }.into(),
                    message: prune_result.err().unwrap_or_else(|| {
                        "Backup created and verified successfully.".into()
                    }),
                    backup_path: Some(path.to_string_lossy().to_string()),
                    created_at,
                    bytes: Some(bytes),
                });
            }
            Err(error) => {
                data.history.insert(0, AutomaticBackupRecord {
                    profile_id,
                    profile_name,
                    status: "failed".into(),
                    message: error,
                    backup_path: None,
                    created_at,
                    bytes: None,
                });
            }
        }

        data.history.truncate(MAX_BACKUP_HISTORY);
        save_automatic_backup_data(&data)?;
    }

    // Ensure the settings/history file exists even if there were no profiles.
    if !settings_file.exists() {
        save_automatic_backup_data(&data)?;
    }

    Ok(())
}

#[cfg(not(windows))]
pub fn run_backup_runner() -> Result<(), String> {
    Err("The automatic backup runner is currently supported on Windows only.".into())
}

#[cfg(windows)]
fn update_automatic_backup_task(
    settings: &AutomaticBackupSettings,
)

-> Result<(), String> {
    if !settings.enabled {
        let output = std::process::Command::new("schtasks.exe")
            .args([
                "/Delete",
                "/TN",
                AUTOMATIC_BACKUP_TASK,
                "/F",
            ])
            .output()
            .map_err(|e| format!("Could not access Windows Task Scheduler: {e}"))?;

        // Deleting a task that does not exist is harmless.
        let message = String::from_utf8_lossy(&output.stderr);

        if !output.status.success()
            && !message.to_lowercase().contains("cannot find")
            && !message.to_lowercase().contains("does not exist")
        {
            return Err(format!("Could not remove automatic backup task: {message}"));
        }

        return Ok(());
    }

    if settings.schedule != "daily" && settings.schedule != "weekly" {
        return Err("Backup schedule must be daily or weekly.".into());
    }

    let mut time_parts = settings.time.split(':');

    let hour = time_parts
        .next()
        .and_then(|v| v.parse::<u32>().ok());

    let minute = time_parts
        .next()
        .and_then(|v| v.parse::<u32>().ok());

    if time_parts.next().is_some()
        || !matches!(hour, Some(0..=23))
        || !matches!(minute, Some(0..=59))
    {
        return Err("Enter a valid backup time in HH:MM format.".into());
    }

    let executable = std::env::current_exe()
        .map_err(|e| format!("Could not locate Ajbot Studio executable: {e}"))?;

    let task_command = format!(
        "\"{}\" --backup-runner",
        executable.display()
    );

    let frequency = if settings.schedule == "weekly" {
    "WEEKLY"
} else {
    "DAILY"
};

let mut task_args = vec![
    "/Create".to_string(),
    "/SC".to_string(),
    frequency.to_string(),
];

if settings.schedule == "weekly" {
    task_args.push("/D".to_string());
    task_args.push("MON".to_string());
}

task_args.extend([
    "/ST".to_string(),
    settings.time.clone(),
    "/TN".to_string(),
    AUTOMATIC_BACKUP_TASK.to_string(),
    "/TR".to_string(),
    task_command,
    "/F".to_string(),
]);

let output = std::process::Command::new("schtasks.exe")
    .args(&task_args)
    .output()
    .map_err(|e| format!("Could not access Windows Task Scheduler: {e}"))?;
    if !output.status.success() {
        let message = String::from_utf8_lossy(&output.stderr);
        let stdout = String::from_utf8_lossy(&output.stdout);

        return Err(format!(
            "Windows could not register the automatic backup task: {} {}",
            message.trim(),
            stdout.trim()
        ));
    }

    Ok(())
}

#[cfg(not(windows))]
fn update_automatic_backup_task(
    _settings: &AutomaticBackupSettings,
) -> Result<(), String> {
    Err("Automatic background scheduling is currently supported on Windows only.".into())
}

fn copy_profile_tree(source: &Path, destination: &Path) -> Result<(u64, u64), String> {
    let metadata = fs::symlink_metadata(source)
        .map_err(|e| format!("Could not inspect source profiles: {e}"))?;

    if !metadata.is_dir() || metadata.file_type().is_symlink() {
        return Err("The source profile directory is not a safe directory.".into());
    }

    fs::create_dir_all(destination)
        .map_err(|e| format!("Could not create migration staging directory: {e}"))?;

    let mut stats = (0u64, 0u64);

    for entry in fs::read_dir(source)
        .map_err(|e| format!("Could not read source profiles: {e}"))?
    {
        let entry = entry.map_err(|e| e.to_string())?;
        let source_path = entry.path();
        let destination_path = destination.join(entry.file_name());
        let metadata = fs::symlink_metadata(&source_path)
            .map_err(|e| e.to_string())?;

        if metadata.file_type().is_symlink() {
            return Err(format!("Migration refused a symbolic link: {}", source_path.display()));
        }

        if metadata.is_dir() {
            let child = copy_profile_tree(&source_path, &destination_path)?;
            stats.0 += child.0;
            stats.1 += child.1;
        } else if metadata.is_file() {
            let size = fs::copy(&source_path, &destination_path)
                .map_err(|e| format!("Could not copy {}: {e}", source_path.display()))?;

            stats.0 += 1;
            stats.1 += size;
        } else {
            return Err(format!("Migration refused an unsupported file: {}", source_path.display()));
        }
    }

    Ok(stats)
}

fn inspect_profile_tree(root: &Path) -> Result<(u64, u64), String> {
    let mut stats = (0u64, 0u64);

    for entry in fs::read_dir(root).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();
        let metadata = fs::symlink_metadata(&path)
            .map_err(|e| e.to_string())?;

        if metadata.file_type().is_symlink() {
            return Err("Migration verification found a symbolic link.".into());
        }

        if metadata.is_dir() {
            let child = inspect_profile_tree(&path)?;
            stats.0 += child.0;
            stats.1 += child.1;
        } else if metadata.is_file() {
            stats.0 += 1;
            stats.1 += metadata.len();
        } else {
            return Err("Migration verification found an unsupported file.".into());
        }
    }

    Ok(stats)
}


fn ensure_profile_idle(state: &WorkerState, profile_id: &str) -> Result<(), String> {
    validate_profile_id(profile_id)?;

    let response = send_worker_request(
        state,
        "profileStorageStatus",
        Some(profile_id.to_string()),
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
    )?;

    let data = response.data.unwrap_or(Value::Null);

    if data.get("busy").and_then(Value::as_bool).unwrap_or(true) {
        let reason = data
            .get("reason")
            .and_then(Value::as_str)
            .unwrap_or("The profile is in use.");

        return Err(format!(
            "{reason} Stop the browser, workflow, and recorder before backing up or restoring."
        ));
    }

    Ok(())
}

fn zip_directory(
    writer: &mut ZipWriter<fs::File>,
    root: &Path,
    current: &Path,
    entry_count: &mut usize,
    total_size: &mut u64,
) -> Result<(), String> {
    let entries = fs::read_dir(current)
        .map_err(|e| format!("Could not read profile data: {e}"))?;

    for entry in entries {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();

        let metadata = fs::symlink_metadata(&path)
            .map_err(|e| format!("Could not inspect profile data: {e}"))?;

        if metadata.file_type().is_symlink() {
            return Err(
                "Profile storage contains a symbolic link; backup was stopped for safety."
                    .into(),
            );
        }

        let relative = path
            .strip_prefix(root)
            .map_err(|_| "Invalid profile path")?;

        let name = relative.to_string_lossy().replace('\\', "/");

        *entry_count += 1;

        if *entry_count > MAX_BACKUP_ENTRIES {
            return Err("The profile contains too many files and folders to back up.".into());
        }

        if metadata.is_dir() {
            writer
                .add_directory(
                    format!("{name}/"),
                    SimpleFileOptions::default(),
                )
                .map_err(|e| format!("Could not add profile folder to backup: {e}"))?;

            zip_directory(
                writer,
                root,
                &path,
                entry_count,
                total_size,
            )?;
        } else if metadata.is_file() {
            if metadata.len() > MAX_BACKUP_FILE {
                return Err(format!(
                    "A profile file exceeds the 4 GB safety limit: {name}"
                ));
            }

            let expected_size = metadata.len();

            if total_size
                .checked_add(expected_size)
                .filter(|size| *size <= MAX_BACKUP_UNCOMPRESSED)
                .is_none()
            {
                return Err("The profile exceeds the 20 GB backup safety limit.".into());
            }

            writer
                .start_file(
                    name,
                    SimpleFileOptions::default()
                        .compression_method(zip::CompressionMethod::Deflated),
                )
                .map_err(|e| format!("Could not add profile file to backup: {e}"))?;

            let mut file = fs::File::open(&path)
                .map_err(|e| format!("Could not open profile file: {e}"))?;

            let copied = std::io::copy(&mut file, writer)
                .map_err(|e| format!("Could not write profile backup: {e}"))?;

            *total_size = total_size
                .checked_add(copied)
                .ok_or("Backup size overflow.")?;

            if *total_size > MAX_BACKUP_UNCOMPRESSED {
                return Err("The profile exceeds the 20 GB backup safety limit.".into());
            }
        } else {
            return Err(format!(
                "Unsupported filesystem entry found in profile storage: {name}"
            ));
        }
    }

    Ok(())
}

fn create_unique_directory(root: &Path, prefix: &str) -> Result<PathBuf, String> {
    for _ in 0..100 {
        let id = next_profile_io_id();

        let path = root.join(format!(
            "{prefix}-{}-{}-{}",
            now_ms(),
            std::process::id(),
            id
        ));

        match fs::create_dir(&path) {
            Ok(()) => return Ok(path),
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(error) => {
                return Err(format!(
                    "Could not create temporary profile directory: {error}"
                ));
            }
        }
    }

    Err("Could not allocate a unique temporary profile directory.".into())
}

#[tauri::command]
fn backup_browser_profile(
    profile_id: String,
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    validate_profile_id(&profile_id)?;
    ensure_profile_idle(&state, &profile_id)?;

    let root = browser_profiles_root()?;
    let profile_dir = root.join(&profile_id);

    let dir_meta = fs::symlink_metadata(&profile_dir)
        .map_err(|_| "Browser profile not found.")?;

    if !dir_meta.is_dir() || dir_meta.file_type().is_symlink() {
        return Err("The profile storage path is not a safe local directory.".into());
    }

    let canonical_profile = profile_dir
        .canonicalize()
        .map_err(|e| format!("Could not verify profile directory: {e}"))?;

    if !canonical_profile.starts_with(&root) {
        return Err("The profile directory is outside the permitted storage location.".into());
    }

    let profile_json = canonical_profile.join("profile.json");

    let metadata_info = fs::symlink_metadata(&profile_json)
        .map_err(|_| "Profile metadata is missing or unreadable.")?;

    if !metadata_info.is_file()
        || metadata_info.file_type().is_symlink()
        || metadata_info.len() > MAX_PROFILE_METADATA_SIZE
    {
        return Err("Profile metadata is not a valid or safe file.".into());
    }

    let metadata: Value = serde_json::from_slice(
        &fs::read(&profile_json)
            .map_err(|_| "Profile metadata is missing or unreadable.")?,
    )
    .map_err(|_| "Profile metadata is invalid.")?;

    if !metadata.is_object() {
        return Err("Profile metadata has an unexpected format.".into());
    }

    let profile_name = metadata
        .get("name")
        .and_then(Value::as_str)
        .unwrap_or(&profile_id)
        .to_string();

    let suggested = format!("ajbot-{}-backup.zip", profile_id);

    let Some(destination) = rfd::FileDialog::new()
        .add_filter("Ajbot profile backup", &["zip"])
        .set_file_name(&suggested)
        .save_file()
    else {
        return Ok(serde_json::json!({"cancelled": true}));
    };

    if destination.exists() {
        return Err(
            "The selected backup file already exists. Choose a new filename.".into(),
        );
    }

    let destination_parent = destination
        .parent()
        .ok_or("The selected backup location is invalid.")?
        .canonicalize()
        .map_err(|e| format!("Could not access backup destination: {e}"))?;

    if destination_parent.starts_with(&canonical_profile) {
        return Err(
            "Save the backup outside the browser profile folder.".into(),
        );
    }

    let destination_name = destination
        .file_name()
        .ok_or("The selected backup filename is invalid.")?
        .to_string_lossy();

    let temporary_path = destination_parent.join(format!(
        ".{destination_name}.ajbot-tmp-{}-{}",
        std::process::id(),
        next_profile_io_id()
    ));

    let created_at = now_ms();

    let manifest = serde_json::json!({
        "format": "ajbot-profile-backup",
        "version": 1,
        "createdAt": created_at,
        "profileId": profile_id,
        "profileName": profile_name,
        "startUrl": metadata.get("startUrl").cloned().unwrap_or(Value::Null),
        "app": "Ajbot Studio"
    });

    let backup_result = (|| -> Result<u64, String> {
        let file = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary_path)
            .map_err(|e| format!("Could not create temporary backup: {e}"))?;

        let mut writer = ZipWriter::new(file);

        let manifest_bytes =
            serde_json::to_vec_pretty(&manifest).map_err(|e| e.to_string())?;

        if manifest_bytes.len() as u64 > MAX_MANIFEST_SIZE {
            return Err("Backup manifest exceeds the allowed size.".into());
        }

        let mut entry_count = 1usize;
        let mut total_size = manifest_bytes.len() as u64;

        writer
            .start_file("ajbot-backup.json", SimpleFileOptions::default())
            .map_err(|e| format!("Could not write backup manifest: {e}"))?;

        writer
            .write_all(&manifest_bytes)
            .map_err(|e| format!("Could not write backup manifest: {e}"))?;

        zip_directory(
            &mut writer,
            &canonical_profile,
            &canonical_profile,
            &mut entry_count,
            &mut total_size,
        )?;

        let finished_file = writer
            .finish()
            .map_err(|e| format!("Could not finish profile backup: {e}"))?;

        finished_file
            .sync_all()
            .map_err(|e| format!("Could not finalize backup file: {e}"))?;

        let bytes = finished_file
            .metadata()
            .map_err(|e| format!("Could not inspect backup file: {e}"))?
            .len();

        if bytes > MAX_BACKUP_ARCHIVE {
            return Err("The compressed backup exceeds the 4 GB archive limit.".into());
        }

        drop(finished_file);

        if destination.exists() {
            return Err(
                "The destination file appeared while creating the backup. Choose another filename."
                    .into(),
            );
        }

        fs::rename(&temporary_path, &destination)
            .map_err(|e| format!("Could not finalize backup destination: {e}"))?;

        Ok(bytes)
    })();

    let bytes = match backup_result {
        Ok(bytes) => bytes,
        Err(error) => {
            let _ = fs::remove_file(&temporary_path);
            return Err(error);
        }
    };

    Ok(serde_json::json!({
        "cancelled": false,
        "path": destination.to_string_lossy(),
        "profileName": profile_name,
        "createdAt": created_at,
        "bytes": bytes
    }))
}

fn safe_archive_relative_path(
    name: &str,
    is_directory: bool,
) -> Result<PathBuf, String> {
    if name.is_empty()
        || name.contains('\\')
        || name.starts_with('/')
        || name.contains(':')
        || name.chars().any(char::is_control)
    {
        return Err("The backup contains an unsafe file path.".into());
    }

    let normalized = if is_directory {
        name.strip_suffix('/')
            .ok_or("The backup contains an invalid directory path.")?
    } else {
        if name.ends_with('/') {
            return Err("The backup contains an invalid file path.".into());
        }
        name
    };

    if normalized.is_empty() {
        return Err("The backup contains an invalid file path.".into());
    }

    let mut path = PathBuf::new();

    for component in normalized.split('/') {
        if component.is_empty() || component == "." || component == ".." {
            return Err("The backup contains a path-traversal entry.".into());
        }

        path.push(component);
    }

    Ok(path)
}

fn archive_path_key(path: &Path) -> String {
    path.components()
        .map(|component| component.as_os_str().to_string_lossy().to_lowercase())
        .collect::<Vec<_>>()
        .join("/")
}

#[tauri::command]
fn restore_browser_profile(name: String) -> Result<Value, String> {
    use std::io::Read;

    let name = name.trim();

    if name.is_empty()
        || name.chars().count() > 80
        || name.chars().any(char::is_control)
    {
        return Err("Profile name must contain between 1 and 80 characters.".into());
    }

    let Some(source) = rfd::FileDialog::new()
        .add_filter("Ajbot profile backup", &["zip"])
        .pick_file()
    else {
        return Ok(serde_json::json!({"cancelled": true}));
    };

    let source_info = fs::metadata(&source)
        .map_err(|e| format!("Could not inspect backup file: {e}"))?;

    if !source_info.is_file() || source_info.len() > MAX_BACKUP_ARCHIVE {
        return Err("The selected backup file is invalid or exceeds the 4 GB limit.".into());
    }

    let root = browser_profiles_root()?;

    let file = fs::File::open(&source)
        .map_err(|e| format!("Could not open backup: {e}"))?;

    let mut archive = ZipArchive::new(file)
        .map_err(|_| "This is not a valid ZIP backup.")?;

    if archive.len() > MAX_BACKUP_ENTRIES {
        return Err("The backup contains too many files.".into());
    }

    let mut total_size = 0u64;
    let mut entries: HashMap<String, bool> = HashMap::new();
    let mut has_manifest = false;
    let mut has_profile = false;

    for index in 0..archive.len() {
        let entry = archive
            .by_index(index)
            .map_err(|_| "The backup contains a damaged entry.")?;

        let is_directory = entry.is_dir();
        let path = safe_archive_relative_path(entry.name(), is_directory)?;
        let key = archive_path_key(&path);

        if let Some(mode) = entry.unix_mode() {
            let file_type = mode & 0o170000;

            if file_type != 0
                && file_type != 0o100000
                && file_type != 0o040000
            {
                return Err(
                    "The backup contains a symbolic link or unsupported special file."
                        .into(),
                );
            }

            if file_type == 0o040000 && !is_directory {
                return Err("The backup contains an invalid directory entry.".into());
            }

            if file_type == 0o100000 && is_directory {
                return Err("The backup contains an invalid file entry.".into());
            }
        }

        if entries.contains_key(&key) {
            return Err("The backup contains duplicate file or folder paths.".into());
        }

        let mut parent = String::new();

        for component in path.components() {
            let part = component.as_os_str().to_string_lossy().to_lowercase();

            if !parent.is_empty() {
                parent.push('/');
            }

            parent.push_str(&part);

            if parent != key && entries.get(&parent) == Some(&false) {
                return Err("The backup contains a file used as a folder.".into());
            }
        }

        if !is_directory {
            let prefix = format!("{key}/");

            if entries.keys().any(|existing| existing.starts_with(&prefix)) {
                return Err("The backup contains conflicting file and folder paths.".into());
            }
        }

        entries.insert(key.clone(), is_directory);

        total_size = total_size
            .checked_add(entry.size())
            .ok_or("Backup size overflow.")?;

        if entry.size() > MAX_BACKUP_FILE
            || total_size > MAX_BACKUP_UNCOMPRESSED
        {
            return Err("The backup exceeds the allowed uncompressed size.".into());
        }

        if key == "ajbot-backup.json" {
            if is_directory {
                return Err("The backup manifest must be a file.".into());
            }
            has_manifest = true;
        }

        if key == "profile.json" {
            if is_directory {
                return Err("Profile metadata must be a file.".into());
            }
            has_profile = true;

            if entry.size() > MAX_PROFILE_METADATA_SIZE {
                return Err("Profile metadata exceeds the allowed size.".into());
            }
        }

        if key == "ajbot-backup.json" && entry.size() > MAX_MANIFEST_SIZE {
            return Err("Backup manifest exceeds the allowed size.".into());
        }
    }

    if !has_manifest || !has_profile {
        return Err(
            "This ZIP is missing the Ajbot backup manifest or profile metadata.".into(),
        );
    }

    let mut manifest_entry = archive
        .by_name("ajbot-backup.json")
        .map_err(|_| "Backup manifest is missing.")?;

    let mut manifest_raw = String::new();

    (&mut manifest_entry)
    .take(MAX_MANIFEST_SIZE + 1)
    .read_to_string(&mut manifest_raw)
        .map_err(|_| "Backup manifest is unreadable.")?;

    if manifest_raw.len() as u64 > MAX_MANIFEST_SIZE {
        return Err("Backup manifest exceeds the allowed size.".into());
    }

    let manifest: Value = serde_json::from_str(&manifest_raw)
        .map_err(|_| "Backup manifest is invalid.")?;

    if manifest.get("format").and_then(Value::as_str)
    != Some("ajbot-profile-backup")
    || manifest.get("version").and_then(Value::as_u64) != Some(1)
{
    return Err("This Ajbot profile backup version is not supported.".into());
}

drop(manifest_entry);
drop(archive);

    let mut archive = ZipArchive::new(
        fs::File::open(&source)
            .map_err(|e| format!("Could not reopen backup: {e}"))?,
    )
    .map_err(|_| "Could not reopen profile backup.")?;

    let mut profile_entry = archive
        .by_name("profile.json")
        .map_err(|_| "Profile metadata is missing.")?;

    let mut profile_raw = String::new();

    (&mut profile_entry)
    .take(MAX_PROFILE_METADATA_SIZE + 1)
    .read_to_string(&mut profile_raw)
        .map_err(|_| "Profile metadata is unreadable.")?;

    if profile_raw.len() as u64 > MAX_PROFILE_METADATA_SIZE {
        return Err("Profile metadata exceeds the allowed size.".into());
    }

    let mut profile_meta: Value = serde_json::from_str(&profile_raw)
        .map_err(|_| "Profile metadata is invalid.")?;

    if !profile_meta.is_object() {
        return Err("Profile metadata has an unexpected format.".into());
    }

    drop(profile_entry);
    drop(archive);

    let mut new_id = String::new();
    let mut final_dir = PathBuf::new();

    for _ in 0..100 {
        let candidate = format!(
            "restored-{}-{}-{}",
            now_ms(),
            std::process::id(),
            next_profile_io_id()
        );

        validate_profile_id(&candidate)?;

        let candidate_path = root.join(&candidate);

        if !candidate_path.exists() {
            new_id = candidate;
            final_dir = candidate_path;
            break;
        }
    }

    if new_id.is_empty() {
        return Err("Could not allocate a unique restored profile ID.".into());
    }

    let staging = create_unique_directory(&root, ".restore-staging")?;

    let extraction = (|| -> Result<(), String> {
        let mut archive = ZipArchive::new(
            fs::File::open(&source).map_err(|e| e.to_string())?,
        )
        .map_err(|_| "Could not reopen profile backup.")?;

        let mut extracted_size = 0u64;

        for index in 0..archive.len() {
            let entry = archive
    .by_index(index)
                .map_err(|_| "The backup contains a damaged entry.")?;

            let is_directory = entry.is_dir();

            let entry_path = safe_archive_relative_path(
                entry.name(),
                is_directory,
            )?;

            if entry_path == Path::new("ajbot-backup.json") {
                continue;
            }

            let output = staging.join(&entry_path);

            if is_directory {
                fs::create_dir_all(&output)
                    .map_err(|e| format!("Could not create restored folder: {e}"))?;
            } else {
                if let Some(parent) = output.parent() {
                    fs::create_dir_all(parent)
                        .map_err(|e| format!("Could not create restored folder: {e}"))?;
                }

                let mut target = fs::OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .open(&output)
                    .map_err(|e| format!("Could not create restored file: {e}"))?;

                let copied = std::io::copy(
                    &mut entry.take(MAX_BACKUP_FILE + 1),
                    &mut target,
                )
                .map_err(|e| format!("Could not extract backup file: {e}"))?;

                if copied > MAX_BACKUP_FILE {
                    return Err("A restored file exceeds the 4 GB safety limit.".into());
                }

                extracted_size = extracted_size
                    .checked_add(copied)
                    .ok_or("Restored profile size overflow.")?;

                if extracted_size > MAX_BACKUP_UNCOMPRESSED {
                    return Err("The restored profile exceeds the 20 GB safety limit.".into());
                }

                target
                    .sync_all()
                    .map_err(|e| format!("Could not finalize restored file: {e}"))?;
            }
        }

        profile_meta["id"] = Value::String(new_id.clone());
        profile_meta["name"] = Value::String(name.to_string());

        fs::write(
            staging.join("profile.json"),
            serde_json::to_vec_pretty(&profile_meta)
                .map_err(|e| e.to_string())?,
        )
        .map_err(|e| format!("Could not update restored profile metadata: {e}"))?;

        if final_dir.exists() {
            return Err("The restored profile ID already exists. Please try again.".into());
        }

        fs::rename(&staging, &final_dir)
            .map_err(|e| format!("Could not finalize restored profile: {e}"))?;

        Ok(())
    })();

    if let Err(error) = extraction {
        let _ = fs::remove_dir_all(&staging);
        return Err(error);
    }

    Ok(serde_json::json!({
        "cancelled": false,
        "profile": {
            "id": new_id,
            "name": name,
            "startUrl": profile_meta.get("startUrl").cloned().unwrap_or(Value::Null),
            "running": false
        },
        "source": source.to_string_lossy()
    }))
}


#[tauri::command]
fn verify_backup_file(source: &Path) -> Result<Value, String> {    
    use std::io::Read;

    let source_info = fs::symlink_metadata(&source)
        .map_err(|e| format!("Could not inspect backup file: {e}"))?;

    if !source_info.is_file()
        || source_info.file_type().is_symlink()
        || source_info.len() > MAX_BACKUP_ARCHIVE
    {
        return Err(
            "The selected backup is invalid or exceeds the 4 GB archive limit."
                .into(),
        );
    }

    
    let file = fs::File::open(&source)
        .map_err(|e| format!("Could not open backup: {e}"))?;

    let mut archive = ZipArchive::new(file)
        .map_err(|_| "This file is not a valid ZIP archive.".to_string())?;

    if archive.len() > MAX_BACKUP_ENTRIES {
        return Err("The backup contains too many entries.".into());
    }

    let mut entries: HashMap<String, bool> = HashMap::new();
    let mut total_size = 0u64;
    let mut file_count = 0usize;
    let mut directory_count = 0usize;
    let mut manifest_raw: Option<Vec<u8>> = None;
    let mut profile_raw: Option<Vec<u8>> = None;

    for index in 0..archive.len() {
        let mut entry = archive
            .by_index(index)
            .map_err(|_| "The backup contains a damaged ZIP entry.".to_string())?;

        let entry_name = entry.name().to_string();
        let is_directory = entry.is_dir();

        let path = safe_archive_relative_path(
            &entry_name,
            is_directory,
        )?;

        let key = archive_path_key(&path);

        // Reject symbolic links and unsupported special files.
        if let Some(mode) = entry.unix_mode() {
            let file_type = mode & 0o170000;

            if file_type != 0
                && file_type != 0o100000
                && file_type != 0o040000
            {
                return Err(
                    "The backup contains a symbolic link or unsupported special file."
                        .into(),
                );
            }

            if file_type == 0o040000 && !is_directory {
                return Err("The backup contains an invalid directory entry.".into());
            }

            if file_type == 0o100000 && is_directory {
                return Err("The backup contains an invalid file entry.".into());
            }
        }

        // Reject duplicate paths, including case-insensitive duplicates.
        if entries.contains_key(&key) {
            return Err(
                "The backup contains duplicate file or folder paths.".into(),
            );
        }

        // Reject a file being used as a parent directory.
        let mut parent = String::new();

        for component in path.components() {
            let part = component
                .as_os_str()
                .to_string_lossy()
                .to_lowercase();

            if !parent.is_empty() {
                parent.push('/');
            }

            parent.push_str(&part);

            if parent != key
                && entries.get(&parent) == Some(&false)
            {
                return Err(
                    "The backup contains a file used as a folder.".into(),
                );
            }
        }

        // Reject a file that conflicts with an existing folder.
        if !is_directory {
            let prefix = format!("{key}/");

            if entries.keys().any(|existing| existing.starts_with(&prefix)) {
                return Err(
                    "The backup contains conflicting file and folder paths.".into(),
                );
            }
        }

        entries.insert(key.clone(), is_directory);

        let entry_size = entry.size();

        total_size = total_size
            .checked_add(entry_size)
            .ok_or("Backup size overflow.")?;

        if entry_size > MAX_BACKUP_FILE
            || total_size > MAX_BACKUP_UNCOMPRESSED
        {
            return Err(
                "The backup exceeds the allowed uncompressed size.".into(),
            );
        }

        if is_directory {
            directory_count += 1;
        } else {
            file_count += 1;
        }

        // Read important metadata into memory with strict size limits.
        if key == "ajbot-backup.json" {
            if is_directory {
                return Err("The backup manifest must be a file.".into());
            }

            if entry_size > MAX_MANIFEST_SIZE {
                return Err("Backup manifest exceeds the allowed size.".into());
            }

            let mut bytes = Vec::with_capacity(entry_size as usize);

            entry
                .read_to_end(&mut bytes)
                .map_err(|_| "Backup manifest is damaged or unreadable.".to_string())?;

            if bytes.len() as u64 != entry_size {
                return Err("Backup manifest size does not match its ZIP entry.".into());
            }

            manifest_raw = Some(bytes);
        } else if key == "profile.json" {
            if is_directory {
                return Err("Profile metadata must be a file.".into());
            }

            if entry_size > MAX_PROFILE_METADATA_SIZE {
                return Err("Profile metadata exceeds the allowed size.".into());
            }

            let mut bytes = Vec::with_capacity(entry_size as usize);

            entry
                .read_to_end(&mut bytes)
                .map_err(|_| "Profile metadata is damaged or unreadable.".to_string())?;

            if bytes.len() as u64 != entry_size {
                return Err("Profile metadata size does not match its ZIP entry.".into());
            }

            profile_raw = Some(bytes);
        } else {
            // Read every other entry completely. This also checks its CRC.
            let copied = std::io::copy(
                &mut entry,
                &mut std::io::sink(),
            )
            .map_err(|_| {
                format!("Backup entry is corrupted or unreadable: {entry_name}")
            })?;

            if copied != entry_size {
                return Err(
                    format!("Backup entry has an incorrect size: {entry_name}")
                );
            }
        }
    }

    // Both required metadata files must exist at the archive root.
    let manifest_raw = manifest_raw
        .ok_or("The Ajbot backup manifest is missing.")?;

    let profile_raw = profile_raw
        .ok_or("Profile metadata is missing from the backup.")?;

    let manifest: Value = serde_json::from_slice(&manifest_raw)
        .map_err(|_| "The Ajbot backup manifest contains invalid JSON.")?;

    if !manifest.is_object() {
        return Err("The Ajbot backup manifest has an invalid format.".into());
    }

    if manifest.get("format").and_then(Value::as_str)
        != Some("ajbot-profile-backup")
        || manifest.get("version").and_then(Value::as_u64) != Some(1)
    {
        return Err(
            "This Ajbot profile backup version is not supported.".into(),
        );
    }

    let profile: Value = serde_json::from_slice(&profile_raw)
        .map_err(|_| "Profile metadata contains invalid JSON.")?;

    if !profile.is_object() {
        return Err("Profile metadata has an unexpected format.".into());
    }

    let profile_name = manifest
        .get("profileName")
        .and_then(Value::as_str)
        .or_else(|| profile.get("name").and_then(Value::as_str))
        .unwrap_or("Unknown profile");

    let created_at = manifest
        .get("createdAt")
        .and_then(Value::as_u64);

    Ok(serde_json::json!({
        "cancelled": false,
        "valid": true,
        "path": source.to_string_lossy(),
        "profileName": profile_name,
        "createdAt": created_at,
        "archiveBytes": source_info.len(),
        "uncompressedBytes": total_size,
        "fileCount": file_count,
        "directoryCount": directory_count,
        "message": "Backup verification completed. All entries and metadata passed validation."
    }))
}

#[tauri::command]
fn verify_browser_profile_backup() -> Result<Value, String> {
    let Some(source) = rfd::FileDialog::new()
        .add_filter("Ajbot profile backup", &["zip"])
        .pick_file()
    else {
        return Ok(serde_json::json!({
            "cancelled": true
        }));
    };

    verify_backup_file(&source)
}


#[tauri::command]
fn create_browser_profile(
    profile_id: String,
    name: String,
    start_url: Option<String>,
    device_class: Option<String>,
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    send_worker_request_options(
        &state,
        "create",
        Some(profile_id),
        Some(name),
        start_url,
        None, None, None, None, None, None, None, None, None, None,
        Some(serde_json::json!({ "deviceClass": device_class })),
    )?
    .profile
    .ok_or_else(|| "Worker did not return the created profile.".into())
}

#[tauri::command]
fn update_browser_profile(
    profile_id: String,
    name: String,
    start_url: Option<String>,
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    let name = name.trim();
    if name.is_empty() || name.chars().count() > 80 {
        return Err("Profile name must contain between 1 and 80 characters.".into());
    }
    request(
        &state,
        "updateProfile",
        Some(profile_id),
        Some(name.to_string()),
        start_url,
        None,
        None,
        None,
    )?
    .profile
    .ok_or_else(|| "Worker did not return the updated profile.".into())
}

#[tauri::command]
fn delete_browser_profile(
    profile_id: String,
    state: State<'_, WorkerState>,
    scheduler: State<'_, SchedulerState>,
) -> Result<String, String> {
    let is_scheduled = scheduler.data.lock().map_err(|e| e.to_string())?
        .schedules.iter().any(|job| job.profile_id == profile_id || job.members.iter().any(|member| member.profile_id == profile_id));
    if is_scheduled {
        return Err("This profile is referenced by a saved schedule. Remove or change that schedule before deleting the profile.".into());
    }
    Ok(request(
        &state,
        "deleteProfile",
        Some(profile_id),
        None,
        None,
        None,
        None,
        None,
    )?.message.unwrap_or_else(|| "Browser profile deleted.".into()))
}

#[tauri::command]
fn list_browser_profiles(
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    request(
        &state, "list", None, None, None, None, None, None
    )?
    .profiles
    .ok_or_else(|| "Worker did not return profiles.".into())
}

#[tauri::command]
fn launch_browser_profile(
    profile_id: String,
    url: Option<String>,
    device_class: Option<String>,
    proxy_id: Option<String>,
    state: State<'_, WorkerState>,
) -> Result<String, String> {
    let proxy = match proxy_id {
        Some(id) => proxy_config(&id)?,
        None => assigned_proxy_config(&profile_id)?,
    };
    let response = send_worker_request_options(
        &state,
        "launch",
        Some(profile_id),
        None,
        url,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        proxy,
        Some(serde_json::json!({ "deviceClass": device_class })),
    )?;

    Ok(response.message.unwrap_or_else(|| "Browser launched.".into()))
}

#[tauri::command]
fn close_browser_profile(
    profile_id: String,
    state: State<'_, WorkerState>,
) -> Result<String, String> {
    Ok(
        request(
            &state,
            "close",
            Some(profile_id),
            None,
            None,
            None,
            None,
            None,
        )?
        .message
        .unwrap_or_else(|| "Browser closed.".into())
    )
}

#[tauri::command]
fn list_browser_workflows(
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    request(
        &state,
        "listWorkflows",
        None,
        None,
        None,
        None,
        None,
        None,
    )?
    .workflows
    .ok_or_else(|| "Worker did not return workflows.".into())
}

#[tauri::command]
fn save_browser_workflow(
    workflow_id: String,
    name: String,
    steps: Vec<WorkflowStep>,
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    if name.trim().is_empty() {
        return Err("Workflow name is required.".into());
    }

    if steps.is_empty() || steps.len() > 50 {
        return Err(
            "A workflow must contain between 1 and 50 steps.".into()
        );
    }

    request(
        &state,
        "saveWorkflow",
        None,
        None,
        None,
        Some(workflow_id),
        Some(name),
        Some(steps),
    )?
    .workflow
    .ok_or_else(|| "Worker did not return the saved workflow.".into())
}

#[tauri::command]
fn delete_browser_workflow(
    workflow_id: String,
    state: State<'_, WorkerState>,
) -> Result<String, String> {
    Ok(
        request(
            &state,
            "deleteWorkflow",
            None,
            None,
            None,
            Some(workflow_id),
            None,
            None,
        )?
        .message
        .unwrap_or_else(|| "Workflow deleted.".into())
    )
}

// Provider credentials use the existing Windows DPAPI encryption layer.
static PROVIDER_KEY_LOCK: Mutex<()> = Mutex::new(());
const PROVIDER_IDS: &[&str] = &["openai", "anthropic", "gemini", "openrouter", "deepseek", "grok", "elevenlabs", "openai-voice", "fish"];
fn provider_key_store() -> Result<HashMap<String, String>, String> {
    let path = proxy_data_path("provider-keys.json")?;
    if !path.exists() { return Ok(HashMap::new()); }
    serde_json::from_str(&fs::read_to_string(path).map_err(|_| "Could not read provider key storage.")?)
        .map_err(|_| "Provider key storage is invalid.".into())
}
fn write_provider_key_store(data: &HashMap<String, String>) -> Result<(), String> {
    let path = proxy_data_path("provider-keys.json")?;
    let temporary = path.with_extension("json.tmp");
    let content = serde_json::to_vec(data).map_err(|_| "Could not encode key storage.".to_string())?;
    fs::write(&temporary, content).map_err(|_| "Could not write encrypted key storage.".to_string())?;
    fs::rename(&temporary, &path).map_err(|_| "Could not commit encrypted key storage.".to_string())
}
#[tauri::command]
fn list_provider_keys() -> Result<Vec<String>, String> {
    Ok(provider_key_store()?.into_keys().collect())
}
#[tauri::command]
fn save_provider_key(provider: String, key: String) -> Result<(), String> {
    let _lock = PROVIDER_KEY_LOCK.lock().map_err(|_| "Provider key storage is busy.")?;
    if !PROVIDER_IDS.contains(&provider.as_str()) { return Err("Unsupported provider.".into()); }
    if key.trim().len() < 10 || key.len() > 1000 || key.chars().any(char::is_whitespace) {
        return Err("Enter a valid API key without spaces (10–1000 characters).".into());
    }
    #[cfg(windows)] {
        let mut data = provider_key_store()?;
        data.insert(provider, hex_encode(&protect_proxy_password(key.trim())?));
        write_provider_key_store(&data)
    }
    #[cfg(not(windows))] { Err("Persistent key storage currently requires Windows. Enter a memory-only key in the AI planner on this platform.".into()) }
}
#[tauri::command]
fn delete_provider_key(provider: String) -> Result<(), String> {
    let _lock = PROVIDER_KEY_LOCK.lock().map_err(|_| "Provider key storage is busy.")?;
    let mut data = provider_key_store()?; data.remove(&provider); write_provider_key_store(&data)
}
fn saved_provider_key(provider: &str) -> Result<Option<String>, String> {
    let data = provider_key_store()?;
    let Some(encoded) = data.get(provider) else { return Ok(None); };
    #[cfg(windows)] { Ok(Some(unprotect_proxy_password(&hex_decode(encoded)?)?)) }
    #[cfg(not(windows))] { let _ = encoded; Err("Saved keys require Windows account decryption.".into()) }
}

fn plan_browser_workflow_inner(
    task: String,
    provider: String,
    model: String,
    api_key: Option<String>,
    profile_id: Option<String>,
    start_url: Option<String>,
    state: &WorkerState,
) -> Result<Value, String> {
    let task = task.trim();
    let provider = provider.trim().to_ascii_lowercase();
    let model = model.trim();

    if task.is_empty() || task.len() > 3000 {
        return Err(
            "Task instructions must contain 1–3000 characters.".into()
        );
    }

    if !["ollama", "openai", "anthropic", "gemini", "openrouter", "deepseek", "grok"].contains(&provider.as_str()) {
        return Err("Choose an available AI planning provider.".into());
    }

    if model.is_empty()
        || model.len() > 120
        || model.chars().any(char::is_control)
    {
        return Err(
            "Enter a valid model name (1–120 characters).".into()
        );
    }

    let api_key = match api_key.filter(|key| !key.trim().is_empty()) {
        Some(key) => key,
        None if provider != "ollama" => saved_provider_key(&provider)?.unwrap_or_default(),
        None => String::new(),
    };

    if provider != "ollama" {
        let key = api_key.trim();

        if key.len() < 10
            || key.len() > 1000
            || key.chars().any(char::is_whitespace)
        {
            return Err(
                "Enter an API key or configure the selected provider in Provider Keys.".into()
            );
        }
    }

    let response = send_worker_request(
        state,
        "planWorkflow",
        profile_id,
        None,
        start_url,
        None,
        None,
        None,
        Some(task.to_string()),
        Some(provider),
        Some(model.to_string()),
        if api_key.trim().is_empty() {
            None
        } else {
            Some(api_key.trim().to_string())
        },
        None,
    )?;

    response.plan.ok_or_else(|| {
        "AI worker returned no workflow plan.".into()
    })
}

#[tauri::command]
async fn plan_browser_workflow(
    task: String, provider: String, model: String, api_key: Option<String>,
    profile_id: Option<String>, start_url: Option<String>, state: State<'_, WorkerState>,
) -> Result<Value, String> {
    let worker = state.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        plan_browser_workflow_inner(task, provider, model, api_key, profile_id, start_url, &worker)
    }).await.map_err(|error| format!("Planning task could not complete: {error}"))?
}

#[tauri::command]
async fn qa_workspace(
    operation: String,
    input: Value,
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    let worker = state.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        let api_key = if matches!(operation.as_str(), "draft" | "models" | "explainRun") {
            let provider = input.get("provider").and_then(Value::as_str).unwrap_or("");
            match provider {
                "ollama" => None,
                "openai" | "anthropic" | "gemini" | "openrouter" | "deepseek" | "grok" =>
                    saved_provider_key(provider)?,
                _ => return Err("Choose a supported AI provider.".into()),
            }
        } else {
            None
        };
        let response = send_worker_request_options(
            &worker, "qaWorkspace", None, None, None, None, None, None, None, None,
            None, api_key, None, None, None,
            Some(serde_json::json!({ "operation": operation, "input": input })),
        )?;
        response.data.ok_or_else(|| "The QA worker returned no response.".to_string())
    }).await.map_err(|error| format!("QA worker task failed: {error}"))?
}

#[tauri::command]
async fn run_ai_agent(
    run_id: String, goal: String, start_url: String, max_steps: u32,
    provider: String, model: String, profile_id: Option<String>, state: State<'_, WorkerState>,
) -> Result<Value, String> {
    if goal.trim().is_empty() || goal.len() > 3000 { return Err("Enter a goal of 1–3000 characters.".into()); }
    if run_id.is_empty() || run_id.len() > 100 || !run_id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_') { return Err("Invalid agent run ID.".into()); }
    if max_steps == 0 || max_steps > 50 { return Err("Max steps must be 1–50.".into()); }
    if !["ollama", "openai", "anthropic", "gemini", "openrouter", "deepseek", "grok"].contains(&provider.as_str()) { return Err("Unsupported agent provider.".into()); }
    if model.trim().is_empty() || model.len() > 120 || model.chars().any(char::is_control) { return Err("Select a valid agent model.".into()); }
    if profile_id.as_deref().is_some_and(|id| !valid_proxy_id(id)) { return Err("Select a valid saved profile.".into()); }
    let key = if provider == "ollama" { None } else { Some(saved_provider_key(&provider)?.ok_or("Save this provider's API key in Provider Keys before starting the agent.")?) };
    let proxy = match profile_id.as_deref() {
        Some(id) => assigned_proxy_config(id)?,
        None => None,
    };
    let worker = state.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        let response = send_worker_request_options(
            &worker, "runAiAgent", profile_id, None, Some(start_url), Some(run_id), None,
            None, Some(goal), Some(provider), Some(model), key, None, None, proxy,
            Some(serde_json::json!({ "maxSteps": max_steps }))
        )?;
        response.data.ok_or_else(|| "The agent returned no result.".to_string())
    }).await.map_err(|e| format!("Live agent failed: {e}"))?
}

#[tauri::command]
async fn control_ai_agent(
    run_id: String, action: String, approval_id: Option<String>, state: State<'_, WorkerState>,
) -> Result<Value, String> {
    if !["stop", "approve", "reject"].contains(&action.as_str()) { return Err("Unknown agent control.".into()); }
    let worker = state.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        let response = send_worker_request_options(
            &worker, "controlAiAgent", None, None, None, Some(run_id), None, None,
            None, None, None, None, None, None, None,
            Some(serde_json::json!({ "action": action, "approvalId": approval_id }))
        )?;
        response.data.ok_or_else(|| "The agent returned no control status.".to_string())
    }).await.map_err(|e| format!("Agent control failed: {e}"))?
}

#[tauri::command]
async fn list_provider_models(provider: String, state: State<'_, WorkerState>) -> Result<Value, String> {
    if !["ollama", "openai", "anthropic", "gemini", "openrouter", "deepseek", "grok"].contains(&provider.as_str()) {
        return Err("Unsupported AI provider.".into());
    }
    let api_key = if provider == "ollama" { None } else { saved_provider_key(&provider)? };
    let worker = state.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        let response = send_worker_request(&worker, "listProviderModels", None, None, None, None, None, None, None, Some(provider), None, api_key, None)?;
        response.data.ok_or_else(|| "Provider returned no model catalogue.".to_string())
    }).await.map_err(|error| format!("Model catalogue task could not complete: {error}"))?
}

fn execute_browser_workflow(
    workflow_id: String,
    profile_id: String,
    approve_consequential: bool,
    step_mode: Option<bool>,
    state: &WorkerState,
) -> Result<Value, String> {
    let response = send_worker_request_mode(
        state,
        "runWorkflow",
        Some(profile_id),
        None,
        None,
        Some(workflow_id),
        None,
        None,
        None,
        None,
        None,
        None,
                Some(approve_consequential),
        step_mode,
        None,
    )?;
    Ok(serde_json::json!({
        "ok": response.ok,
        "status": response.status,
        "error": response.error,
        "message": response.message.unwrap_or_else(|| "Workflow finished.".into()),
        "results": response.results.unwrap_or(Value::Array(vec![]))
    }))
}

// Keep the Tauri event loop free so pause/stop and navigation remain responsive.
#[tauri::command]
async fn run_browser_workflow(
    workflow_id: String,
    profile_id: String,
    approve_consequential: bool,
    step_mode: Option<bool>,
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    let worker = state.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        execute_browser_workflow(workflow_id, profile_id, approve_consequential, step_mode, &worker)
    }).await.map_err(|error| format!("Workflow task could not complete: {error}"))?
}


#[tauri::command]
fn list_run_history(state: State<'_, WorkerState>) -> Result<Value, String> {
    let response = send_worker_request(&state, "listRunHistory", None, None, None, None, None, None, None, None, None, None, None)?;
    Ok(response.runs.unwrap_or(Value::Array(vec![])))
}

#[tauri::command]
fn retry_failed_browser_step(
    profile_id: String, step: WorkflowStep, approve_consequential: bool,
    state: State<'_, WorkerState>,
) -> Result<Value, String> {
    let response = send_worker_request(&state, "retryFailedStep", Some(profile_id), None, None,
        None, None, Some(vec![step]), None, None, None, None, Some(approve_consequential))?;
    response.result.ok_or_else(|| response.error.unwrap_or_else(|| "Worker returned no retry result.".into()))
}

#[tauri::command]
fn control_browser_workflow(
    action: String, profile_id: String, state: State<'_, WorkerState>,
) -> Result<String, String> {
    if !["pauseWorkflow", "resumeWorkflow", "stopWorkflow"].contains(&action.as_str()) {
        return Err("Invalid workflow control action.".into());
    }
    let response = send_worker_request(&state, &action, Some(profile_id), None, None, None, None,
        None, None, None, None, None, None)?;
    Ok(response.message.unwrap_or_else(|| "Workflow control accepted.".into()))
}

#[tauri::command]
fn start_browser_recording(profile_id: String, state: State<'_, WorkerState>) -> Result<Value, String> {
    let response = send_worker_request(&state, "startRecorder", Some(profile_id), None, None, None, None, None, None, None, None, None, None)?;
    response.result.ok_or_else(|| response.error.unwrap_or_else(|| "Recorder returned no start result.".into()))
}

#[tauri::command]
fn control_browser_recording(action: String, profile_id: String, state: State<'_, WorkerState>) -> Result<Value, String> {
    if !["pauseRecorder", "resumeRecorder", "stopRecorder"].contains(&action.as_str()) {
        return Err("Invalid recorder control action.".into());
    }
    let response = send_worker_request(&state, &action, Some(profile_id), None, None, None, None, None, None, None, None, None, None)?;
    response.result.ok_or_else(|| response.error.unwrap_or_else(|| "Recorder returned no control result.".into()))
}

#[tauri::command]
fn list_schedules(state: State<'_, SchedulerState>) -> Result<Vec<ScheduledJob>, String> {
    let data = state.data.lock().map_err(|e| e.to_string())?;
    Ok(data.schedules.clone())
}

#[tauri::command]
fn list_schedule_runs(state: State<'_, SchedulerState>) -> Result<Vec<ScheduledRun>, String> {
    let data = state.data.lock().map_err(|e| e.to_string())?;
    Ok(data.runs.clone())
}

#[tauri::command]
fn save_schedule(
    id: Option<String>, name: String, workflow_id: String, profile_id: String,
    repeat: String, scheduled_at: u64, pod_id: Option<String>, members: Option<Vec<ScheduledMember>>,
    proxy_id: Option<String>, state: State<'_, SchedulerState>,
) -> Result<ScheduledJob, String> {
    let name = name.trim();
    if name.is_empty() || name.chars().count() > 100 { return Err("Schedule name must be between 1 and 100 characters.".into()); }
    if workflow_id.trim().is_empty() || profile_id.trim().is_empty() { return Err("Choose a saved workflow and browser profile.".into()); }
    if !["once", "daily", "weekly"].contains(&repeat.as_str()) { return Err("Choose a valid repeat option.".into()); }
    if scheduled_at <= now_ms().saturating_add(30_000) { return Err("Choose a start time at least 30 seconds in the future.".into()); }
    let members = members.unwrap_or_default();
    if pod_id.is_some() != !members.is_empty() {
        return Err("Choose a pod with local browser profiles.".into());
    }
    if !members.is_empty() {
        let mut ids = std::collections::HashSet::new();
        if members[0].profile_id != profile_id || members.iter().any(|member| !valid_proxy_id(&member.profile_id) || !ids.insert(&member.profile_id)) {
            return Err("Pod schedule contains invalid or duplicate profile IDs.".into());
        }
    }
    if let Some(ref proxy) = proxy_id { proxy_config(proxy)?; }
    let mut data = state.data.lock().map_err(|e| e.to_string())?;
    let id = id.filter(|v| !v.trim().is_empty()).unwrap_or_else(|| format!("schedule-{}", now_ms()));
    if data.schedules.iter().any(|item| item.id == id && item.running) {
        return Err("A running schedule cannot be edited.".into());
    }
    let existing = data.schedules.iter().find(|item| item.id == id);
    let created_at = existing.map(|item| item.created_at).unwrap_or_else(now_ms);
    let enabled = existing.map(|item| item.enabled).unwrap_or(true);
    let last_run_at = existing.and_then(|item| item.last_run_at);
    let last_status = existing.and_then(|item| item.last_status.clone());
    let last_message = existing.and_then(|item| item.last_message.clone());
    let job = ScheduledJob { id: id.clone(), name: name.into(), workflow_id, profile_id, pod_id, members, proxy_id, repeat, scheduled_at, next_run_at: scheduled_at, enabled, running: false, last_run_at, last_status, last_message, created_at };
    if let Some(index) = data.schedules.iter().position(|item| item.id == id) { data.schedules[index] = job.clone(); }
    else { data.schedules.insert(0, job.clone()); }
    drop(data);
    save_scheduler_data(&state)?;
    Ok(job)
}

#[tauri::command]
fn set_schedule_enabled(id: String, enabled: bool, state: State<'_, SchedulerState>) -> Result<(), String> {
    let mut data = state.data.lock().map_err(|e| e.to_string())?;
    let job = data.schedules.iter_mut().find(|item| item.id == id).ok_or("Schedule not found.")?;
    if job.running { return Err("This schedule is currently running and cannot be changed yet.".into()); }
    if enabled && job.next_run_at <= now_ms() {
        match job.repeat.as_str() {
            "daily" | "weekly" => {
                let interval = if job.repeat == "daily" { 86_400_000 } else { 604_800_000 };
                while job.next_run_at <= now_ms() { job.next_run_at = job.next_run_at.saturating_add(interval); }
            }
            _ => return Err("This one-time schedule has passed. Edit it and choose a new future time before resuming.".into()),
        }
    }
    job.enabled = enabled;
    drop(data);
    save_scheduler_data(&state)
}

#[tauri::command]
fn delete_schedule(id: String, state: State<'_, SchedulerState>) -> Result<(), String> {
    let mut data = state.data.lock().map_err(|e| e.to_string())?;
    if data.schedules.iter().any(|item| item.id == id && item.running) { return Err("A running schedule cannot be deleted.".into()); }
    let before = data.schedules.len();
    data.schedules.retain(|item| item.id != id);
    if data.schedules.len() == before { return Err("Schedule not found.".into()); }
    drop(data);
    save_scheduler_data(&state)
}

#[tauri::command]
fn get_automatic_backup_settings() -> Result<Value, String> {
    let data = load_automatic_backup_data();

    let default_directory = automatic_backup_data_file()?
        .parent()
        .ok_or("Could not locate Ajbot Studio data directory.")?
        .join("automatic-backups");

    Ok(serde_json::json!({
        "settings": data.settings,
        "history": data.history,
        "defaultBackupDirectory": default_directory.to_string_lossy().to_string()
    }))
}

#[tauri::command]
fn save_automatic_backup_settings(
    enabled: bool,
    schedule: String,
    time: String,
    backup_directory: String,
    retention_count: usize,
) -> Result<Value, String> {
    let schedule = schedule.trim().to_lowercase();
    let time = time.trim().to_string();
    let backup_directory = backup_directory.trim().to_string();

    if schedule != "daily" && schedule != "weekly" {
        return Err("Schedule must be daily or weekly.".into());
    }

    if time.len() != 5
        || time.as_bytes().get(2) != Some(&b':')
        || !time.as_bytes()[0..2].iter().all(u8::is_ascii_digit)
        || !time.as_bytes()[3..5].iter().all(u8::is_ascii_digit)
    {
        return Err("Enter the backup time in HH:MM format.".into());
    }

    let hour: u32 = time[0..2]
        .parse()
        .map_err(|_| "Invalid backup hour.")?;

    let minute: u32 = time[3..5]
        .parse()
        .map_err(|_| "Invalid backup minute.")?;

    if hour > 23 || minute > 59 {
        return Err("Backup time must be between 00:00 and 23:59.".into());
    }

    if !(1..=100).contains(&retention_count) {
        return Err("Backup retention must be between 1 and 100.".into());
    }

    if !backup_directory.is_empty()
        && !Path::new(&backup_directory).is_absolute()
    {
        return Err("The backup directory must be an absolute path.".into());
    }

    let new_settings = AutomaticBackupSettings {
        enabled,
        schedule,
        time,
        backup_directory,
        retention_count,
    };

    // Create and validate the destination before enabling the task.
    if enabled {
        automatic_backup_directory(&new_settings)?;
    }

    let mut data = load_automatic_backup_data();
    let previous_data = data.clone();

    data.settings = new_settings.clone();

    // Persist settings before registering the scheduled task.
    save_automatic_backup_data(&data)?;

    if let Err(task_error) = update_automatic_backup_task(&new_settings) {
        // Roll back settings and attempt to restore the previous task.
        let rollback_result = save_automatic_backup_data(&previous_data);
        let task_rollback_result =
            update_automatic_backup_task(&previous_data.settings);

        if rollback_result.is_err() || task_rollback_result.is_err() {
            return Err(format!(
                "Could not update the scheduled backup task: {task_error}. \
                 Automatic backup settings rollback also encountered an error."
            ));
        }

        return Err(format!(
            "Could not update the scheduled backup task: {task_error}"
        ));
    }

    get_automatic_backup_settings()
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let worker_state = WorkerState { connection: Arc::new(Mutex::new(None)), app: Arc::new(Mutex::new(None)) };
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .manage(worker_state.clone())
        .setup(move |app| {
            if let Ok(mut slot) = worker_state.app.lock() { *slot = Some(app.handle().clone()); }
            let data_dir = app.path().app_data_dir()?;
            fs::create_dir_all(&data_dir)?;
            let scheduler_file = data_dir.join("scheduler.json");
            let scheduler_state = SchedulerState { data: Arc::new(Mutex::new(load_scheduler_data(&scheduler_file))), file: scheduler_file };
            let _ = save_scheduler_data(&scheduler_state);
            app.manage(scheduler_state.clone());
            start_scheduler(worker_state.clone(), scheduler_state, app.handle().clone());
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            list_provider_models,
            list_provider_keys,
            save_provider_key,
            delete_provider_key,
            check_node,
            verify_browser_engine,
            repair_browser_engine,
            discover_site_pages,
            device_country,
            search_web,
            create_browser_profile,
            update_browser_profile,
            delete_browser_profile,
            backup_browser_profile,
            restore_browser_profile,
            verify_browser_profile_backup,
            get_automatic_backup_settings,
            save_automatic_backup_settings,
            list_browser_profiles,
            launch_browser_profile,
            close_browser_profile,
            list_browser_workflows,
            save_browser_workflow,
            delete_browser_workflow,
            plan_browser_workflow,
            run_ai_agent,
            qa_workspace,
            control_ai_agent,
            run_browser_workflow,
            list_run_history,
            retry_failed_browser_step,
            control_browser_workflow,
            start_browser_recording,
            control_browser_recording,
            list_schedules,
            list_schedule_runs,
            list_proxies,
            save_proxy,
            delete_proxy,
            assign_proxy_to_profile,
            get_profile_proxy,
            save_schedule,
            set_schedule_enabled,
            delete_schedule
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
