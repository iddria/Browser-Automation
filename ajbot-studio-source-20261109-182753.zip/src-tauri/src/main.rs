#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    if std::env::args().any(|arg| arg == "--backup-runner") {
        if let Err(error) = ajbot_studio_lib::run_backup_runner() {
            eprintln!("Ajbot automatic backup failed: {error}");
            std::process::exit(1);
        }

        return;
    }

    ajbot_studio_lib::run();
}