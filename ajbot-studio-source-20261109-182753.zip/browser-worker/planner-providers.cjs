"use strict";
// Fixed provider endpoints; credentials are received in memory from the native key vault.
const providers = {
  openai: { base: 'https://api.openai.com/v1', models: '/models' },
  openrouter: { base: 'https://openrouter.ai/api/v1', models: '/models' },
  deepseek: { base: 'https://api.deepseek.com', models: '/models' },
  grok: { base: 'https://api.x.ai/v1', models: '/models' },
  anthropic: { base: 'https://api.anthropic.com/v1', models: '/models' },
  gemini: { base: 'https://generativelanguage.googleapis.com/v1beta', models: '/models' },
  ollama: { base: 'http://127.0.0.1:11434', models: '/api/tags' },
};
function headers(provider, apiKey) {
  const out = { 'Content-Type': 'application/json' };
  if (provider === 'anthropic') { out['anthropic-version'] = '2023-06-01'; out['x-api-key'] = apiKey; }
  else if (provider === 'gemini') out['x-goog-api-key'] = apiKey;
  else if (apiKey) out.Authorization = `Bearer ${apiKey}`;
  return out;
}
async function request(provider, path, apiKey, body, fetchImpl, signal) {
  const config = providers[provider]; if (!config) throw new Error('Unsupported AI provider.');
  if (!['ollama','openrouter'].includes(provider) && !apiKey) throw new Error('Configure this provider’s API key first.');
  let response;
  try {
    response = await fetchImpl(config.base + path, {
      method: body ? 'POST' : 'GET', headers: headers(provider, apiKey),
      ...(body ? { body: JSON.stringify(body) } : {}),
      redirect: 'error', signal: signal ? AbortSignal.any([signal,AbortSignal.timeout(body ? 120000 : 30000)]) : AbortSignal.timeout(body ? 120000 : 30000),
    });
  } catch { throw new Error(`${provider} could not be reached. Check the connection and try again.`); }
  let data; try { data = await response.json(); } catch { throw new Error(`${provider} returned an unreadable response.`); }
  if (!response.ok || data.error) {
    let detail = typeof data.error?.message === 'string' ? data.error.message : `Request failed (${response.status}).`;
    if (apiKey) detail = detail.split(apiKey).join('[redacted]');
    throw new Error(`${provider}: ${detail.slice(0, 300)}`);
  }
  return data;
}
async function listModels(provider, apiKey = '', fetchImpl = fetch) {
  const config = providers[provider]; if (!config) throw new Error('Unsupported AI provider.');
  const models = []; let path = config.models; const cursors = new Set();
  while (path) {
    const data = await request(provider, path, apiKey, null, fetchImpl);
    const list = provider === 'ollama' || provider === 'gemini' ? data.models : data.data;
    if (!Array.isArray(list)) throw new Error(`${provider} returned an invalid model catalogue.`);
    for (const item of list) {
      if (provider === 'gemini' && !item.supportedGenerationMethods?.includes('generateContent')) continue;
      if (provider === 'openrouter' && item.architecture?.output_modalities && !item.architecture.output_modalities.includes('text')) continue;
      const id = provider === 'gemini' ? String(item.name || '').replace(/^models\//, '') : String(item.id || item.name || '');
      if (id && id.length <= 120) models.push({ id, name: String(item.displayName || item.display_name || item.name || id) });
    }
    const cursor = provider === 'gemini' ? data.nextPageToken : provider === 'anthropic' && data.has_more ? data.last_id : null;
    if (!cursor) break;
    if (cursors.has(cursor)) throw new Error(`${provider} returned a repeated catalogue cursor.`);
    cursors.add(cursor);
    path = config.models + '?' + new URLSearchParams(provider === 'gemini' ? { pageToken: cursor } : { after_id: cursor }).toString();
  }
  return [...new Map(models.map(model => [model.id, model])).values()];
}
async function callHostedPlanner(provider, model, apiKey, prompt, fetchImpl = fetch, signal) {
  if (!apiKey) throw new Error('Configure this provider’s API key first.');
  const system = 'Return valid JSON only. Follow the provided workflow schema. Do not execute actions.';
  let data; let content;
  if (provider === 'anthropic') {
    data = await request(provider, '/messages', apiKey, { model, max_tokens: 4096, system, messages: [{ role: 'user', content: prompt }] }, fetchImpl, signal);
    content = data.content?.filter(part => part.type === 'text').map(part => part.text).join('\n');
  } else if (provider === 'gemini') {
    if (!/^[a-zA-Z0-9._-]+$/.test(model)) throw new Error('Use a Gemini model ID from its catalogue.');
    data = await request(provider, `/models/${encodeURIComponent(model)}:generateContent`, apiKey, { systemInstruction: { parts: [{ text: system }] }, contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json' } }, fetchImpl, signal);
    content = data.candidates?.[0]?.content?.parts?.map(part => part.text || '').join('');
  } else if (['openrouter','deepseek','grok'].includes(provider)) {
    data = await request(provider, '/chat/completions', apiKey, { model, stream: false, messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }] }, fetchImpl, signal);
    content = data.choices?.[0]?.message?.content;
    if (Array.isArray(content)) content = content.map(part => part.text || '').join('');
  } else throw new Error('Unsupported hosted planning provider.');
  if (typeof content !== 'string' || !content.trim()) throw new Error(`${provider} returned no workflow text. Choose a text-generation model.`);
  return content;
}
async function askPlanner(prompt, { provider, model, apiKey, signal }) {
  const messages = [
    { role: 'system', content: 'Return valid JSON only. Follow the schema supplied in the task.' },
    { role: 'user', content: prompt },
  ];
  if (provider === 'openai') {
    const data = await request(provider, '/chat/completions', apiKey, {
      model, messages, temperature: 0.2, response_format: { type: 'json_object' },
    }, fetch, signal);
    return data.choices?.[0]?.message?.content;
  }
  if (provider === 'ollama') {
    const data = await request(provider, '/api/chat', '', {
      model, messages, stream: false, format: 'json', options: { temperature: 0.2 },
    }, fetch, signal);
    return data.message?.content;
  }
  return callHostedPlanner(provider, model, apiKey, prompt, fetch, signal);
}
module.exports = { callHostedPlanner, listModels, askPlanner };
