const MAX_PAGES = 24;
const MAX_CANDIDATES = 48;
const ASSET_EXTENSION = /\.(?:apk|appx|avif|css|csv|dll|dmg|docx?|exe|gif|gz|ico|jpe?g|js|json|mjs|mov|mp[34]|msi|pdf|png|rar|svg|tar|txt|wasm|webm|webmanifest|webp|woff2?|xlsx?|xml|zip)$/i;

function isHtmlContentType(value) {
  return /^(text\/html|application\/xhtml\+xml)\s*(?:;|$)/i.test(value || '');
}

function pageUrl(value, base) {
  try {
    const url = new URL(value.replaceAll('&amp;', '&'), base);
    if (url.origin !== base.origin || url.username || url.password || url.search) return null;
    if (ASSET_EXTENSION.test(decodeURIComponent(url.pathname))) return null;
    url.hash = '';
    return url.href;
  } catch {
    return null;
  }
}

function anchorTargets(html, root) {
  const markup = html.replace(/<!--[\s\S]*?-->|<(script|style|template|textarea|title)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, '');
  const tags = markup.matchAll(/<([a-z][\w:-]*)(?=[\s/>])((?:[^"'<>]|"[^"]*"|'[^']*')*)>/gi);
  let base = root;
  let hasBase = false;
  const links = [];
  for (const [, tagName, attributes] of tags) {
    const tag = tagName.toLowerCase();
    if (tag !== 'a' && tag !== 'base') continue;
    const attrs = new Map();
    for (const [, name, double, single, unquoted] of attributes.matchAll(/([^\s=/'"<>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>\x60]+)))?/g)) {
      if (!attrs.has(name.toLowerCase())) attrs.set(name.toLowerCase(), double ?? single ?? unquoted ?? '');
    }
    if (tag === 'base') {
      if (!hasBase && attrs.has('href')) {
        hasBase = true;
        try { base = new URL(attrs.get('href'), root); } catch { /* Invalid base. */ }
      }
    } else if (attrs.get('href') && !attrs.has('download')) {
      links.push(attrs.get('href'));
    }
  }
  return links.filter(href => !href.startsWith('#')).map(href => {
    try { return new URL(href, base).href; } catch { return ''; }
  }).filter(Boolean);
}

// Bounded, read-only discovery. Only confirmed HTML documents become visits.
async function discoverPages(input, { fetcher = fetch } = {}) {
  const root = new URL(input);
  if (!['http:', 'https:'].includes(root.protocol) || root.username || root.password) throw Error('Invalid website URL.');
  root.hash = '';
  const deadline = Date.now() + 15000;
  const request = async url => {
    const parsed = new URL(url);
    if (parsed.origin !== root.origin || parsed.username || parsed.password) throw Error('Discovery is limited to the target website.');
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw Error('Site discovery timed out.');
    const response = await fetcher(url, {
      redirect: 'manual',
      signal: AbortSignal.timeout(Math.min(remaining, 5000)),
      headers: { 'User-Agent': 'AJBOT-Studio-Site-Inspector/1.0', Accept: 'text/html,application/xhtml+xml,application/xml,text/xml' },
    });
    if (!response.ok) {
      await response.body?.cancel();
      throw Error(`Website returned HTTP ${response.status}.`);
    }
    return response;
  };
  const read = async response => {
    if (!response.body) return '';
    const decoder = new TextDecoder();
    let text = '';
    let size = 0;
    for await (const chunk of response.body) {
      size += chunk.byteLength;
      if (size > 1000000) throw Error('Discovery response exceeds 1 MB.');
      text += decoder.decode(chunk, { stream: true });
    }
    return text + decoder.decode();
  };
  const isPage = response => response.status !== 204
    && isHtmlContentType(response.headers.get('content-type'))
    && !/^attachment\b/i.test(response.headers.get('content-disposition') || '');
  const landing = await request(root.href);
  if (!isPage(landing)) {
    await landing.body?.cancel();
    throw Error('The target URL must return an HTML page.');
  }
  const html = await read(landing);
  const candidates = new Set();
  const add = value => {
    const url = pageUrl(value, root);
    if (url && url !== root.href && candidates.size < MAX_CANDIDATES) candidates.add(url);
  };
  anchorTargets(html, root).forEach(add);
  const locations = xml => [...xml.matchAll(/<loc>\s*([^<]+)\s*<\/loc>/gi)].map(match => match[1].trim());
  const readSitemap = async url => {
    try {
      const response = await request(url);
      if (isHtmlContentType(response.headers.get('content-type'))) {
        await response.body?.cancel();
        return '';
      }
      return await read(response);
    } catch {
      return '';
    }
  };
  const sitemap = await readSitemap(new URL('/sitemap.xml', root).href);
  if (/<sitemapindex[\s>]/i.test(sitemap)) {
    const nested = await Promise.all(locations(sitemap).slice(0, 3).map(readSitemap));
    nested.filter(xml => /<urlset[\s>]/i.test(xml)).forEach(xml => locations(xml).forEach(add));
  } else if (/<urlset[\s>]/i.test(sitemap)) {
    locations(sitemap).forEach(add);
  }

  const pages = [root.href];
  const urls = [...candidates];
  for (let start = 0; start < urls.length && pages.length < MAX_PAGES && Date.now() < deadline; start += 6) {
    const batch = await Promise.all(urls.slice(start, start + 6).map(async url => {
      try {
        const response = await request(url);
        await response.body?.cancel();
        return isPage(response) ? url : null;
      } catch {
        return null;
      }
    }));
    for (const page of batch) {
      if (page && pages.length < MAX_PAGES) pages.push(page);
    }
  }
  return pages;
}

module.exports = { discoverPages, isHtmlContentType };
if (require.main === module) discoverPages(process.argv[2])
  .then(pages => process.stdout.write(JSON.stringify(pages)))
  .catch(error => { process.stderr.write(error.message); process.exitCode = 1; });
