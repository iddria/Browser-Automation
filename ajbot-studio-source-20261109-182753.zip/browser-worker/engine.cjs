const fs = require('node:fs');
const path = require('node:path');
const {spawn} = require('node:child_process');
async function verifyEngine({playwright, browserPath}={}) {
  const checks=[{name:'Node.js',ok:Number(process.versions.node.split('.')[0])>=20,detail:process.version+' (20 or newer required)'}];
  let engine=playwright;
  try {engine ||= require('playwright');checks.push({name:'Playwright package',ok:true,detail:require('playwright/package.json').version});}
  catch{checks.push({name:'Playwright package',ok:false,detail:'Run pnpm install in the AJBOT STUDIO folder, then Repair Engine.'});}
  for(const file of ['worker.cjs','planner-providers.cjs','live-agent.cjs']) checks.push({name:file,ok:fs.existsSync(path.join(__dirname,file)),detail:'Worker source file'});
  if(engine){
    const executable=browserPath||engine.chromium.executablePath();
    checks.push({name:'Chromium files',ok:fs.existsSync(executable),detail:executable});
    if(fs.existsSync(executable)){
      let browser;
      try{browser=await engine.chromium.launch({headless:true,executablePath:executable,timeout:20000});const page=await browser.newPage();await page.setContent('<title>AJBOT engine check</title>');if(await page.title()!=='AJBOT engine check')throw Error('Page check failed');checks.push({name:'Browser launch',ok:true,detail:'Headless launch and page inspection passed'});}
      catch(e){checks.push({name:'Browser launch',ok:false,detail:String(e.message).slice(0,600)});}
      finally{if(browser)await browser.close();}
    }
  }
  return {ok:checks.every(c=>c.ok),checks,checkedAt:new Date().toISOString()};
}
async function repairEngine({cliPath,timeoutMs=300000}={}){
  let cli;try{cli=cliPath||path.join(path.dirname(require.resolve('playwright/package.json')),'cli.js');}catch{return {ok:false,checks:[{name:'Playwright package',ok:false,detail:'Run pnpm install in the project folder first. Repair installs Chromium from the locally installed Playwright package.'}]};}
  await new Promise((resolve,reject)=>{const child=spawn(process.execPath,[cli,'install','chromium'],{cwd:path.join(__dirname,'..'),windowsHide:true,stdio:['ignore','pipe','pipe']});let details='';child.stdout.on('data',b=>{details=(details+b).slice(-5000);});child.stderr.on('data',b=>{details=(details+b).slice(-5000);});const timer=setTimeout(()=>{child.kill();reject(Error('Browser install timed out after 5 minutes. Check your network and retry.'));},timeoutMs);child.on('error',e=>{clearTimeout(timer);reject(e);});child.on('close',code=>{clearTimeout(timer);code===0?resolve():reject(Error(details||`Browser installation exited ${code}`));});});
  return verifyEngine();
}
module.exports={verifyEngine,repairEngine};
if(require.main===module)(process.argv[2]==='repair'?repairEngine():verifyEngine()).then(r=>process.stdout.write(JSON.stringify(r))).catch(e=>{process.stdout.write(JSON.stringify({ok:false,checks:[{name:'Engine operation',ok:false,detail:String(e.message)}]}));});
