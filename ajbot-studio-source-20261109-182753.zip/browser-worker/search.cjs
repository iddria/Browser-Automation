
const readline = require("node:readline");
const { chromium } = require("playwright");

const MAX_QUERY_LENGTH = 600;
const RESULT_LIMIT = 8;
const NAVIGATION_TIMEOUT = 25000;

function safeHttpUrl(value) {
  try {
    const url = new URL(String(value || ""));
    if (!["http:", "https:"].includes(url.protocol)) return "";
    if (!url.hostname) return "";
    return url.href;
  } catch {
    return "";
  }
}

function cleanText(value, maxLength) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, maxLength);
}

function normalizeSearchText(value) {
  return String(value || "")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function rankBraveResults(results, query) {
  const normalizedQuery = normalizeSearchText(query);
  const terms = normalizedQuery.split(/\s+/).filter(Boolean);

  if (!terms.length) return [];

  return results
    .map((item) => {
      const title = normalizeSearchText(item.title);
      const description = normalizeSearchText(item.description);

      let hostname = "";

      try {
        hostname = normalizeSearchText(new URL(item.url).hostname);
      } catch {
        return { ...item, score: 0 };
      }

      let score = 0;
      let matchedTerms = 0;

      for (const term of terms) {
        const inTitle = title.includes(term);
        const inDescription = description.includes(term);
        const inHostname = hostname.includes(term);

        if (inTitle) {
          score += 8;
          matchedTerms++;
        } else if (inDescription) {
          score += 3;
          matchedTerms++;
        } else if (inHostname) {
          score += 2;
          matchedTerms++;
        }
      }

      // Reward results containing the complete search phrase.
      if (title.includes(normalizedQuery)) score += 12;
      if (description.includes(normalizedQuery)) score += 5;

      return {
        ...item,
        score,
        matchedTerms,
      };
    })
    .filter((item) => {
      // Reject results that don't contain any search terms.
      if (item.score === 0) return false;

      // For multiword queries, require at least half the terms to match.
      return item.matchedTerms >= Math.ceil(terms.length / 2);
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, RESULT_LIMIT)
    .map(({ score, matchedTerms, ...item }) => item);
}

async function braveSearch(query) {
  const apiKey = String(
    process.env.BRAVE_SEARCH_API_KEY || ""
  ).trim();

  if (!apiKey) {
    throw new Error(
      "BRAVE_SEARCH_API_KEY is not set. Check your Windows environment variables and restart Ajbot Studio."
    );
  }

  const url = new URL(
    "https://api.search.brave.com/res/v1/web/search"
  );

  url.searchParams.set("q", query);
  url.searchParams.set("count", "20");
  url.searchParams.set("country", "ALL");
  url.searchParams.set("search_lang", "en");
  url.searchParams.set("safesearch", "strict");

  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Cache-Control": "no-cache",
      "X-Subscription-Token": apiKey,
    },
    signal: AbortSignal.timeout(20000),
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new Error(
        "Brave rejected the API key or account access. Check your Brave Search dashboard."
      );
    }

    if (response.status === 429) {
      throw new Error(
        "Brave Search rate limit reached. Try again later."
      );
    }

    const detail = cleanText(
      data?.error?.message ||
      data?.error ||
      data?.message ||
      "",
      400
    );

    throw new Error(
      `Brave Search returned HTTP ${response.status}${detail ? `: ${detail}` : "."}`
    );
  }

  const raw = Array.isArray(data?.web?.results)
    ? data.web.results
    : [];

  const results = raw
    .map((item) => ({
      title: cleanText(item.title || "Untitled result", 300),
      url: safeHttpUrl(item.url),
      description: cleanText(item.description, 1200),
    }))
    .filter((item) => item.url && item.title !== "Untitled result");

  // Rank and filter results against the original search query.
  const ranked = rankBraveResults(results, query);
  process.stderr.write(
  "\n========== BRAVE SEARCH DEBUG ==========\n"
);

process.stderr.write(`Query: ${query}\n`);
process.stderr.write(`Raw results: ${results.length}\n`);
process.stderr.write(`Ranked results: ${ranked.length}\n`);

results.slice(0, 10).forEach((item, index) => {
  process.stderr.write(
    `\n${index + 1}. ${item.title}\nURL: ${item.url}\nDescription: ${item.description}\n`
  );
});

process.stderr.write(
  "\n========================================\n"
);

  // Diagnostic information goes to stderr, not the JSON response.
  process.stderr.write(
    `[Brave] Query: "${query}" | Raw results: ${raw.length} | Relevant results: ${ranked.length}\n`
  );

  return ranked;
}

function isChallengePage(url, bodyText) {
  const combined = `${url} ${bodyText}`.toLowerCase();

  return (
    /\/sorry\/|captcha|challenge-platform|consent\.google/.test(combined) ||
    /unusual traffic|verify you are human|complete the security check/.test(combined)
  );
}

async function browserSearch(provider, query) {
  const engines = {
    google: {
      url: `https://www.google.com/search?q=${encodeURIComponent(query)}&safe=active`,
      resultSelector: "#search a:has(h3)",
      titleSelector: "h3",
      descriptionSelectors: [
        ".VwiC3b",
        ".IsZvec",
        "[data-sncf]",
      ],
      blockedHosts: ["google.com", "googleusercontent.com"],
    },
    bing: {
      url: `https://www.bing.com/search?q=${encodeURIComponent(query)}&adlt=strict`,
      resultSelector: "li.b_algo h2 a",
      titleSelector: "h2",
      descriptionSelectors: [
        ".b_caption p",
        ".b_algoSlug",
      ],
      blockedHosts: ["bing.com", "microsoft.com"],
    },
  };

  const engine = engines[provider];
  if (!engine) throw new Error("Unsupported search provider.");

  let browser;

  try {
    browser = await chromium.launch({
      headless: true,
    });

    const context = await browser.newContext({
      locale: "en-US",
      viewport: { width: 1365, height: 900 },
      serviceWorkers: "block",
    });

    const page = await context.newPage();
    page.setDefaultNavigationTimeout(NAVIGATION_TIMEOUT);

    await page.goto(engine.url, {
      waitUntil: "domcontentloaded",
      timeout: NAVIGATION_TIMEOUT,
    });

    await page.waitForTimeout(1200);

    const bodyText = await page.locator("body").innerText().catch(() => "");
    const currentUrl = page.url();

    if (isChallengePage(currentUrl, bodyText)) {
      throw new Error(
        `${provider === "google" ? "Google" : "Bing"} displayed a consent, CAPTCHA, or security challenge. Complete it manually in a normal browser, then try again. Ajbot does not bypass these checks.`
      );
    }

    const results = await page.locator(engine.resultSelector).evaluateAll(
      (elements, config) => {
        const output = [];

        for (const element of elements) {
          const anchor = element.matches("a") ? element : element.closest("a");
          if (!anchor) continue;

          const heading = anchor.querySelector(config.titleSelector);
          const title = heading?.textContent?.trim() || anchor.textContent?.trim();

          let url = anchor.href;

          try {
            const parsed = new URL(url);
            if (!["http:", "https:"].includes(parsed.protocol)) continue;

            if (config.blockedHosts.some(
              (host) => parsed.hostname === host || parsed.hostname.endsWith(`.${host}`)
            )) continue;

            // Google sometimes wraps result links in a redirect URL.
            if (parsed.hostname === "www.google.com" && parsed.pathname === "/url") {
              url = parsed.searchParams.get("q") || parsed.searchParams.get("url") || "";
            }
          } catch {
            continue;
          }

          const container =
            anchor.closest("li") ||
            anchor.parentElement?.parentElement ||
            anchor.parentElement;

          let description = "";

          if (container) {
            for (const selector of config.descriptionSelectors) {
              const candidate = container.querySelector(selector)?.textContent?.trim();
              if (candidate) {
                description = candidate;
                break;
              }
            }
          }

          output.push({
            title: title || "Untitled result",
            url,
            description,
          });
        }

        return output;
      },
      {
        titleSelector: engine.titleSelector,
        descriptionSelectors: engine.descriptionSelectors,
        blockedHosts: engine.blockedHosts,
      }
    );

    return results
      .map((item) => ({
        title: cleanText(item.title, 300),
        url: safeHttpUrl(item.url),
        description: cleanText(item.description, 1200),
      }))
      .filter((item) => item.url)
      .slice(0, RESULT_LIMIT);
  } catch (error) {
    if (error?.name === "TimeoutError") {
      throw new Error(`${provider} search timed out. Check your internet connection and try again.`);
    }

    throw error;
  } finally {
    if (browser) {
      await browser.close().catch(() => {});
    }
  }
}

async function run(input) {
  const query = String(input?.query || "").trim();
  const provider = String(input?.provider || "brave").trim().toLowerCase();

  if (!query || query.length > MAX_QUERY_LENGTH) {
    throw new Error("Enter a search query between 1 and 600 characters.");
  }

  if (!["brave", "google", "bing"].includes(provider)) {
    throw new Error("Choose Brave, Google, or Bing as the search provider.");
  }

  let results;

  if (provider === "brave") {
    results = await braveSearch(query);
  } else {
    results = await browserSearch(provider, query);
  }

  return { results };
}

const rl = readline.createInterface({
  input: process.stdin,
  crlfDelay: Infinity,
});

let handled = false;

rl.on("line", async (line) => {
  if (handled) return;
  handled = true;

  try {
    const input = JSON.parse(line);
    const response = await run(input);
    process.stdout.write(JSON.stringify(response));
  } catch (error) {
    const message =
      error instanceof Error ? error.message : String(error || "Unknown search error");

    process.stderr.write(cleanText(message, 1000));
    process.exitCode = 1;
  } finally {
    rl.close();
  }
});

rl.on("close", () => {
  if (!handled) {
    process.stderr.write("No search request was received.");
    process.exitCode = 1;
  }
});
