const { chromium } = require("playwright");
const os = require("os");
const path = require("path");

(async () => {
  const context = await chromium.launchPersistentContext(
    path.join(os.tmpdir(), "ajbot-diagnostic-profile"),
    { headless: false }
  );

  console.log("Browser launched. Waiting 20 seconds...");
  context.on("close", () => console.log("BROWSER CLOSED unexpectedly"));

  await new Promise(resolve => setTimeout(resolve, 20000));
  console.log("20-second test completed.");
  await context.close();
})().catch(error => {
  console.error("LAUNCH ERROR:", error);
  process.exitCode = 1;
});
