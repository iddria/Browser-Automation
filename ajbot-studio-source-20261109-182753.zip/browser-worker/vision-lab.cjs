'use strict';

const { execFile } = require('node:child_process');
const path = require('node:path');
const { promisify } = require('node:util');

const execute = promisify(execFile);
const script = path.join(__dirname, 'vision-lab', 'classify_fixture.py');
const expected = [2, 7];
const threshold = 0.5;
let pending;

function scoreFixture(confidences) {
  if (!Array.isArray(confidences) || confidences.length !== 9 ||
      confidences.some(value => !Number.isFinite(value) || value < 0 || value > 1)) {
    throw new Error('The vision model returned invalid tile scores.');
  }
  const selected = confidences.flatMap((value, index) => value >= threshold ? [index + 1] : []);
  const passed = selected.length === expected.length && expected.every(tile => selected.includes(tile));
  return { confidences, selected, expected: [...expected], threshold, passed };
}

async function classifyFixture() {
  const python = process.env.AJBOT_VISION_PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
  let output;
  try {
    output = await execute(python, [script], { timeout: 120_000, maxBuffer: 64 * 1024, windowsHide: true });
  } catch (error) {
    if (error.code === 'ENOENT') throw new Error('Python 3.10+ is required for the Vision Lab.');
    if (error.code === 3) throw new Error('Install the Vision Lab Python packages using the project README.');
    if (error.code === 4) throw new Error('Add the ONNX model to browser-worker/vision-lab as described in the README.');
    if (error.code === 5) throw new Error('The ONNX file does not match the model checksum in the uploaded source.');
    if (error.killed) throw new Error('The vision run timed out.');
    throw new Error('The local vision model could not classify the sample grid. Check the Vision Lab setup.');
  }
  let scores;
  try { scores = JSON.parse(output.stdout); } catch {
    throw new Error('The vision model returned an invalid response.');
  }
  return scoreFixture(scores);
}

function runVisionLab(input) {
  if (Object.keys(input).length) throw new Error('The Vision Lab only accepts its built-in sample grid.');
  pending ??= classifyFixture().finally(() => { pending = undefined; });
  return pending;
}

module.exports = { runVisionLab, scoreFixture };
