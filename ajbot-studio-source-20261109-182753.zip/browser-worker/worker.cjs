

"use strict";

const { runAgent, controlAgent, stopAllAgents } = require("./live-agent.cjs");

const { callHostedPlanner, listModels, askPlanner } = require("./planner-providers.cjs");

const { chromium, devices } = require("playwright");
const { createQaWorkspace } = require("./qa-workspace.cjs");
const { isHtmlContentType } = require("./site-pages.cjs");
const { planSwarmer, executeSwarmerTarget, swarmerUrl, SCOPED_ACTIONS } = require("./swarmer-plan.cjs");
let qaWorkspace;

const readline = require("node:readline");

const path = require("node:path");

const fs = require("node:fs");

const profilesRoot = process.env.AJBOT_PROFILES_DIR
  ? path.resolve(process.env.AJBOT_PROFILES_DIR)
  : path.join(__dirname, "profiles");

const workflowsFile = path.join(__dirname, "workflows.json");
const runHistoryFile = path.join(__dirname, "run-history.json");

const MAX_WORKFLOW_STEPS = 50;

const STEP_TIMEOUT_MS = 12000;

const NAVIGATION_TIMEOUT_MS = 30000;

const MAX_TEXT_LENGTH = 10000;

const MAX_SELECTOR_LENGTH = 1000;

const MAX_WAIT_MS = 30000;

const MAX_SCROLL_MS = 10000;

fs.mkdirSync(profilesRoot, { recursive: true });

const sessions = new Map();
const activeRuns = new Map();
const recorders = new Map();

// Shared profile locks prevent backups and other processes from
// modifying browser data while a profile is in use.

const profileLocksRoot = path.join(
  path.dirname(profilesRoot),
  "profile-locks"
);

fs.mkdirSync(profileLocksRoot, { recursive: true });

function profileLockPath(profileId) {
  return path.join(profileLocksRoot, `${profileId}.lock`);
}

function isProcessAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;

  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error.code === "EPERM";
  }
}

function acquireProfileLock(profileId) {
  const pid = safeId(profileId);

  if (!pid) {
    throw new Error("A valid profile ID is required for locking.");
  }

  const lockPath = profileLockPath(pid);

  for (let attempt = 0; attempt < 2; attempt++) {
    let fd;

    try {
      fd = fs.openSync(lockPath, "wx");

      fs.writeFileSync(
        fd,
        JSON.stringify({
          pid: process.pid,
          profileId: pid,
          createdAt: new Date().toISOString()
        }),
        "utf8"
      );

      fs.closeSync(fd);
      profileLockPaths.set(pid, lockPath);

      return lockPath;
    } catch (error) {
      if (fd !== undefined) {
        try {
          fs.closeSync(fd);
        } catch {}
      }

      if (error.code !== "EEXIST") {
        throw new Error(`Could not lock browser profile: ${error.message}`);
      }

      // Remove a lock left behind by a worker that has exited.
      let ownerPid = null;

      try {
        const lock = JSON.parse(fs.readFileSync(lockPath, "utf8"));
        ownerPid = Number(lock.pid);
      } catch {
        throw new Error(
          "The profile has an unreadable lock file. Check its lock before continuing."
        );
      }

      if (isProcessAlive(ownerPid)) {
        throw new Error(
          "This browser profile is already in use by another process."
        );
      }

      try {
        fs.unlinkSync(lockPath);
      } catch (removeError) {
        if (removeError.code !== "ENOENT") {
          throw new Error("Could not clear the previous profile lock.");
        }
      }
    }
  }

  throw new Error("Could not acquire the browser profile lock.");
}

function releaseProfileLock(profileId) {
  const pid = safeId(profileId);
  if (!pid) return;

  const lockPath = profileLockPaths.get(pid);
  if (!lockPath) return;

  try {
    const lock = JSON.parse(fs.readFileSync(lockPath, "utf8"));

    // Never remove a lock owned by another process.
    if (Number(lock.pid) === process.pid) {
      fs.unlinkSync(lockPath);
    }
  } catch (error) {
    if (error.code !== "ENOENT") {
      console.error(`Could not release profile lock ${pid}:`, error.message);
    }
  } finally {
    profileLockPaths.delete(pid);
  }
}

function isProfileLocked(profileId) {
  const pid = safeId(profileId);
  if (!pid) return false;

  const lockPath = profileLockPath(pid);

  if (!fs.existsSync(lockPath)) return false;

  try {
    const lock = JSON.parse(fs.readFileSync(lockPath, "utf8"));

    if (!isProcessAlive(Number(lock.pid))) {
      fs.unlinkSync(lockPath);
      return false;
    }

    return true;
  } catch {
    // Treat an unreadable lock as locked rather than risking profile data.
    return true;
  }
}

const profileLockPaths = new Map();


function emitRecorderEvent(data) { respond({ event: "recorder-event", ok: true, data }); }

// Recording recovery is stored inside each browser profile. It contains only
// the already-filtered recorder actions (password/private fields are excluded
// by recorderInitScript before they reach this worker).
function recorderRecoveryPath(profileId) {
  return path.join(profilesRoot, safeId(profileId), "recording-recovery.json");
}

function persistRecorder(profileId, state) {
  try {
    const dir = path.join(profilesRoot, safeId(profileId));
    fs.mkdirSync(dir, { recursive: true });
    const target = recorderRecoveryPath(profileId);
    const temp = `${target}.tmp`;
    fs.writeFileSync(temp, JSON.stringify({
      version: 1,
      profileId,
      status: state.status,
      updatedAt: new Date().toISOString(),
      actions: state.actions.slice(-2000),
      diagnostics: state.diagnostics || []
    }, null, 2));
    fs.renameSync(temp, target);
  } catch (error) {
    log(`Could not persist recorder recovery for ${profileId}: ${errorMessage(error)}`);
  }
}

async function captureRecorderSnapshot(profileId, page, state, reason) {
  if (!page || page.isClosed()) return;
  try {
    const folder = path.join(profilesRoot, safeId(profileId), "recording-snapshots");
    fs.mkdirSync(folder, { recursive: true });
    const file = path.join(folder, `recording-${Date.now()}.png`);
    await page.screenshot({ path: file, fullPage: false, timeout: 5000 });
    state.snapshots = state.snapshots || [];
    state.snapshots.push({ file, reason, url: page.url(), capturedAt: new Date().toISOString() });
    state.snapshots = state.snapshots.slice(-100);
    persistRecorder(profileId, state);
    emitRecorderEvent({ type: "recorder_snapshot", profileId, file, reason, url: page.url() });
  } catch (error) {
    const diagnostic = { at: new Date().toISOString(), kind: "snapshot_failed", message: errorMessage(error).slice(0, 500) };
    state.diagnostics = [...(state.diagnostics || []).slice(-49), diagnostic];
    persistRecorder(profileId, state);
    emitRecorderEvent({ type: "recorder_diagnostic", profileId, diagnostic });
  }
}

function recorderInitScript() {
  return `(() => {
    if (window.__ajbotRecorderInstalled) return;
    window.__ajbotRecorderInstalled = true;
    const clean = value => String(value || "").replace(/\\s+/g, " ").trim().slice(0, 240);
    const unique = value => {
      try { return !!value && document.querySelectorAll(value).length === 1; } catch { return false; }
    };
    const sensitive = el => {
      if (!el || !(el instanceof Element)) return true;
      const tag = el.tagName.toLowerCase();
      if (tag === "input") {
        const type = (el.getAttribute("type") || "text").toLowerCase();
        if (["password", "hidden", "file"].includes(type)) return true;
      }
      if (el.closest('[data-private], [data-sensitive], [autocomplete="current-password"], [autocomplete="new-password"], [autocomplete="one-time-code"]')) return true;
      const attrs = [el.id, el.getAttribute("name"), el.getAttribute("placeholder"), el.getAttribute("aria-label"), el.getAttribute("autocomplete"), el.getAttribute("data-testid")].join(" ");
      return /pass(word)?|secret|token|auth|credit.?card|card.?number|cvv|cvc|security.?code|bank.?account|pin\\b|otp|one.?time.?code/i.test(attrs);
    };
    const cssEscape = value => (window.CSS && CSS.escape) ? CSS.escape(String(value)) : String(value).replace(/[^a-zA-Z0-9_-]/g, ch => "\\\\" + ch);
    const buildSelector = el => {
      if (!el || el.nodeType !== 1) return { selector: "", confidence: "low", candidates: [] };
      const tag = el.tagName.toLowerCase();
      const candidates = [];
      const add = (value, confidence) => { if (value && unique(value) && !candidates.some(x => x.selector === value)) candidates.push({ selector: value, confidence }); };
      const test = el.getAttribute("data-testid");
      if (test) add('[data-testid="' + String(test).replace(/\\"/g, '\\\\"') + '"]', "high");
      if (el.id && !/^(?:\d|:)/.test(el.id)) add("#" + cssEscape(el.id), "high");
      const name = el.getAttribute("name");
      if (name) add(tag + '[name="' + String(name).replace(/\\"/g, '\\\\"') + '"]', "high");
      const aria = el.getAttribute("aria-label");
      if (aria) add(tag + '[aria-label="' + String(aria).replace(/\\"/g, '\\\\"') + '"]', "high");
      const title = el.getAttribute("title");
      if (title) add(tag + '[title="' + String(title).replace(/\\"/g, '\\\\"') + '"]', "medium");
      const role = el.getAttribute("role");
      if (role && aria) add('[role="' + role + '"][aria-label="' + String(aria).replace(/\\"/g, '\\\\"') + '"]', "high");
      if (!candidates.length) {
        const parts = []; let node = el;
        while (node && node.nodeType === 1 && parts.length < 7) {
          let part = node.tagName.toLowerCase();
          const stable = node.getAttribute("data-testid");
          if (stable) { part += '[data-testid="' + String(stable).replace(/\\"/g, '\\\\"') + '"]'; parts.unshift(part); break; }
          const siblings = node.parentElement ? Array.from(node.parentElement.children).filter(x => x.tagName === node.tagName) : [];
          if (siblings.length > 1) part += ':nth-of-type(' + (siblings.indexOf(node) + 1) + ')';
          parts.unshift(part);
          if (node.parentElement && node.parentElement.id) { parts.unshift("#" + cssEscape(node.parentElement.id)); break; }
          node = node.parentElement;
        }
        add(parts.join(" > "), "low");
      }
      const chosen = candidates[0] || { selector: "", confidence: "low" };
      return { selector: chosen.selector, confidence: chosen.confidence, candidates: candidates.slice(0, 4).map(x => x.selector) };
    };
    const getLabel = el => {
      const labels = el.labels ? Array.from(el.labels).map(x => x.innerText || x.textContent).filter(Boolean) : [];
      const labelledBy = el.getAttribute("aria-labelledby");
      if (labelledBy) labelledBy.split(/\\s+/).forEach(id => { const node = document.getElementById(id); if (node) labels.push(node.innerText || node.textContent); });
      return clean(labels.join(" ") || el.getAttribute("aria-label") || el.getAttribute("placeholder") || el.getAttribute("title"));
    };
    const describe = el => {
      const picked = buildSelector(el);
      const tag = el.tagName.toLowerCase();
      const type = (el.getAttribute("type") || "").toLowerCase();
      return { selector: picked.selector, selectorConfidence: picked.confidence, selectorCandidates: picked.candidates,
        tag, elementType: tag === "input" ? (type || "text") : tag, inputType: type || undefined,
        role: el.getAttribute("role") || undefined, label: getLabel(el),
        text: clean(el.innerText || el.textContent || el.value || el.getAttribute("aria-label")) };
    };
    const send = payload => {
      if (typeof window.__ajbotRecorderBridge === "function") window.__ajbotRecorderBridge(payload).catch(() => {});
    };
    const clickable = 'button,a,[role="button"],[role="link"],input[type="button"],input[type="submit"],input[type="reset"],[onclick]';
    document.addEventListener("click", event => {
      if (event.detail > 1) return;
      const el = event.target && event.target.closest ? event.target.closest(clickable) : null;
      if (!el || sensitive(el)) return;
      const info = describe(el);
      send({ action: "click", ...info, url: location.href, pageTitle: document.title });
    }, true);
    document.addEventListener("dblclick", event => {
      const el = event.target && event.target.closest ? event.target.closest(clickable) : null;
      if (!el || sensitive(el)) return;
      send({ action: "doubleclick", ...describe(el), url: location.href, pageTitle: document.title });
    }, true);
    const captureField = el => {
      if (!el || sensitive(el)) return;
      const tag = el.tagName.toLowerCase();
      if (!["input", "textarea", "select"].includes(tag)) return;
      const type = (el.getAttribute("type") || "text").toLowerCase();
      if (["password", "hidden", "file", "submit", "button", "reset"].includes(type)) return;
      const info = describe(el);
      if (tag === "input" && ["checkbox", "radio"].includes(type)) {
        send({ action: el.checked ? "check" : "uncheck", ...info, url: location.href, pageTitle: document.title });
        return;
      }
      const value = tag === "select" ? el.value : String(el.value || "").slice(0, 1000);
      send({ action: tag === "select" ? "select" : "fill", ...info, value, url: location.href, pageTitle: document.title });
    };
    document.addEventListener("change", event => captureField(event.target), true);
    document.addEventListener("blur", event => captureField(event.target), true);
  })();`;
}
function attachRecorder(context, profileId) {
  if (context.__ajbotRecorderAttached) return;
  context.__ajbotRecorderAttached = true;
  context.exposeBinding("__ajbotRecorderBridge", async (_source, payload) => {
    const state = recorders.get(profileId);
    if (!state || state.status !== "recording" || !payload || typeof payload !== "object") return;
    const allowed = new Set(["click", "doubleclick", "fill", "select", "check", "uncheck"]);
    if (!allowed.has(payload.action)) return;
    const selector = String(payload.selector || "").slice(0, 500);
    const value = String(payload.value || "").slice(0, 1000);
    const signature = `${payload.action}|${selector}|${value}|${String(payload.url || "")}`;
    if (state.lastSignature === signature && Date.now() - state.lastRecordedAt < 700) return;
    state.lastSignature = signature;
    state.lastRecordedAt = Date.now();
    const item = { id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, action: payload.action,
      selector, value,
      label: String(payload.label || "").slice(0, 240), text: String(payload.text || "").slice(0, 240),
      tag: String(payload.tag || "").slice(0, 32), elementType: String(payload.elementType || "").slice(0, 32), inputType: String(payload.inputType || "").slice(0, 32), role: String(payload.role || "").slice(0, 64), selectorConfidence: String(payload.selectorConfidence || "low").slice(0, 16), selectorCandidates: Array.isArray(payload.selectorCandidates) ? payload.selectorCandidates.slice(0, 4).map(x => String(x).slice(0, 500)) : [],
      url: String(payload.url || "").slice(0, 2000), pageTitle: String(payload.pageTitle || "").slice(0, 240), recordedAt: Date.now() };
    if (payload.action !== "fill" && payload.action !== "select") delete item.value;
    state.actions.push(item);
    persistRecorder(profileId, state);
    emitRecorderEvent({ type: "action_recorded", profileId, action: item });
    if (state.actions.length === 1 || state.actions.length % 5 === 0) {
      void captureRecorderSnapshot(profileId, _source.page, state, `action_${state.actions.length}`);
    }
  });
  const initScript = recorderInitScript();
  context.addInitScript(initScript);
  for (const page of context.pages()) {
    attachRecorderPage(page, profileId);
    page.evaluate(initScript).catch(() => {});
  }
  context.on("page", page => {
    attachRecorderPage(page, profileId);
    const state = recorders.get(profileId);
    if (state && state.status === "recording") {
      const pages = context.pages();
      const action = { id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, action: "newTab", index: Math.max(0, pages.indexOf(page)), recordedAt: Date.now() };
      state.actions.push(action);
      persistRecorder(profileId, state);
      emitRecorderEvent({ type: "action_recorded", profileId, action });
      page.once("domcontentloaded", () => void captureRecorderSnapshot(profileId, page, state, "new_tab"));
    }
  });
}

function attachRecorderPage(page, profileId) {
  if (page.__ajbotRecorderPageAttached) return;
  page.__ajbotRecorderPageAttached = true;
  page.on("framenavigated", frame => {
    if (frame !== page.mainFrame()) return;
    const state = recorders.get(profileId);
    if (!state || state.status !== "recording") return;
    const url = page.url();
    if (!/^https?:/i.test(url) || state.lastUrl === url) return;
    state.lastUrl = url;
    const action = { id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, action: "navigate", url, pageTitle: "", recordedAt: Date.now() };
    state.actions.push(action);
    persistRecorder(profileId, state);
    emitRecorderEvent({ type: "action_recorded", profileId, action });
    void captureRecorderSnapshot(profileId, page, state, "navigation");
  });
  page.on("close", () => {
    const state = recorders.get(profileId);
    if (!state || state.status !== "recording") return;
    const remaining = sessions.get(profileId)?.pages().filter(item => !item.isClosed()) || [];
    const action = { id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, action: "closeTab", index: Math.max(0, remaining.length), recordedAt: Date.now() };
    state.actions.push(action);
    persistRecorder(profileId, state);
    emitRecorderEvent({ type: "action_recorded", profileId, action });
  });
}



function readRunHistory() {
  try { const value = JSON.parse(fs.readFileSync(runHistoryFile, "utf8")); return Array.isArray(value) ? value : []; } catch { return []; }
}
function writeRunHistory(items) {
  const temp = `${runHistoryFile}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(items.slice(0, 300), null, 2));
  fs.renameSync(temp, runHistoryFile);
}
function emitRunEvent(data) { respond({ event: "workflow-progress", ok: true, data }); }
function historyStep(result) {
  const { stepDefinition, screenshot, ...safe } = result || {};
  return safe;
}

let requestQueue = Promise.resolve();

let shuttingDown = false;

const rl = readline.createInterface({

  input: process.stdin,

  crlfDelay: Infinity

});

/* -------------------------------------------------------

   GENERAL HELPERS

\------------------------------------------------------- */

function log(message) {

  process.stderr.write(`[Ajbot Worker] ${message}\n`);

}

function respond(data) {

  process.stdout.write(JSON.stringify(data) + "\n");

}

function errorMessage(error) {

  return error instanceof Error ? error.message : String(error);

}

function safeId(value) {

  return String(value || "").replace(/[^a-zA-Z0-9_-]/g, "");

}

function normalizeUrl(value) {

  if (!value || !String(value).trim()) return null;

  let input = String(value).trim();

  if (!/^https?:\/\//i.test(input)) {

    input = `https://${input}`;

  }

  let parsed;

  try {

    parsed = new URL(input);

  } catch {

    throw new Error("Please enter a valid website URL.");

  }

  if (!["http:", "https:"].includes(parsed.protocol)) {

    throw new Error("Only HTTP and HTTPS URLs are allowed.");

  }

  if (

    !parsed.hostname ||

    (!parsed.hostname.includes(".") && parsed.hostname !== "localhost")

  ) {

    throw new Error("Please enter a valid website address.");

  }

  if (parsed.username || parsed.password) {

    throw new Error("URLs containing embedded credentials are not allowed.");

  }

  return parsed.href;

}

function sleep(ms) {

  return new Promise(resolve => setTimeout(resolve, ms));

}

/* -------------------------------------------------------

   PROFILE STORAGE

\------------------------------------------------------- */

function readMetadata(profilePath) {

  try {

    return JSON.parse(

      fs.readFileSync(path.join(profilePath, "profile.json"), "utf8")

    );

  } catch {

    return {};

  }

}

const devicePresets = { iPhone: "iPhone 13", Android: "Pixel 7", Mac: "Desktop Chrome HiDPI", Windows: "Desktop Chrome" };

function profileDeviceClass(value) {
  return typeof value === "string" && Object.hasOwn(devicePresets, value) ? value : null;
}

function deviceLaunchOptions(deviceClass) {
  const key = profileDeviceClass(deviceClass);
  if (!key) return {};
  const { viewport, screen, deviceScaleFactor, isMobile, hasTouch } = devices[devicePresets[key]];
  return { viewport, screen, deviceScaleFactor, isMobile, hasTouch };
}

function saveMetadata(profilePath, id, name, startUrl, deviceClass) {

  fs.writeFileSync(

    path.join(profilePath, "profile.json"),

    JSON.stringify(

      {

        id,

        name,

        startUrl: startUrl || null,
        deviceClass: profileDeviceClass(deviceClass)

      },

      null,

      2

    ),

    "utf8"

  );

}

/* -------------------------------------------------------

   WORKFLOW STORAGE

\------------------------------------------------------- */

function readWorkflows() {

  if (!fs.existsSync(workflowsFile)) {

    return [];

  }

  try {

    const data = JSON.parse(

      fs.readFileSync(workflowsFile, "utf8")

    );

    if (!Array.isArray(data)) {

      throw new Error("The workflows file must contain a JSON array.");

    }

    return data;

  } catch (error) {

    throw new Error(

      `Could not read workflows.json. Your saved data has not been changed. ${errorMessage(error)}`

    );

  }

}

function writeWorkflows(workflows) {

  const tmp = `${workflowsFile}.tmp`;

  fs.writeFileSync(

    tmp,

    JSON.stringify(workflows, null, 2),

    "utf8"

  );

  fs.renameSync(tmp, workflowsFile);

}

/* -------------------------------------------------------

   WORKFLOW ACTIONS

\------------------------------------------------------- */

const ACTIONS = new Set([

  "navigate",

  "back",

  "forward",

  "reload",

  "newtab",

  "closetab",

  "switchtab",

  "click",

  "clicktext",

  "clickrole",

  "doubleclick",

  "rightclick",

  "hover",

  "fill",

  "filllabel",

  "type",

  "clear",

  "press",

  "select",

  "check",

  "uncheck",

  "scroll",

  "wait",

  "waitforselector",

  "waitforurl",

  "waitforloadstate",

  "handledialog",

  "waitfortext",

  "extracttext",

  "extractlinks",

  "screenshot",
  "setvariable",
  "iftext",
  "ifurl",
  "ifvariable"

]);

function validateWorkflowSteps(rawSteps) {

  if (

    !Array.isArray(rawSteps) ||

    rawSteps.length < 1 ||

    rawSteps.length > MAX_WORKFLOW_STEPS

  ) {

    throw new Error(

      `A workflow must contain between 1 and ${MAX_WORKFLOW_STEPS} steps.`

    );

  }

  return rawSteps.map((raw, i) => {

    const n = i + 1;

    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {

      throw new Error(`Step ${n} is invalid.`);

    }

    const action = String(raw.action || "").trim().toLowerCase();

    if (!ACTIONS.has(action)) {

      throw new Error(`Step ${n}: unsupported action "${action}".`);

    }

    const step = {

      action,

      requiresApproval:

        raw.requiresApproval === true ||

        raw.requires_approval === true,

      riskReason:

        typeof raw.riskReason === "string"

          ? raw.riskReason

          : typeof raw.risk_reason === "string"

            ? raw.risk_reason

            : null

    };

    const str = (key, required = false) => {

      const value = raw[key] == null ? "" : String(raw[key]);

      if (required && !value.trim()) {

        throw new Error(`Step ${n}: ${key} is required.`);

      }

      const maxLength =

        key === "selector" ? MAX_SELECTOR_LENGTH : MAX_TEXT_LENGTH;

      if (value.length > maxLength) {

        throw new Error(`Step ${n}: ${key} is too long.`);

      }

      if (value) {

        step[key] = value;

      }

    };

    if (action === "navigate") {

      step.url = normalizeUrl(raw.url);

      if (!step.url) {

        throw new Error(`Step ${n}: URL is required.`);

      }

      if (raw.journeyStart === true) {
        step.journeyStart = true;
        str("journeyName");
      }
      if (raw.verifyHtml === true) step.verifyHtml = true;

    }

    if (

      [

        "click",

        "doubleclick",

        "rightclick",

        "hover",

        "fill",

        "type",

        "clear",

        "select",

        "check",

        "uncheck",

        "waitforselector",

        "extracttext",

        "extractlinks"

      ].includes(action)

    ) {

      str(

        "selector",

        !["extracttext", "extractlinks"].includes(action)

      );

    }

    if (["clicktext", "waitfortext"].includes(action)) {

      str("value", true);

    }

    if (action === "clickrole") {

      str("role", true);

      str("value", true);

    }

    if (["fill", "type", "select"].includes(action)) {

      str("value", true);

    }

    if (action === "filllabel") {

      str("label", true);

      str("value", true);

    }

    if (action === "press") {

      str("key", true);

      if (step.key.length > 50) {

        throw new Error(`Step ${n}: key is too long.`);

      }

      if (raw.selector) {

        str("selector");

      }

    }

    if (action === "scroll") {

      if (raw.scopeOrigin && raw.selector) str("selector", true);
      const direction = String(

        raw.direction || "down"

      ).toLowerCase();

      if (!["up", "down"].includes(direction)) {

        throw new Error(

          `Step ${n}: scroll direction must be up or down.`

        );

      }

      step.direction = direction;

      step.durationMs = Math.min(

        MAX_SCROLL_MS,

        Math.max(

          250,

          Number(raw.durationMs ?? raw.duration_ms ?? 1200) || 1200

        )

      );

      step.amount = Math.min(

        3000,

        Math.max(100, Number(raw.amount ?? 650) || 650)

      );

    }

    if (action === "wait") {

      step.durationMs = Math.min(

        MAX_WAIT_MS,

        Math.max(

          0,

          Number(raw.durationMs ?? raw.duration_ms ?? 1000) || 0

        )

      );

    }

    if (action === "waitforselector") {

      step.state = ["attached", "visible", "hidden"].includes(raw.state)

        ? raw.state

        : "visible";

    }

    if (action === "waitforurl") {
      str("value", true);
      step.timeoutMs = Math.min(
        NAVIGATION_TIMEOUT_MS,
        Math.max(500, Number(raw.timeoutMs ?? raw.timeout_ms ?? STEP_TIMEOUT_MS) || STEP_TIMEOUT_MS)
      );
    }

    if (action === "waitforloadstate") {
      step.state = ["load", "domcontentloaded", "networkidle"].includes(raw.state)
        ? raw.state
        : "domcontentloaded";
      step.timeoutMs = Math.min(
        NAVIGATION_TIMEOUT_MS,
        Math.max(500, Number(raw.timeoutMs ?? raw.timeout_ms ?? NAVIGATION_TIMEOUT_MS) || NAVIGATION_TIMEOUT_MS)
      );
    }

    if (action === "handledialog") {
      step.dialogAction = ["accept", "dismiss"].includes(String(raw.dialogAction || raw.dialog_action || raw.choice || "dismiss").toLowerCase())
        ? String(raw.dialogAction || raw.dialog_action || raw.choice || "dismiss").toLowerCase()
        : "dismiss";
      if (raw.promptText != null || raw.prompt_text != null) {
        step.promptText = String(raw.promptText ?? raw.prompt_text).slice(0, 1000);
      }
    }

    if (action === "switchtab") {

      step.index = Math.max(

        0,

        Math.floor(Number(raw.index) || 0)

      );

    }

    if (action === "newtab" && raw.url) {

      step.url = normalizeUrl(raw.url);

    }

    if (action === "screenshot") {
      step.fullPage = raw.fullPage === true || raw.full_page === true;
    }
    if (action === "setvariable") {
      str("name", true); str("value", true);
      if (!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(step.name)) throw new Error(`Step ${n}: invalid variable name.`);
    }
    if (["iftext", "ifurl", "ifvariable"].includes(action)) {
      if (raw.operator !== "exists") str("value", true);
      if (action === "ifvariable") str("name", true);
      step.operator = ["contains", "equals", "notContains", "exists"].includes(raw.operator) ? raw.operator : "contains";
      const branch = key => {
        const value = raw[key] == null ? [] : raw[key];
        if (!Array.isArray(value) || value.length > 20) throw new Error(`Step ${n}: ${key} must contain at most 20 steps.`);
        return value.map(child => {
          const validated = validateWorkflowSteps([child])[0];
          if (["iftext","ifurl","ifvariable"].includes(validated.action)) throw new Error("Nested conditional branches are not supported.");
          return validated;
        });
      };
      step.thenSteps = branch("thenSteps"); step.elseSteps = branch("elseSteps");
    }
    step.retryCount = Math.min(3, Math.max(0, Math.floor(Number(raw.retryCount ?? 0) || 0)));
    step.retryDelayMs = Math.min(10000, Math.max(0, Math.floor(Number(raw.retryDelayMs ?? 500) || 0)));
    if (raw.repeatCount != null) {
      if (!Number.isInteger(raw.repeatCount) || raw.repeatCount < 1 || raw.repeatCount > 10) {
        throw new Error(`Step ${n}: repeat count must be a whole number from 1 to 10.`);
      }
      if (raw.repeatCount > 1) step.repeatCount = raw.repeatCount;
    }
    if (raw.scopeOrigin) {
      const origin = swarmerUrl(raw.scopeOrigin).origin;
      if (origin !== raw.scopeOrigin || !SCOPED_ACTIONS.has(action)) throw new Error(`Step ${n}: invalid Swarmers scope or action.`);
      step.scopeOrigin = origin;
      if (step.url) swarmerUrl(step.url, origin);
      for (const key of ["sourceUrl", "expectedUrl"]) {
        if (raw[key]) step[key] = swarmerUrl(raw[key], origin).href;
      }
      if (["click", "fill", "press"].includes(action) || action === "scroll" && step.selector) {
        str("targetLabel", true);
        if (!step.selector) throw new Error(`Step ${n}: a Swarmers element selector is required.`);
      }
      if (action === "press" && step.key !== "Enter") throw new Error(`Step ${n}: a Swarmers search requires Enter.`);
      if (requiresConsequentialApproval(step)) {
        step.requiresApproval = true;
        step.riskReason ||= "Review this link before following it.";
      }
    }
    return step;

  });

}

/* -------------------------------------------------------

   APPROVAL CHECKS

\------------------------------------------------------- */

function requiresConsequentialApproval(step) {

  if (step.requiresApproval) {

    return true;

  }

  const target = [

    step.value || "",

    step.selector || "",

    step.label || "",
    step.targetLabel || "",
    step.expectedUrl || ""

  ].join(" ");

  const riskyAction =

    /submit|delete|remove|purchase|buy|pay|payment|send|publish|confirm|checkout|transfer|unsubscribe|cancel|place.?order|save.?changes|download|\.apk\b|\.exe\b|\.msi\b|install/i;

  const clickActions = [

    "click",

    "clicktext",

    "clickrole",

    "doubleclick",

    "rightclick"

  ];

  return (

    riskyAction.test(target) &&

    clickActions.includes(step.action)

  );

}

/* -------------------------------------------------------

   BROWSER SESSION HELPERS

\------------------------------------------------------- */

function getActivePage(context) {

  const pages = context.pages().filter(page => !page.isClosed());

  if (!pages.length) {

    throw new Error("This browser profile has no open page.");

  }

  return pages[pages.length - 1];

}

async function openProfileContext(profileId, { deviceClass, proxy, forAgent = false } = {}) {
  const pid = safeId(profileId);
  if (!pid) throw new Error("A valid browser profile is required.");
  if (sessions.has(pid)) throw new Error("This profile is already running. Close it in Solo Mode first.");
  const dir = path.join(profilesRoot, pid);
  if (!fs.existsSync(dir)) throw new Error("Profile not found. Create it first.");
  const directory = fs.lstatSync(dir);
  if (!directory.isDirectory() || directory.isSymbolicLink()) throw new Error("The profile storage path is not a safe local directory.");

  const metadata = readMetadata(dir);
  const options = {
    headless: false,
    acceptDownloads: !forAgent,
    ...deviceLaunchOptions(deviceClass || metadata.deviceClass),
    ...(forAgent ? { serviceWorkers: "block" } : {}),
  };
  if (proxy) {
    if (typeof proxy.server !== "string" || !proxy.server) throw new Error("Invalid proxy server configuration.");
    options.proxy = {
      server: proxy.server,
      ...(proxy.username ? { username: proxy.username } : {}),
      ...(proxy.password ? { password: proxy.password } : {}),
    };
  }

  acquireProfileLock(pid);
  try {
    const context = await chromium.launchPersistentContext(dir, options);
    context.once("close", () => releaseProfileLock(pid));
    return context;
  } catch (error) {
    releaseProfileLock(pid);
    throw error;
  }
}

function getRunningContext(profileId) {

  const id = safeId(profileId);

  if (!id) {

    throw new Error("A valid browser profile is required.");

  }

  const context = sessions.get(id);

  if (!context) {

    throw new Error("Launch the selected browser profile first.");

  }

  return context;

}

// A dialog is handled only after an explicit handledialog workflow step.
const armedDialogs = new WeakMap();

function armDialogHandler(page, action, promptText) {
  const previous = armedDialogs.get(page);
  if (previous) {
    page.removeListener("dialog", previous);
  }

  const handler = async dialog => {
    try {
      if (action === "accept") {
        await dialog.accept(promptText);
        log(`Handled ${dialog.type()} dialog: accepted.`);
      } else {
        await dialog.dismiss();
        log(`Handled ${dialog.type()} dialog: dismissed.`);
      }
    } catch (error) {
      log(`Dialog handling failed: ${errorMessage(error)}`);
    } finally {
      armedDialogs.delete(page);
    }
  };

  armedDialogs.set(page, handler);
  page.once("dialog", handler);
  return `Armed one-time dialog handler to ${action} the next browser dialog`;
}

async function clickAndDetectPopup(page, element, options = {}) {
  const popupWait = page.waitForEvent("popup", {
    timeout: options.popupTimeoutMs || 1800
  }).catch(() => null);

  await element.click({ timeout: STEP_TIMEOUT_MS });
  const popup = await popupWait;

  if (!popup || popup.isClosed()) {
    return { popup: false, detail: "No new tab or popup detected" };
  }

  await popup.bringToFront().catch(() => {});
  await popup.waitForLoadState("domcontentloaded", {
    timeout: 5000
  }).catch(() => {});

  return {
    popup: true,
    detail: `Opened popup tab: ${popup.url() || "about:blank"}`
  };
}

/* -------------------------------------------------------

   PAGE INSPECTION

\------------------------------------------------------- */

async function inspectPage(page) {

  return page.evaluate(() => {

    const clean = (value, max = 200) =>

      String(value || "")

        .replace(/\s+/g, " ")

        .trim()

        .slice(0, max);

    const isVisible = element => {

      const style = window.getComputedStyle(element);

      const rect = element.getBoundingClientRect();

      return (

        style.display !== "none" &&

        style.visibility !== "hidden" &&

        Number(style.opacity) !== 0 &&

        rect.width > 0 &&

        rect.height > 0

      );

    };

    const collect = (selector, mapper, limit = 30) => {

      return Array.from(document.querySelectorAll(selector))

        .filter(isVisible)

        .slice(0, limit)

        .map(mapper)

        .filter(item =>

          Object.values(item).some(Boolean)

        );

    };

    return {

      title: document.title,

      url: location.href,

      headings: collect(

        "h1, h2, h3, h4, h5, h6",

        element => ({

          tag: element.tagName.toLowerCase(),

          text: clean(element.innerText)

        }),

        30

      ),

      buttons: collect(

        "button, input[type=button], input[type=submit], [role=button]",

        element => ({

          text: clean(element.innerText || element.value),

          label: clean(element.getAttribute("aria-label")),

          title: clean(element.getAttribute("title"))

        }),

        30

      ),

      links: collect(

        "a[href]",

        element => ({

          text: clean(

            element.innerText ||

            element.getAttribute("aria-label")

          ),

          href: element.href

        }),

        40

      ),

      fields: collect(

        "input:not([type=hidden]), textarea, select",

        element => ({

          tag: element.tagName.toLowerCase(),

          type: clean(element.type),

          name: clean(element.name),

          placeholder: clean(element.placeholder),

          label: clean(

            element.labels?.[0]?.innerText ||

            element.getAttribute("aria-label")

          )

        }),

        30

      ),

      pageText: clean(

        document.body?.innerText,

        5000

      )

    };

  });

}

/* -------------------------------------------------------

   SELECTOR INTELLIGENCE

\------------------------------------------------------- */

function inferElementTag(selector) {

  if (!selector) return null;

  const matches = String(selector).match(

    /(?:^|[\s>+\~])([a-z][a-z0-9-]*)/gi

  );

  if (!matches || !matches.length) {

    return null;

  }

  const last = matches[matches.length - 1]

    .trim()

    .toLowerCase();

  const tag = last.replace(/^[\s>+\~]+/, "");

  const allowedTags = new Set([

    "h1",

    "h2",

    "h3",

    "h4",

    "h5",

    "h6",

    "button",

    "a",

    "input",

    "textarea",

    "select",

    "label",

    "form",

    "main",

    "article",

    "section",

    "nav",

    "header",

    "footer"

  ]);

  return allowedTags.has(tag) ? tag : null;

}

async function getPageDiagnostic(page) {

  try {

    const inspection = await inspectPage(page);

    const headings = inspection.headings

      .map(item => item.text)

      .filter(Boolean)

      .slice(0, 8);

    const buttons = inspection.buttons

      .map(item => item.text || item.label || item.title)

      .filter(Boolean)

      .slice(0, 8);

    return (

      ` Page title: "${inspection.title}".` +

      ` URL: ${inspection.url}.` +

      ` Visible headings: ${headings.join(" | ") || "None"}.` +

      ` Visible buttons: ${buttons.join(" | ") || "None"}.`

    );

  } catch {

    return "";

  }

}

async function locate(page, step, options = {}) {

  const timeout = options.timeout ?? 2500;

  const allowFallback = options.allowFallback !== false;

  /*

   * First try the exact selector.

   * Never silently replace a failed interaction selector

   * with an unrelated button or link.

   */

  if (step.selector) {

    try {

      const exact = page.locator(step.selector).first();

      await exact.waitFor({

        state: "visible",

        timeout

      });

      return exact;

    } catch (error) {

      if (!allowFallback) {

        throw error;

      }

    }

  }

  /*

   * Accessible label fallback.

   */

  if (step.label) {

    try {

      const byLabel = page.getByLabel(

        step.label,

        { exact: false }

      );

      if (await byLabel.count() === 1) {

        const element = byLabel.first();

        if (await element.isVisible()) {

          return element;

        }

      }

    } catch {

      // Continue to diagnostic error.

    }

  }

  /*

   * Visible text fallback.

   */

  if (

    ["clicktext", "waitfortext"].includes(step.action) &&

    step.value

  ) {

    try {

      const byText = page.getByText(

        step.value,

        { exact: false }

      );

      if (await byText.count() === 1) {

        const element = byText.first();

        if (await element.isVisible()) {

          return element;

        }

      }

    } catch {

      // Continue to diagnostic error.

    }

  }

  /*

   * Accessible role fallback.

   */

  if (step.action === "clickrole") {

    try {

      const byRole = page.getByRole(

        step.role,

        {

          name: step.value,

          exact: false

        }

      );

      if (await byRole.count() === 1) {

        const element = byRole.first();

        if (await element.isVisible()) {

          return element;

        }

      }

    } catch {

      // Continue to diagnostic error.

    }

  }

  const diagnostic = await getPageDiagnostic(page);

  throw new Error(

    `Could not find a unique visible element for "${step.selector || step.label || step.value || step.action}".` +

    diagnostic +

    " Inspect the page and update the workflow selector."

  );

}

/*

 * Special fallback for waitForSelector.

 *

 * Example:

 * Original selector: h1.page-title

 * Fallback: h1

 *

 * The fallback is allowed only when exactly one matching

 * element exists in the requested state.

 */

async function waitForSelectorWithFallback(page, step) {

  try {

    await page.locator(step.selector).first().waitFor({

      state: step.state,

      timeout: STEP_TIMEOUT_MS

    });

    return `Waited for ${step.state} selector ${step.selector}`;

  } catch (originalError) {

    /*

     * Do not use a broad fallback for hidden elements.

     * A missing selector is not evidence that another

     * element should be considered hidden.

     */

    if (step.state === "hidden") {

      throw originalError;

    }

    const tag = inferElementTag(step.selector);

    if (!tag) {

      const diagnostic = await getPageDiagnostic(page);

      throw new Error(

        `Selector "${step.selector}" was not found.` +

        diagnostic

      );

    }

    const candidates = page.locator(tag);

    try {

      if (step.state === "visible") {

        const visibleCandidates = [];

        const count = await candidates.count();

        for (let i = 0; i < count; i++) {

          const candidate = candidates.nth(i);

          if (await candidate.isVisible()) {

            visibleCandidates.push(candidate);

          }

          if (visibleCandidates.length > 1) {

            break;

          }

        }

        if (visibleCandidates.length === 1) {

          return (

            `Original selector "${step.selector}" was unavailable. ` +

            `Found one visible <${tag}> element instead.`

          );

        }

      }

      if (step.state === "attached") {

        const count = await candidates.count();

        if (count === 1) {

          return (

            `Original selector "${step.selector}" was unavailable. ` +

            `Found one attached <${tag}> element instead.`

          );

        }

      }

    } catch {

      // Continue to the diagnostic error.

    }

    const diagnostic = await getPageDiagnostic(page);

    throw new Error(

      `Selector "${step.selector}" was not found, and a unique <${tag}> fallback could not be confirmed.` +

      diagnostic

    );

  }

}

/* -------------------------------------------------------

   WORKFLOW STEP EXECUTION

\------------------------------------------------------- */

async function executeStep(context, page, step, profileId) {
  if (step.scopeOrigin) {
    if (step.action !== "navigate") swarmerUrl(page.url(), step.scopeOrigin);
    if (step.sourceUrl && page.url() !== step.sourceUrl) throw new Error(`Expected to be on ${step.sourceUrl}. The browser is on ${page.url()}.`);
    if (["click", "fill", "press"].includes(step.action) || step.action === "scroll" && step.selector) {
      return executeSwarmerTarget(page, step);
    }
  }

  const loc = () => locate(page, step);

  /* Navigation */

  if (step.action === "navigate") {

    if (step.scopeOrigin) swarmerUrl(step.url, step.scopeOrigin);
    const response = await page.goto(step.url, {

      waitUntil: "domcontentloaded",

      timeout: NAVIGATION_TIMEOUT_MS

    });

    if (step.scopeOrigin) {
      swarmerUrl(page.url(), step.scopeOrigin);
      if (response && (!response.ok() || !isHtmlContentType(response.headers()["content-type"]))) {
        throw new Error(`Expected an HTML page at ${step.url}. Received HTTP ${response.status()}.`);
      }
      if (page.url() !== step.url) throw new Error(`Expected to open ${step.url}. The browser landed on ${page.url()}.`);
    }
    if (step.verifyHtml) {
      const contentType = response?.headers()["content-type"];
      if (!response?.ok() || response.status() === 204 || !isHtmlContentType(contentType)) {
        const actual = response ? `HTTP ${response.status()} (${contentType || "unknown content type"})` : "no document response";
        throw new Error(`Expected an HTML page at ${step.url}. Received ${actual}.`);
      }
      const actual = new URL(page.url());
      const expected = new URL(step.url);
      actual.hash = expected.hash = "";
      if (actual.href !== expected.href) {
        throw new Error(`Expected to open ${step.url}. The browser landed on ${page.url()}.`);
      }
      const journey = step.journeyName ? `Started journey ${step.journeyName} · ` : "";
      return `${journey}Opened HTML page ${page.url()} · HTTP ${response.status()}`;
    }
    return `Navigated to ${page.url()}`;

  }

  if (step.action === "back") {

    await page.goBack({

      waitUntil: "domcontentloaded",

      timeout: NAVIGATION_TIMEOUT_MS

    });

    if (step.scopeOrigin) swarmerUrl(page.url(), step.scopeOrigin);
    return "Went back in page history";

  }

  if (step.action === "forward") {

    await page.goForward({

      waitUntil: "domcontentloaded",

      timeout: NAVIGATION_TIMEOUT_MS

    });

    return "Went forward in page history";

  }

  if (step.action === "reload") {

    await page.reload({

      waitUntil: "domcontentloaded",

      timeout: NAVIGATION_TIMEOUT_MS

    });

    return "Reloaded the page";

  }

  /* Tabs */

  if (step.action === "newtab") {

    const tab = await context.newPage();

    if (step.url) {

      await tab.goto(step.url, {

        waitUntil: "domcontentloaded",

        timeout: NAVIGATION_TIMEOUT_MS

      });

    }

    return `Opened new tab${step.url ? ` at ${tab.url()}` : ""}`;

  }

  if (step.action === "closetab") {

    if (context.pages().length <= 1) {

      throw new Error("Cannot close the only open tab.");

    }

    await page.close();

    return "Closed the active tab";

  }

  if (step.action === "switchtab") {

    const tabs = context.pages().filter(

      p => !p.isClosed()

    );

    if (!tabs[step.index]) {

      throw new Error(`Tab ${step.index + 1} does not exist.`);

    }

    await tabs[step.index].bringToFront();

    return `Switched to tab ${step.index + 1}`;

  }

  /* Waiting */

  if (step.action === "wait") {

    await sleep(step.durationMs);

    return `Waited ${step.durationMs} ms`;

  }

  /* Scrolling */

  if (step.action === "scroll") {

    const end = Date.now() + step.durationMs;

    const delta =

      step.direction === "down"

        ? step.amount

        : -step.amount;

    while (Date.now() < end) {

      await page.mouse.wheel(0, delta);

      await sleep(250);

    }

    return `Scrolled ${step.direction} for ${step.durationMs} ms`;

  }

  /* Selector waiting */

  if (step.action === "waitforselector") {

    return await waitForSelectorWithFallback(page, step);

  }

  if (step.action === "waitforurl") {
    if (step.expectedUrl) {
      await page.waitForURL(url => url.href === step.expectedUrl, { timeout: step.timeoutMs });
      return `Verified page ${page.url()}`;
    }
    const target = step.value;
    await page.waitForFunction(
      expected => window.location.href.includes(expected),
      target,
      { timeout: step.timeoutMs }
    );
    return `Waited for URL to contain "${target}". Current URL: ${page.url()}`;
  }

  if (step.action === "waitforloadstate") {
    await page.waitForLoadState(step.state, { timeout: step.timeoutMs });
    return `Waited for page load state: ${step.state}`;
  }

  if (step.action === "handledialog") {
    return armDialogHandler(page, step.dialogAction, step.promptText);
  }

  /* Text waiting */

  if (step.action === "waitfortext") {

    const element = page.getByText(

      step.value,

      { exact: false }

    ).first();

    await element.waitFor({

      state: "visible",

      timeout: STEP_TIMEOUT_MS

    });

    return `Waited for text: ${step.value}`;

  }

  /* Text extraction */

  if (step.action === "extracttext") {

    const text = (

      await (

        step.selector

          ? page.locator(step.selector).first().innerText({

              timeout: STEP_TIMEOUT_MS

            })

          : page.locator("body").innerText({

              timeout: STEP_TIMEOUT_MS

            })

      )

    ).slice(0, MAX_TEXT_LENGTH);

    return `Extracted text: ${text}`;

  }

  /* Link extraction */

  if (step.action === "extractlinks") {

    const links = await page

      .locator(step.selector || "a[href]")

      .evaluateAll(elements =>

        elements

          .slice(0, 100)

          .map(element => ({

            text: (

              element.innerText ||

              element.getAttribute("aria-label") ||

              ""

            ).trim().slice(0, 200),

            href: element.href

          }))

          .filter(item => item.href)

      );

    return (

      `Extracted ${links.length} link(s): ` +

      JSON.stringify(links)

    );

  }

  /* Screenshot */

  if (step.action === "screenshot") {

    const folder = path.join(

      profilesRoot,

      safeId(profileId),

      "screenshots"

    );

    fs.mkdirSync(folder, { recursive: true });

    const file = path.join(

      folder,

      `ajbot-${Date.now()}.png`

    );

    await page.screenshot({

      path: file,

      fullPage: step.fullPage

    });

    return `Screenshot saved: ${file}`;

  }

  /* Keyboard */

  if (step.action === "press") {

    if (step.selector) {

      const element = await loc();

      await element.waitFor({

        state: "visible",

        timeout: STEP_TIMEOUT_MS

      });

      await element.press(step.key, {

        timeout: STEP_TIMEOUT_MS

      });

    } else {

      await page.keyboard.press(step.key);

    }

    return `Pressed ${step.key}`;

  }

  /* Element actions */

  const element = await loc();

  await element.waitFor({

    state: "visible",

    timeout: STEP_TIMEOUT_MS

  });

  if (

    step.action === "click" ||

    step.action === "clicktext" ||

    step.action === "clickrole"

  ) {

    const clickResult = await clickAndDetectPopup(page, element);
    return clickResult.popup
      ? `Clicked ${step.value || step.selector || step.role}. ${clickResult.detail}`
      : `Clicked ${step.value || step.selector || step.role}. ${clickResult.detail}`;

  }

  if (step.action === "doubleclick") {

    const popupWait = page.waitForEvent("popup", { timeout: 1800 }).catch(() => null);
    await element.dblclick({ timeout: STEP_TIMEOUT_MS });
    const popup = await popupWait;
    if (popup && !popup.isClosed()) {
      await popup.bringToFront().catch(() => {});
      await popup.waitForLoadState("domcontentloaded", { timeout: 5000 }).catch(() => {});
      return `Double-clicked ${step.selector}. Opened popup tab: ${popup.url()}`;
    }
    return `Double-clicked ${step.selector}. No popup detected`;

  }

  if (step.action === "rightclick") {

    await element.click({

      button: "right",

      timeout: STEP_TIMEOUT_MS

    });

    return `Right-clicked ${step.selector}`;

  }

  if (step.action === "hover") {

    await element.hover({

      timeout: STEP_TIMEOUT_MS

    });

    return `Hovered over ${step.selector}`;

  }

  if (step.action === "fill") {

    await element.fill(step.value, {

      timeout: STEP_TIMEOUT_MS

    });

    return `Filled ${step.selector}`;

  }

  if (step.action === "filllabel") {

    await page

      .getByLabel(step.label, { exact: false })

      .first()

      .fill(step.value, {

        timeout: STEP_TIMEOUT_MS

      });

    return `Filled field labelled ${step.label}`;

  }

  if (step.action === "type") {

    await element.pressSequentially(step.value, {

      timeout: STEP_TIMEOUT_MS,

      delay: 35

    });

    return `Typed into ${step.selector}`;

  }

  if (step.action === "clear") {

    await element.clear({

      timeout: STEP_TIMEOUT_MS

    });

    return `Cleared ${step.selector}`;

  }

  if (step.action === "select") {

    await element.selectOption(step.value, {

      timeout: STEP_TIMEOUT_MS

    });

    return `Selected ${step.value} in ${step.selector}`;

  }

  if (step.action === "check") {

    await element.check({

      timeout: STEP_TIMEOUT_MS

    });

    return `Checked ${step.selector}`;

  }

  if (step.action === "uncheck") {

    await element.uncheck({

      timeout: STEP_TIMEOUT_MS

    });

    return `Unchecked ${step.selector}`;

  }

  throw new Error(

    `Unsupported workflow action: ${step.action}`

  );

}

/* -------------------------------------------------------

   WORKFLOW EXECUTION

\------------------------------------------------------- */

async function waitForRunControl(run) {
  while (run.paused && !run.stopped) {
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  if (run.stopped) throw new Error("Workflow stopped by the user at a safe step boundary.");
}

async function pauseAfterStepIfNeeded(run) {
  if (run.stepMode) {
    run.paused = true;
    await waitForRunControl(run);
  }
}

function controlRun(profileId, action) {
  const run = activeRuns.get(safeId(profileId));
  if (!run) throw new Error("No active workflow run exists for this browser profile.");
  if (action === "pauseWorkflow") run.paused = true;
  else if (action === "resumeWorkflow") run.paused = false;
  else if (action === "stopWorkflow") { run.stopped = true; run.paused = false; }
  else throw new Error("Unknown workflow control action.");
  return { ok: true, message: action === "pauseWorkflow" ? "Workflow will pause at the next safe step boundary." : action === "resumeWorkflow" ? "Workflow resumed." : "Stop requested. The current step will finish before another step starts." };
}

async function runWorkflow(message) {
  const profileId = safeId(message.profileId), workflowId = safeId(message.workflowId);
  if (!profileId || !workflowId) throw new Error("A valid browser profile and workflow are required.");
  const context = getRunningContext(profileId);
  const workflow = readWorkflows().find(item => item.id === workflowId);
  if (!workflow) throw new Error("Workflow not found.");
  const expandRepeats = list => list.flatMap(({ repeatCount = 1, ...step }) => {
    if (step.thenSteps) {
      step.thenSteps = expandRepeats(step.thenSteps);
      step.elseSteps = expandRepeats(step.elseSteps);
    }
    return Array(repeatCount).fill(step);
  });
  const steps = expandRepeats(validateWorkflowSteps(workflow.steps));
  const maxActions = list => list.reduce((total, step) => total + 1 + (step.thenSteps
    ? Math.max(maxActions(step.thenSteps), maxActions(step.elseSteps)) : 0), 0);
  if (maxActions(steps) > 100) throw new Error("Reduce repeats and branches to at most 100 actions per run.");
  if (activeRuns.has(profileId)) throw new Error("A workflow is already running for this browser profile.");
  const runId = `run-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const run = { id: runId, profileId, paused: false, stopped: false, stepMode: message.stepMode === true };
  const runStartedAt = Date.now();
  const runRecord = { id: runId, workflowId, workflowName: workflow.name, profileId, source: message.runSource === "scheduled" ? "scheduled" : "manual", status: "running", startedAt: runStartedAt, finishedAt: null, durationMs: null, currentStep: 0, totalSteps: steps.length, steps: [], message: "Workflow started." };
  activeRuns.set(profileId, run);
  emitRunEvent({ type: "run_started", run: runRecord });
  const variables = Object.assign(Object.create(null), workflow.variables || {});
  const results = [];
  let executed = 0;
  const interpolate = value => typeof value === "string"
    ? value.replace(/\{\{([A-Za-z_][A-Za-z0-9_]{0,63})\}\}/g, (m,k) => Object.prototype.hasOwnProperty.call(variables,k) ? String(variables[k]) : m)
    : value;
  const expand = step => {
    const out = {...step};
    for (const key of ["url","selector","value","key","role","label","name","promptText"]) if (typeof out[key] === "string") out[key] = interpolate(out[key]);
    return out;
  };
  const condition = async (step,page) => {
    const op=step.operator||"contains"; let actual="";
    if(step.action==="iftext") actual=await page.locator("body").innerText({timeout:STEP_TIMEOUT_MS}).catch(()=>"");
    if(step.action==="ifurl") actual=page.url();
    if(step.action==="ifvariable") {
      const exists=Object.prototype.hasOwnProperty.call(variables,step.name);
      if(op==="exists") return exists;
      actual=exists?String(variables[step.name]):"";
    }
    const expected=String(interpolate(step.value)??"");
    if(op==="exists") return actual.length>0;
    if(op==="equals") return actual===expected;
    if(op==="notContains") return !actual.includes(expected);
    return actual.includes(expected);
  };
  const runList = async (list,depth=0) => {
    if(depth>1) throw new Error("Conditional nesting limit exceeded.");
    for(const original of list) {
      await waitForRunControl(run);
      if(++executed>100) throw new Error("Execution stopped at the 100-step safety limit.");
      const step=expand(original), stepNo=executed, started=Date.now(), startedAt=new Date().toISOString();
      runRecord.currentStep = stepNo;
      emitRunEvent({ type: "step_started", runId, step: { step: stepNo, action: step.action, status: "running", startedAt, stepDefinition: step }, currentStep: stepNo, totalSteps: steps.length });
      if (
  requiresConsequentialApproval(step) &&
  message.approveConsequential !== true
) {
  const approvalResult = {
    step: stepNo,
    action: step.action,
    ok: false,
    status: "waiting_approval",
    requiresApproval: true,
    detail:
      step.riskReason ||
      "Explicit user approval is required.",
    startedAt,
    durationMs: Date.now() - started,
    attempts: 0
  };

  results.push(approvalResult);

  runRecord.steps.push(historyStep(approvalResult));

  emitRunEvent({
    type: "step_completed",
    runId,
    step: approvalResult,
    currentStep: stepNo,
    totalSteps: steps.length
  });

  return false;
}
      if(step.action==="setvariable") {
        variables[step.name]=interpolate(step.value);
        results.push({step:stepNo,action:step.action,stepDefinition:step,ok:true,status:"completed",detail:`Set variable ${step.name}.`,startedAt,durationMs:Date.now()-started,attempts:1});
        runRecord.steps.push(historyStep(results[results.length - 1])); emitRunEvent({ type: "step_completed", runId, step: results[results.length - 1], currentStep: stepNo, totalSteps: steps.length });
        await pauseAfterStepIfNeeded(run);
        continue;
      }
      if(["iftext","ifurl","ifvariable"].includes(step.action)) {
        const page=getActivePage(context), matched=await condition(step,page);
        results.push({step:stepNo,action:step.action,stepDefinition:step,ok:true,status:"completed",detail:`Condition ${matched?"matched":"did not match"}; ${matched?"then":"else"} branch selected.`,startedAt,durationMs:Date.now()-started,attempts:1,url:page.url()});
        runRecord.steps.push(historyStep(results[results.length - 1])); emitRunEvent({ type: "step_completed", runId, step: results[results.length - 1], currentStep: stepNo, totalSteps: steps.length });
        await pauseAfterStepIfNeeded(run);
        if(!await runList(matched?step.thenSteps:step.elseSteps,depth+1)) return false;
        continue;
      }
      let success=false,lastError="",detail="",activePage,attempts=0;
      const maxAttempts=Math.min(3,step.retryCount||0)+1;
      for(let attempt=1;attempt<=maxAttempts;attempt++) {
        attempts=attempt;
        try {
          const page=getActivePage(context);
          activePage=page;
          detail=await executeStep(context,page,step,profileId);
          activePage=getActivePage(context); success=true; break;
        } catch(error) {
          lastError=errorMessage(error);
          if(requiresConsequentialApproval(step)||attempt===maxAttempts) break;
          await sleep(Math.min(10000,step.retryDelayMs||500));
        }
      }
      let failureScreenshot;
      if (!success && activePage && !activePage.isClosed()) {
        try {
          const dir = path.join(profilesRoot, profileId);
          fs.mkdirSync(dir, { recursive: true });
          failureScreenshot = path.join(dir, `failure-${Date.now()}-${stepNo}.png`);
          await activePage.screenshot({ path: failureScreenshot, fullPage: false, timeout: 5000 });
        } catch (screenshotError) { log(`Failure screenshot unavailable: ${errorMessage(screenshotError)}`); }
      }
      results.push({step:stepNo,action:step.action,stepDefinition:step,ok:success,status:success?"completed":"failed",detail:success?detail:lastError,startedAt,durationMs:Date.now()-started,attempts,screenshot:failureScreenshot,url:activePage&&!activePage.isClosed()?activePage.url():undefined,title:activePage&&!activePage.isClosed()?await activePage.title().catch(()=>""):undefined});
      runRecord.steps.push(historyStep(results[results.length - 1]));
      emitRunEvent({ type: "step_completed", runId, step: results[results.length - 1], currentStep: stepNo, totalSteps: steps.length });
      if(!success) return false;
      await pauseAfterStepIfNeeded(run);

    }
    return true;
  };
  try {
   const completed = await runList(steps);
const stopped = run.stopped;

const needsApproval = results.some(
  item => item.requiresApproval === true
);

const finalStatus = stopped
  ? "stopped"
  : completed
    ? "completed"
    : needsApproval
      ? "needs_approval"
      : "failed";

const finalMessage = stopped
  ? `Workflow "${workflow.name}" stopped by user after ${executed} steps.`
  : completed
    ? `Workflow "${workflow.name}" completed (${executed} steps).`
    : needsApproval
      ? `Workflow "${workflow.name}" is waiting for approval at step ${executed}.`
      : `Workflow "${workflow.name}" failed after ${executed} steps.`;

runRecord.status = finalStatus;
runRecord.message = finalMessage;
runRecord.finishedAt = Date.now();
runRecord.durationMs = runRecord.finishedAt - runStartedAt;
runRecord.currentStep = executed;

writeRunHistory([
  runRecord,
  ...readRunHistory()
]);

emitRunEvent({
  type: "run_finished",
  run: runRecord
});

return {
  ok: completed && !stopped,
  message: finalMessage,
  results,
  variables,
  status: finalStatus
};
  } catch(error) {
    const stopped = run.stopped;
    runRecord.status = stopped ? "stopped" : (results.some(item => item.requiresApproval) ? "needs_approval" : "failed");
    runRecord.message = errorMessage(error); runRecord.finishedAt = Date.now(); runRecord.durationMs = runRecord.finishedAt - runStartedAt; runRecord.currentStep = executed;
    writeRunHistory([runRecord, ...readRunHistory()]); emitRunEvent({ type: "run_finished", run: runRecord });
    return {ok:false,message:`Workflow "${workflow.name}" ${stopped?"stopped":"failed"}: ${errorMessage(error)}`,error:errorMessage(error),results,variables,status:stopped?"stopped":"failed"};
  } finally {
    activeRuns.delete(profileId);
  }
}

/* -------------------------------------------------------

   AI WORKFLOW PLANNING

\------------------------------------------------------- */

function plannerPrompt(task, pageContext = null) {

  return [

    "You are Ajbot Studio's browser workflow planner.",

    "Return only valid JSON, no Markdown.",

    'Schema: {"name":"Short name","steps":[{"action":"navigate","url":"https://example.com"}]}',

    "Allowed actions: navigate, back, forward, reload, newTab, closeTab, switchTab, click, clickText, clickRole, doubleClick, rightClick, hover, fill, fillLabel, type, clear, press, select, check, uncheck, scroll, wait, waitForSelector, waitForURL, waitForLoadState, handleDialog, waitForText, extractText, extractLinks, screenshot.",

    "Fields: navigate url; click/doubleClick/rightClick/hover/fill/type/clear/select/check/uncheck/waitForSelector/extractText/extractLinks selector; waitForURL value and optional timeoutMs; waitForLoadState optional state(load/domcontentloaded/networkidle) and timeoutMs; handleDialog optional dialogAction(accept/dismiss) and promptText; clickText/waitForText value; clickRole role and value; fillLabel label and value; press key and optional selector; scroll direction(up/down), durationMs(250-10000), optional amount; wait durationMs(0-30000); switchTab index (zero-based); newTab optional url; screenshot optional fullPage.",

    "Prefer accessible roles, labels and visible text.",

    "Use actual page information supplied below instead of inventing selectors.",

    "Do not assume a website has a particular CSS class.",

    "When a page has not been inspected, use extractText or extractLinks before interacting with unknown elements.",

    "Avoid selectors that depend on guessed CSS classes.",

    "If a target is ambiguous, do not guess or click an arbitrary element.",
    "A click can open a popup; report it and continue on the newly opened tab.",
    "Use handleDialog immediately before an action expected to open a browser dialog. Choose accept or dismiss explicitly; never assume acceptance.",

    "Variables are strings and use {{name}} interpolation. Supported control steps: setVariable, ifText, ifUrl, ifVariable with thenSteps/elseSteps. Safe steps may set retryCount 0-3 and retryDelayMs 0-10000. Mark consequential actions with requiresApproval=true and explain riskReason.",

    "Consequential actions include submitting forms, sending messages, publishing, purchases, account changes, downloads, file uploads, and deletion.",

    "Never bypass logins, CAPTCHAs, access controls, paywalls, or bot protections.",

    "Never install files or submit sensitive forms automatically.",

    pageContext

      ? `CURRENT PAGE INSPECTION:\n${JSON.stringify(pageContext, null, 2)}`

      : "No current page inspection is available. Do not invent website-specific selectors.",

    `USER TASK: ${task}`

  ].join("\n");

}

function extractJson(text) {

  const cleaned = String(text || "")

    .trim()

    .replace(/^```(?:json)?\s*/i, "")

    .replace(/\s*```$/, "");

  try {

    return JSON.parse(cleaned);

  } catch {

    const start = cleaned.indexOf("{");

    const end = cleaned.lastIndexOf("}");

    if (start < 0 || end <= start) {

      throw new Error(

        "The AI provider did not return valid JSON."

      );

    }

    return JSON.parse(

      cleaned.slice(start, end + 1)

    );

  }

}

async function readProviderResponse(response, providerName) {

  let data;

  try {

    data = await response.json();

  } catch {

    throw new Error(

      `${providerName} returned an unreadable response.`

    );

  }

  if (!response.ok) {

    throw new Error(

      data.error?.message ||

      data.error ||

      `${providerName} request failed (${response.status}).`

    );

  }

  return data;

}

async function callOpenAI(model, apiKey, prompt, signal) {

  const response = await fetch(

    "https://api.openai.com/v1/chat/completions",

    {

      method: "POST",

      headers: {

        "Content-Type": "application/json",

        Authorization: `Bearer ${apiKey}`

      },

      body: JSON.stringify({

        model,

        messages: [

          {

            role: "system",

            content: "Return valid JSON only."

          },

          {

            role: "user",

            content: prompt

          }

        ],

        temperature: 0.2,

        response_format: {

          type: "json_object"

        }

      }),

      signal: signal ? AbortSignal.any([signal,AbortSignal.timeout(120000)]) : AbortSignal.timeout(120000)

    }

  );

  const data = await readProviderResponse(

    response,

    "OpenAI"

  );

  return data.choices?.[0]?.message?.content;

}

async function callOllama(model, prompt, signal) {

  const response = await fetch(

    "http://127.0.0.1:11434/api/chat",

    {

      method: "POST",

      headers: {

        "Content-Type": "application/json"

      },

      body: JSON.stringify({

        model,

        stream: false,

        format: "json",

        messages: [

          {

            role: "system",

            content:

              "Return valid JSON only. Follow the workflow schema exactly."

          },

          {

            role: "user",

            content: prompt

          }

        ],

        options: {

          temperature: 0.2

        }

      }),

      signal: signal ? AbortSignal.any([signal,AbortSignal.timeout(120000)]) : AbortSignal.timeout(120000)

    }

  );

  const data = await readProviderResponse(

    response,

    "Ollama"

  );

  return data.message?.content;

}

async function planWorkflow(message) {

  const task = String(message.task || "").trim();

  const provider = String(

    message.provider || "openai"

  ).trim().toLowerCase();

  const model = String(message.model || "").trim();

  const apiKey = String(message.apiKey || "").trim();

  if (!task) {

    throw new Error("Describe the browser task first.");

  }

  if (task.length > 3000) {

    throw new Error("The task description is too long.");

  }

  if (!model) {

    throw new Error("Select an AI model first.");

  }

  if (provider !== "ollama" && !apiKey) {

    throw new Error(

      "An API key is required for this planning provider."

    );

  }

  if (message.url) {
    const plan = await planSwarmer({ ...message, task, provider, model, apiKey }, { chromium, ask: askPlanner, parse: extractJson });
    return { ...plan, journeys: plan.journeys.map(journey => ({ ...journey, steps: validateWorkflowSteps(journey.steps) })) };
  }

  /*

   * Inspect the currently active browser page when

   * the frontend supplies a running profileId.

   */

  let pageContext = null;

  if (message.profileId) {

    try {

      const context = getRunningContext(

        message.profileId

      );

      const page = getActivePage(context);

      pageContext = await inspectPage(page);

    } catch (error) {

      log(

        `Page inspection unavailable: ${errorMessage(error)}`

      );

    }

  }

  const prompt = plannerPrompt(

    task,

    pageContext

  );

  let content;

  if (provider === "ollama") {

    content = await callOllama(model, prompt);

  } else if (provider === "openai") {

    content = await callOpenAI(

      model,

      apiKey,

      prompt

    );

  } else {

    content = await callHostedPlanner(provider, model, apiKey, prompt);

  }

  const plan = extractJson(content);

  if (!plan || !Array.isArray(plan.steps)) {

    throw new Error(

      "The AI provider returned an invalid workflow plan."

    );

  }

  return {

    name: String(

      plan.name || "AI-generated workflow"

    ).slice(0, 120),

    task,

    steps: validateWorkflowSteps(plan.steps)

  };

}

/* -------------------------------------------------------

   WORKER REQUEST HANDLER

\------------------------------------------------------- */

async function handle(message) {

  const id = message?.id;

  const action = message?.action;

  try {

    /* Shutdown */

    if (action === "shutdown") {
      await stopAllAgents();
      await qaWorkspace?.close();

      for (const [pid, context] of sessions) {

        try {

          await context.close();

        } catch (error) {

          log(

            `Could not close ${pid}: ${errorMessage(error)}`

          );

        }

      }

      sessions.clear();

      respond({

        id,

        ok: true

      });

      shuttingDown = true;

      rl.close();

      return;

    }

    if (["pauseWorkflow", "resumeWorkflow", "stopWorkflow"].includes(action)) {
      const result = controlRun(message.profileId, action);
      respond({ id, ...result });
      return;
    }

    if (["startRecorder", "pauseRecorder", "resumeRecorder", "stopRecorder"].includes(action)) {
      const pid = safeId(message.profileId);
      if (!pid) throw new Error("Select a valid browser profile.");
      const context = getRunningContext(pid);
      if (action === "startRecorder") {
        if (recorders.has(pid) && recorders.get(pid).status !== "stopped") throw new Error("A recording is already active for this profile.");
        const state = { status: "recording", actions: [], snapshots: [], diagnostics: [], lastUrl: getActivePage(context).url(), lastSignature: "", lastRecordedAt: 0 };
        recorders.set(pid, state);
        persistRecorder(pid, state);
        attachRecorder(context, pid);
        emitRecorderEvent({ type: "recorder_status", profileId: pid, status: "recording" });
        respond({ id, ok: true, result: { status: state.status, actions: [] } });
        return;
      }
      const state = recorders.get(pid);
      if (!state) throw new Error("No recording exists for this profile.");
      if (action === "pauseRecorder") state.status = "paused";
      if (action === "resumeRecorder") state.status = "recording";
      if (action === "stopRecorder") state.status = "stopped";
      persistRecorder(pid, state);
      emitRecorderEvent({ type: "recorder_status", profileId: pid, status: state.status });
      respond({ id, ok: true, result: { status: state.status, actions: state.actions } });
      return;
    }

    if (action === "getRecorderRecovery") {
      const pid = safeId(message.profileId);
      if (!pid) throw new Error("Select a valid browser profile.");
      let recovery = null;
      try { recovery = JSON.parse(fs.readFileSync(recorderRecoveryPath(pid), "utf8")); }
      catch { recovery = null; }
      respond({ id, ok: true, recovery });
      return;
    }

    if (action === "validateRecording") {
      const pid = safeId(message.profileId);
      const actions = Array.isArray(message.actions) ? message.actions.slice(0, 2000) : [];
      if (!pid) throw new Error("Select a valid browser profile.");
      if (!actions.length) throw new Error("There are no recorded actions to validate.");
      const supported = new Set(["navigate", "click", "doubleclick", "fill", "select", "check", "uncheck", "newTab", "closeTab"]);
      const issues = [];
      actions.forEach((item, index) => {
        if (!item || !supported.has(String(item.action || ""))) issues.push({ index, level: "error", message: "Unsupported recorded action." });
        else if (["click", "doubleclick", "fill", "select", "check", "uncheck"].includes(item.action) && !String(item.selector || "").trim()) issues.push({ index, level: "warning", message: "Action has no CSS selector and needs review." });
        else if (item.selectorConfidence === "low") issues.push({ index, level: "warning", message: "Selector confidence is low; verify it before playback." });
      });
      respond({ id, ok: true, result: { valid: !issues.some(item => item.level === "error"), actionCount: actions.length, issues, dryRun: true } });
      return;
    }

    if (action === "profileStorageStatus") {
  const pid = safeId(message.profileId);
  if (!pid) throw new Error("A valid profile ID is required.");

  const recording = recorders.get(pid);
  const locked = isProfileLocked(pid);

  const busy =
    sessions.has(pid) ||
    activeRuns.has(pid) ||
    !!(recording && recording.status !== "stopped") ||
    locked;

  const reason = sessions.has(pid)
    ? "The browser profile is running."
    : activeRuns.has(pid)
      ? "A workflow is running for this profile."
      : recording && recording.status !== "stopped"
        ? "A recording is active for this profile."
        : locked
          ? "Profile storage is locked by another process."
          : null;

  respond({ id, ok: true, data: { busy, reason } });
  return;
}

    /* Update browser profile metadata without touching Chromium user data. */
    if (action === "updateProfile") {
      const pid = safeId(message.profileId);
      if (!pid) throw new Error("A valid profile ID is required.");
if (isProfileLocked(pid)) {
  throw new Error("This profile is locked. Stop the browser or backup operation before editing its settings.");
}
      const dir = path.join(profilesRoot, pid);
      if (!fs.existsSync(dir)) throw new Error("Profile not found.");
      const dirStat = fs.lstatSync(dir);
      if (!dirStat.isDirectory() || dirStat.isSymbolicLink()) throw new Error("The profile storage path is not a safe local directory.");
      const name = String(message.name || "").trim();
      if (!name || name.length > 80) throw new Error("Profile name must contain between 1 and 80 characters.");
      const startUrl = message.url == null || String(message.url).trim() === "" ? null : normalizeUrl(message.url);
      const deviceClass = profileDeviceClass(readMetadata(dir).deviceClass);
      saveMetadata(dir, pid, name, startUrl, deviceClass);
      respond({ id, ok: true, profile: { id: pid, name, startUrl, deviceClass, running: sessions.has(pid) } });
      return;
    }
    if (action === "deleteProfile") {
      const pid = safeId(message.profileId);
      if (!pid) throw new Error("A valid profile ID is required.");
      if (isProfileLocked(pid)) {
  throw new Error("This profile is locked. Stop the browser or backup operation before deleting it.");
}
      if (sessions.has(pid)) throw new Error("Stop this browser profile before deleting it.");
      if (activeRuns.has(pid)) throw new Error("A workflow is active for this profile. Stop it before deleting the profile.");
      const recording = recorders.get(pid);
      if (recording && recording.status !== "stopped") throw new Error("Stop the active recording before deleting this profile.");
      const dir = path.join(profilesRoot, pid);
      if (!fs.existsSync(dir)) throw new Error("Profile not found.");
      const stat = fs.lstatSync(dir);
      if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("The profile storage path is not a safe local directory.");
      fs.rmSync(dir, { recursive: true, force: false });
      recorders.delete(pid);
      respond({ id, ok: true, message: "Browser profile and its local browser data were deleted." });
      return;
    }
    /* Create browser profile */

    if (action === "create") {

      const pid = safeId(message.profileId);

      if (!pid) {

        throw new Error("A valid profile ID is required.");

      }

      const dir = path.join(profilesRoot, pid);

      const existed = fs.existsSync(dir);

      fs.mkdirSync(dir, {

        recursive: true

      });

      const meta = readMetadata(dir);

      const name =

        String(message.name || meta.name || pid).trim() ||

        pid;

      const startUrl =

        normalizeUrl(message.url) ||

        meta.startUrl ||

        null;

      const deviceClass = profileDeviceClass(message.agentOptions?.deviceClass) || profileDeviceClass(meta.deviceClass);
      saveMetadata(

        dir,

        pid,

        name,

        startUrl,
        deviceClass

      );

      respond({

        id,

        ok: true,

        profile: {

          id: pid,

          name,

          startUrl,

          deviceClass,
          created: !existed

        }

      });

      return;

    }

    /* List browser profiles */

    if (action === "list") {

      const profiles = fs

        .readdirSync(profilesRoot, {

          withFileTypes: true

        })

        .filter(entry => entry.isDirectory())

        .map(entry => {

          const meta = readMetadata(

            path.join(profilesRoot, entry.name)

          );

          return {

            id: entry.name,

            name: String(meta.name || entry.name),

            startUrl: meta.startUrl || null,

            deviceClass: profileDeviceClass(meta.deviceClass),
            running: sessions.has(entry.name)

          };

        });

      respond({

        id,

        ok: true,

        profiles

      });

      return;

    }

    /* Launch browser profile */

    if (action === "launch") {

      const pid = safeId(message.profileId);
      const context = await openProfileContext(pid, { deviceClass: message.agentOptions?.deviceClass, proxy: message.proxy });
      const target = normalizeUrl(message.url) || normalizeUrl(readMetadata(path.join(profilesRoot, pid)).startUrl);
      sessions.set(pid, context);
      context.once("close", () => {
        sessions.delete(pid);
        log(`Browser context closed: ${pid}`);
      });

      const page =

        context.pages()[0] ||

        await context.newPage();

      if (recorders.has(pid)) attachRecorder(context, pid);

      if (target) {

        try {

          await page.goto(target, {

            waitUntil: "domcontentloaded",

            timeout: NAVIGATION_TIMEOUT_MS

          });

        } catch (error) {

          log(

            `Initial navigation failed: ${errorMessage(error)}`

          );

        }

      }

      respond({

        id,

        ok: true,

        message: target

          ? `Browser launched at ${target}`

          : "Browser launched without a starting URL."

      });

      return;

    }

    /* Close browser profile */

    if (action === "close") {

      const pid = safeId(message.profileId);

      const context = sessions.get(pid);

      if (!context) {

        throw new Error(

          "This profile is not running."

        );

      }

      await context.close();

      sessions.delete(pid);

      respond({

        id,

        ok: true,

        message: "Browser closed."

      });

      return;

    }

    /* List workflows */

    if (action === "listWorkflows") {

      respond({

        id,

        ok: true,

        workflows: readWorkflows()

      });

      return;

    }

    /* Save workflow */

    if (action === "saveWorkflow") {

      const wid = safeId(message.workflowId);

      const name = String(

        message.workflowName || ""

      ).trim();

      if (!wid) {

        throw new Error(

          "A valid workflow ID is required."

        );

      }

      if (!name) {

        throw new Error("Workflow name is required.");

      }

      if (name.length > 120) {

        throw new Error(

          "Workflow name must be 120 characters or fewer."

        );

      }

      const steps = validateWorkflowSteps(

        message.steps

      );

      const workflows = readWorkflows();

      const index = workflows.findIndex(

        workflow => workflow.id === wid

      );

      const previous = index >= 0 ? workflows[index] : {};
      const variables = message.variables && typeof message.variables === "object" && !Array.isArray(message.variables)
        ? Object.fromEntries(Object.entries(message.variables).slice(0, 50).map(([key, value]) => {
            if (!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(key)) throw new Error(`Invalid variable name: ${key}`);
            return [key, String(value).slice(0, 10000)];
          }))
        : (previous.variables || {});
      const workflow = { ...previous, id: wid, name, steps, variables, updatedAt: new Date().toISOString() };

      if (index >= 0) {

        workflows[index] = workflow;

      } else {

        workflows.push(workflow);

      }

      writeWorkflows(workflows);

      respond({

        id,

        ok: true,

        workflow

      });

      return;

    }

    /* Delete workflow */

    if (action === "deleteWorkflow") {

      const wid = safeId(message.workflowId);

      if (!wid) {

        throw new Error(

          "A valid workflow ID is required."

        );

      }

      const workflows = readWorkflows();

      const rest = workflows.filter(

        workflow => workflow.id !== wid

      );

      if (rest.length === workflows.length) {

        throw new Error("Workflow not found.");

      }

      writeWorkflows(rest);

      respond({

        id,

        ok: true,

        message: "Workflow deleted."

      });

      return;

    }

    if (action === "listRunHistory") { respond({ id, ok: true, runs: readRunHistory() }); return; }
    if (action === "runWorkflowScheduled") { const result = await runWorkflow({ ...message, runSource: "scheduled" }); respond({ id, ...result }); return; }

    if (action === "qaWorkspace") {
      qaWorkspace ||= createQaWorkspace({
        directory: path.join(path.dirname(profilesRoot), "qa-workspace"),
        chromium,
        ask: askPlanner,
        blockedOrigins: ["http://localhost:1420", "http://127.0.0.1:1420"],
      });
      const options = message.agentOptions || {};
      const data = await qaWorkspace.command(options.operation, options.input, message.apiKey);
      respond({ id, ok: true, data });
      return;
    }

    if (action === "runAiAgent") {
      const data = await runAgent(message, {
        chromium,
        openSavedProfile: message.profileId
          ? () => openProfileContext(message.profileId, { proxy: message.proxy, forAgent: true })
          : undefined,
        emit: data => respond({ event: "ai-agent-progress", ok: true, data }),
        ask: (prompt, options) => options.provider === "ollama"
          ? callOllama(options.model, prompt, options.signal)
          : options.provider === "openai"
          ? callOpenAI(options.model, options.apiKey, prompt, options.signal)
          : callHostedPlanner(options.provider, options.model, options.apiKey, prompt, undefined, options.signal)
      });
      respond({ id, ok: true, data }); return;
    }
    if (action === "controlAiAgent") {
      const data = controlAgent(message.workflowId, message.agentOptions?.action, message.agentOptions?.approvalId);
      respond({ id, ok: true, data }); return;
    }

    /* AI workflow planning */

    if (action === "listProviderModels") {
      const data = await listModels(String(message.provider || ""), String(message.apiKey || ""));
      respond({ id, ok: true, data }); return;
    }

    if (action === "planWorkflow") {

      const plan = await planWorkflow(message);

      respond({

        id,

        ok: true,

        plan

      });

      return;

    }

    if (action === "retryFailedStep") {
      const profileId = safeId(message.profileId);
      const step = validateWorkflowSteps(message.steps || [])[0];
      if (!profileId || !step) throw new Error("A browser profile and one valid step are required.");
      if (["setvariable", "iftext", "ifurl", "ifvariable"].includes(step.action)) throw new Error("This step type cannot be retried independently.");
      if (requiresConsequentialApproval(step) && message.approveConsequential !== true) throw new Error("Explicit approval is required before retrying this consequential action.");
      const context = getRunningContext(profileId);
      const page = getActivePage(context);
      const started = Date.now();
      try {
        const detail = await executeStep(context, page, step, profileId);
        respond({ id, ok: true, result: { ok: true, action: step.action, detail, durationMs: Date.now() - started, url: getActivePage(context).url() } });
      } catch (error) {
        let screenshot;
        try { screenshot = path.join(profilesRoot, profileId, `retry-failure-${Date.now()}.png`); await page.screenshot({ path: screenshot, timeout: 5000 }); } catch {}
        respond({ id, ok: false, error: errorMessage(error), result: { ok: false, action: step.action, detail: errorMessage(error), durationMs: Date.now() - started, screenshot } });
      }
      return;
    }

    /* Execute workflow */

    if (action === "runWorkflow") {

      const result = await runWorkflow(message);

      respond({

        id,

        ...result

      });

      return;

    }

    throw new Error(

      `Unknown worker action: ${action}`

    );

  } catch (error) {

    respond({

      id,

      ok: false,

      error: errorMessage(error)

    });

  }

}

/* -------------------------------------------------------

   JSON-LINE REQUEST QUEUE

\------------------------------------------------------- */

rl.on("line", line => {
  if (shuttingDown) return;
  let message;
  try { message = JSON.parse(line); }
  catch { respond({ ok: false, error: "Invalid JSON request." }); return; }
  const action = message?.action;
  // Runs and live controls must bypass the ordinary request queue. Otherwise a
  // long workflow would prevent its own pause/resume/stop messages from arriving.
  if (["runWorkflow", "runAiAgent", "controlAiAgent", "qaWorkspace"].includes(action) || ["pauseWorkflow", "resumeWorkflow", "stopWorkflow", "pauseRecorder", "resumeRecorder", "stopRecorder", "getRecorderRecovery", "validateRecording"].includes(action)) {
    void handle(message);
    return;
  }
  requestQueue = requestQueue.then(() => handle(message)).catch(error => {
    respond({ id: message?.id, ok: false, error: errorMessage(error) });
  });
});

rl.on("close", () => {

  requestQueue.finally(() => {

    if (!shuttingDown) {

      log("Input stream closed.");

    }

  });

});

/* -------------------------------------------------------

   PROCESS ERROR HANDLING

\------------------------------------------------------- */

process.on("uncaughtException", error => {

  log(

    `Uncaught exception: ${errorMessage(error)}`

  );

});

process.on("unhandledRejection", error => {

  log(

    `Unhandled rejection: ${errorMessage(error)}`

  );

});
