"""Classify the built-in AJBOT grid using the uploaded project's YOLO export."""

import ast
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
MODEL = HERE / "recaptcha_classification_57k.onnx"
# The uploaded YOLO detector pins this exact model and maps buses to class 2.
MODEL_SHA256 = "4092e8917ee8c2963895d66ba10a97d6ef975c468a95858a8a7bd9e70681b65d"
BUS_CLASS = 2


def main():
    if not MODEL.is_file():
        return 4
    if MODEL.stat().st_size > 128 * 1024 * 1024:
        return 5
    with MODEL.open("rb") as model_file:
        digest = hashlib.sha256()
        for chunk in iter(lambda: model_file.read(65536), b""):
            digest.update(chunk)
    if digest.hexdigest() != MODEL_SHA256:
        return 5

    try:
        import numpy as np
        import onnxruntime as ort
        from PIL import Image
    except ImportError:
        return 3

    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    session = ort.InferenceSession(str(MODEL), sess_options=options, providers=["CPUExecutionProvider"])
    model_input = session.get_inputs()[0]
    # The export has dynamic shapes. Use its training image size for inference.
    size = ast.literal_eval(session.get_modelmeta().custom_metadata_map["imgsz"])
    height, width = (size, size) if isinstance(size, int) else size
    if not (0 < height == width <= 1024):
        raise ValueError("Invalid classifier input size")

    tiles = []
    with Image.open(HERE / "sample-grid.jpg") as source:
        grid = source.convert("RGB")
        tile_size = grid.width // 3
        if grid.size != (tile_size * 3, tile_size * 3):
            raise ValueError("Invalid sample grid")
        for row in range(3):
            for column in range(3):
                left, top = column * tile_size, row * tile_size
                tile = grid.crop((left, top, left + tile_size, top + tile_size))
                tile = tile.resize((width, height), Image.Resampling.BILINEAR)
                tiles.append(np.asarray(tile, dtype=np.float32).transpose(2, 0, 1) / 255)

    batch = np.stack(tiles)
    scores = session.run(None, {model_input.name: batch})[0]
    if scores.shape != (9, 14) or not np.allclose(scores.sum(axis=1), 1, atol=0.001):
        raise ValueError("Invalid classifier output")
    print(json.dumps(scores[:, BUS_CLASS].tolist(), allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
