"use strict";
const fs = require("node:fs");
const path = require("node:path");
const target = path.join(__dirname, "worker.cjs");
const source = fs.readFileSync(target, "utf8");
if (source.includes('action === "updateProfile"') || source.includes('action === "deleteProfile"')) {
  console.log("Profile management worker actions are already installed.");
  process.exit(0);
}
const marker = "    /* Create browser profile */";
const addition = `    /* Update browser profile metadata without touching Chromium user data. */
    if (action === "updateProfile") {
      const pid = safeId(message.profileId);
      if (!pid) throw new Error("A valid profile ID is required.");
      if (sessions.has(pid)) throw new Error("Stop this browser profile before editing its settings.");
      const dir = path.join(profilesRoot, pid);
      if (!fs.existsSync(dir)) throw new Error("Profile not found.");
      const dirStat = fs.lstatSync(dir);
      if (!dirStat.isDirectory() || dirStat.isSymbolicLink()) throw new Error("The profile storage path is not a safe local directory.");
      const name = String(message.name || "").trim();
      if (!name || name.length > 80) throw new Error("Profile name must contain between 1 and 80 characters.");
      const startUrl = message.url == null || String(message.url).trim() === "" ? null : normalizeUrl(message.url);
      saveMetadata(dir, pid, name, startUrl);
      respond({ id, ok: true, profile: { id: pid, name, startUrl, running: sessions.has(pid) } });
      return;
    }
    if (action === "deleteProfile") {
      const pid = safeId(message.profileId);
      if (!pid) throw new Error("A valid profile ID is required.");
      if (sessions.has(pid)) throw new Error("Stop this browser profile before deleting it.");
      if (activeRuns.has(pid)) throw new Error("A workflow is active for this profile. Stop it before deleting the profile.");
      const recording = recorders.get(pid);
      if (recording && recording.status !== "stopped") throw new Error("Stop the active recording before deleting this profile.");
      const dir = path.join(profilesRoot, pid);
      if (!fs.existsSync(dir)) throw new Error("Profile not found.");
      const stat = fs.lstatSync(dir);
      if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("The profile storage path is not a safe local directory.");
      fs.rmSync(dir, { recursive: true, force: false });
      recorders.delete(pid);
      respond({ id, ok: true, message: "Browser profile and its local browser data were deleted." });
      return;
    }
`;
if (source.split(marker).length !== 2) throw new Error("Could not find the unique profile handler insertion point; worker.cjs was not changed.");
fs.writeFileSync(target, source.replace(marker, addition + marker), "utf8");
console.log("Installed updateProfile and deleteProfile worker actions.");
