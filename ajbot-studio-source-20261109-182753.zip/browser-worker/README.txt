Ajbot Studio - Batch 5 Recorder Engine Update

REPLACEMENT FILE
1. Back up your existing file:
   browser-worker/worker.cjs
2. Replace it with:
   worker.cjs

WHAT THIS WORKER UPDATE ADDS
- Captures new-tab and tab-close events during recording.
- Saves recorder actions to browser-worker/profiles/<profile-id>/recording-recovery.json as they occur.
- Captures local PNG snapshots after navigation, when a new tab loads, and after the first/every fifth recorded action.
- Emits recorder_snapshot and recorder_diagnostic events through the existing recorder-event bridge.
- Adds worker actions getRecorderRecovery and validateRecording (dry-run validation only; it does not execute browser actions).
- Keeps the existing click, double-click, form, select, checkbox, navigation, selector-confidence and sensitive-field filtering logic.

IMPORTANT COMPATIBILITY NOTES
- This is a complete replacement for browser-worker/worker.cjs only. It does not replace App.tsx, WorkflowStudio.tsx, Rust lib.rs, or CSS.
- The existing App UI may not yet display snapshot/diagnostic events, and its recording-to-workflow converter may need a follow-up UI integration to convert newTab/closeTab events into workflow steps.
- Tab switching is not claimed as captured: Playwright does not expose a reliable user-tab-focus event in this current worker architecture.
- getRecorderRecovery and validateRecording are worker commands. A frontend button for them requires corresponding Tauri invoke wrappers if the Rust bridge does not already forward arbitrary worker actions.
- validateRecording is a dry run only. It reports unsupported actions and selector warnings; it does not replay or execute actions.

VALIDATION
- `node --check browser-worker/worker.cjs` passed in the preparation environment.
- Run the app's normal build and test commands after replacing the file:
  `pnpm.cmd exec tsc --noEmit`
  `pnpm.cmd build`
  `pnpm.cmd tauri dev`

Please test recording on a non-sensitive sample website first. No password or private-field values are intentionally captured.
