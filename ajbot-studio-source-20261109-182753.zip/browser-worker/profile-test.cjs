const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");

(async () => {
  const root = path.join(__dirname, "profiles");
  const profiles = fs.readdirSync(root, { withFileTypes: true })
    .filter(entry => entry.isDirectory());

  if (!profiles.length) throw new Error("No saved profiles found.");

  const profilePath = path.join(root, profiles[0].name);
  console.log("Testing profile:", profiles[0].name);

  const context = await chromium.launchPersistentContext(profilePath, {
    headless: false
  });

  let closed = false;
  context.on("close", () => {
    closed = true;
    console.log("Browser closed before the test finished.");
  });

  console.log("Keep this window open for 30 seconds.");
  await new Promise(resolve => setTimeout(resolve, 30000));

  console.log(closed
    ? "RESULT: Browser closed early."
    : "RESULT: Browser stayed open.");

  if (!closed) await context.close();
})().catch(error => console.error("TEST ERROR:", error.message));
