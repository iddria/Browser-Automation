
import { type FormEvent, useState } from "react";
import { invoke } from "./studio/bridge";
import {
  ExternalLink,
  Search,
  LoaderCircle,
  ShieldCheck,
  Workflow,
} from "lucide-react";
import "./WebSearchPanel.css";

type SearchProvider = "all" | "google" | "brave" | "bing";

type SearchResult = {
  title: string;
  url: string;
  description: string;
  providers: string[];
};

type ProviderStatus = {
  provider: string;
  status: "success" | "error";
  count: number;
  error: string;
};

type SearchResponse = {
  query: string;
  results: SearchResult[];
  providers: ProviderStatus[];
  error?: string;
};

type WebSearchPanelProps = {
  onCreateWorkflow?: (result: SearchResult) => void;
};

function isSafeWebUrl(value: string): boolean {
  try {
    const parsed = new URL(value);
    return (
      (parsed.protocol === "https:" || parsed.protocol === "http:") &&
      Boolean(parsed.hostname)
    );
  } catch {
    return false;
  }
}

function getErrorMessage(err: unknown): string {
  if (typeof err === "string") return err;
  if (err instanceof Error) return err.message;

  if (err && typeof err === "object") {
    const details = err as Record<string, unknown>;
    const candidate = details.message ?? details.error ?? details.details;

    if (typeof candidate === "string") return candidate;

    try {
      return JSON.stringify(candidate ?? err, null, 2);
    } catch {
      return "Could not read the web search error.";
    }
  }

  return "An unknown web search error occurred.";
}

function providerName(provider: string): string {
  const names: Record<string, string> = {
    google: "Google",
    brave: "Brave",
    bing: "Bing",
  };

  return names[provider] || provider;
}

export default function WebSearchPanel({
  onCreateWorkflow,
}: WebSearchPanelProps) {
  const [query, setQuery] = useState("");
  const [provider, setProvider] = useState<SearchProvider>("all");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [statuses, setStatuses] = useState<ProviderStatus[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [searchedQuery, setSearchedQuery] = useState("");

  const runSearch = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const safeQuery = query.trim();

    if (!safeQuery) {
      setError("Enter something to search for.");
      return;
    }

    if (safeQuery.length > 600) {
      setError("Keep your search under 600 characters.");
      return;
    }

    setLoading(true);
    setError("");
    setResults([]);
    setStatuses([]);
    setSearchedQuery(safeQuery);

    try {
      const response = await invoke<SearchResponse>("search_web", {
        query: safeQuery,
        provider,
      });

      if (!response || !Array.isArray(response.results)) {
        throw new Error("The research service returned an invalid response.");
      }

      const safeResults = response.results.filter(
        (result) =>
          result &&
          typeof result.title === "string" &&
          typeof result.url === "string" &&
          isSafeWebUrl(result.url)
      );

      setResults(safeResults);
      setStatuses(
        Array.isArray(response.providers) ? response.providers : []
      );

      if (response.error) {
        setError(response.error);
      } else if (safeResults.length === 0) {
        setError(
          "No pages were found. Check provider statuses below or try another search phrase."
        );
      }
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      className="web-search-panel panel"
      id="web-search"
      aria-labelledby="web-search-title"
    >
      <div className="web-search-heading">
        <div className="web-search-heading-icon">
          <Search size={20} />
        </div>

        <div>
          <h2 id="web-search-title">Ajbot research</h2>
          <p>Search and combine results from multiple engines.</p>
        </div>
      </div>

      <form className="web-search-form" onSubmit={runSearch}>
        <label className="web-search-sr-only" htmlFor="web-search-provider">
          Search provider
        </label>

        <select
          id="web-search-provider"
          className="web-search-provider"
          value={provider}
          onChange={(event) =>
            setProvider(event.target.value as SearchProvider)
          }
          disabled={loading}
        >
          <option value="all">All engines</option>
          <option value="google">Google only</option>
          <option value="brave">Brave only</option>
          <option value="bing">Bing only</option>
        </select>

        <label className="web-search-sr-only" htmlFor="web-search-query">
          Search query
        </label>

        <input
          id="web-search-query"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="What do you want to research?"
          maxLength={600}
          autoComplete="off"
        />

        <button type="submit" disabled={loading || !query.trim()}>
          {loading ? (
            <LoaderCircle className="web-search-spinner" size={16} />
          ) : (
            <Search size={16} />
          )}
          {loading ? "Researching…" : "Research"}
        </button>
      </form>

      <p className="web-search-safety">
        <ShieldCheck size={14} />
        All engines run independently. Failed providers do not cancel successful searches.
      </p>

      {error && (
        <p className="web-search-error" role="alert">
          {error}
        </p>
      )}

      {statuses.length > 0 && (
        <div className="web-search-provider-status" aria-live="polite">
          <strong>Search engine status</strong>

          <div className="web-search-provider-status-list">
            {statuses.map((item) => (
              <div
                className="web-search-provider-status-item"
                key={item.provider}
              >
                <span>
                  {providerName(item.provider)}
                  {item.status === "success"
                    ? ` · ${item.count} found`
                    : " · Failed"}
                </span>

                <span
                  className={
                    item.status === "success"
                      ? "web-search-status-success"
                      : "web-search-status-error"
                  }
                >
                  {item.status === "success" ? "Available" : "Unavailable"}
                </span>

                {item.error && (
                  <small>{item.error}</small>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {results.length > 0 && (
        <div className="web-search-results" aria-live="polite">
          <div className="web-search-results-label">
            {results.length} unique results for “{searchedQuery}”
          </div>

          {results.map((result, index) => (
            <article
              className="web-search-result"
              key={`${result.url}-${index}`}
            >
              <div className="web-search-result-heading">
                <a
                  href={isSafeWebUrl(result.url) ? result.url : undefined}
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <span>{result.title}</span>
                  <ExternalLink size={14} />
                </a>

                {onCreateWorkflow && isSafeWebUrl(result.url) && (
                  <button
                    type="button"
                    className="web-search-workflow-button"
                    onClick={() => onCreateWorkflow(result)}
                    title="Create a draft workflow starting at this page"
                  >
                    <Workflow size={14} />
                    Use in workflow
                  </button>
                )}
              </div>

              <div className="web-search-url">{result.url}</div>

              {result.description && <p>{result.description}</p>}

              {result.providers?.length > 0 && (
                <div className="web-search-result-providers">
                  Found by: {result.providers.map(providerName).join(", ")}
                </div>
              )}
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
