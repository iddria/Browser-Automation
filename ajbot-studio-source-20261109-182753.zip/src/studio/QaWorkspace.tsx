import { useCallback, useEffect, useRef, useState } from 'react';
import { ClipboardCheck, Globe2, ListChecks, Play, Plus, RefreshCw, ShieldCheck, Sparkles, Square, Trash2 } from 'lucide-react';
import { Empty, PageHeading } from './AccountPages';
import { type Flow, downloadJson } from './model';
import { qaCommand } from './qaBridge';
import ProviderModelFields from './ProviderModelFields';
import VisionLab from './VisionLab';
import { defaultModel } from './providerCatalog';

type Site = { id: string; name: string; origin: string; token: string; verifiedAt: number | null };
type Check = { path: string; type: 'page' | 'heading' | 'title' | 'text'; expected: string };
type Viewport = 'desktop' | 'mobile';
type Suite = { viewport?: Viewport; revision?: number; id: string; siteId: string; name: string; checks: Check[] };
type CheckResult = Check & { passed: boolean; detail: string; durationMs: number };
type Job = {
  id: string; suiteName: string; origin: string; status: string; checks: Check[]; results: CheckResult[];
  viewport?: Viewport; createdAt: number; finishedAt?: number; error?: string;
};
type Snapshot = { sites: Site[]; suites: Suite[]; jobs: Job[]; storageError?: string };
const blankCheck: Check = { path: '/', type: 'page', expected: '' };
const checkNames: Record<Check['type'], string> = {
  page: 'Page loads', heading: 'Main heading is visible', title: 'Title contains', text: 'Visible text contains',
};
const tabs = ['Sites', 'Journeys', 'Runs', 'Vision Lab'] as const;
const active = (job: Job) => ['queued', 'running', 'stopping'].includes(job.status);
const verified = (site?: Site) => Boolean(site?.verifiedAt && Date.now() - site.verifiedAt < 86400000);

export default function QaWorkspace({ workflows }: { workflows: Flow[] }) {
  const [snapshot, setSnapshot] = useState<Snapshot>({ sites: [], suites: [], jobs: [] });
  const [tab, setTab] = useState<typeof tabs[number]>('Sites');
  const [selected, setSelected] = useState('');
  const [siteName, setSiteName] = useState('');
  const [origin, setOrigin] = useState('');
  const [suiteId, setSuiteId] = useState('');
  const [viewport, setViewport] = useState<Viewport>('desktop');
  const [revision, setRevision] = useState(0);
  const [suiteName, setSuiteName] = useState('');
  const [checks, setChecks] = useState<Check[]>([{ ...blankCheck }]);
  const [catalogue, setCatalogue] = useState<string[]>([]);
  const [goal, setGoal] = useState('');
  const [provider, setProvider] = useState('ollama');
  const [model, setModel] = useState(defaultModel('ollama'));
  const [workflowId, setWorkflowId] = useState('');
  const [busy, setBusy] = useState('');
  const [connectionError, setConnectionError] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [ready, setReady] = useState(false);
  const [explanation, setExplanation] = useState<{ id: string; summary: string; model: string }>();
  const sequence = useRef(0);
  const site = snapshot.sites.find(item => item.id === selected) || snapshot.sites[0];
  const hasActive = snapshot.jobs.some(active);
  const visibleSuites = snapshot.suites.filter(suite => suite.siteId === site?.id);

  const refresh = useCallback(async () => {
    const current = ++sequence.current;
    try {
      const data = await qaCommand<Snapshot>('status');
      if (sequence.current !== current) return;
      setSnapshot(data);
      setReady(true);
      setConnectionError('');
    } catch (err) {
      if (sequence.current === current) setConnectionError(String(err));
    }
  }, []);

  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => void refresh(), hasActive ? 900 : 5000);
    return () => window.clearInterval(timer);
  }, [refresh, hasActive]);

  async function perform(label: string, work: () => Promise<void>) {
    setBusy(label);
    setError('');
    setNotice('');
    try {
      await work();
      await refresh();
    } catch (err) {
      setError(String(err));
    } finally {
      setBusy('');
    }
  }

  function resetSuite() {
    setSuiteId('');
    setRevision(0);
    setViewport('desktop');
    setSuiteName('');
    setChecks([{ ...blankCheck }]);
    setWorkflowId('');
  }

  function selectSite(id: string) {
    setSelected(id);
    setCatalogue([]);
    resetSuite();
  }

  function appendRoutes(paths: string[]) {
    const distinct = [...new Set(paths)].filter(path => !checks.some(check => check.path === path && check.type === 'page'));
    const available = 12 - checks.length;
    setChecks(current => [...current, ...distinct.slice(0, available).map(path => ({ ...blankCheck, path }))]);
    setNotice(distinct.length > available ? 'The suite holds up to 12 checks. Remove a row to add more.' : 'Routes added to your draft.');
  }

  function importWorkflowRoutes() {
    const flow = workflows.find(item => item.id === workflowId);
    if (!flow || !site) return;
    const paths = flow.steps.flatMap(step => {
      if (step.action.toLowerCase() !== 'navigate' || !step.url) return [];
      try {
        const url = new URL(step.url);
        return url.origin === site.origin && !url.username && !url.password && !url.search && !url.hash ? [url.pathname] : [];
      } catch { return []; }
    });
    if (!paths.length) setError('This workflow has no navigation routes for the selected site.');
    else appendRoutes(paths);
  }

  function updateCheck(index: number, patch: Partial<Check>) {
    setChecks(current => current.map((check, at) => at === index ? { ...check, ...patch } : check));
  }

  return <div className="aj-qa">
    <PageHeading title="QA workspace" description="Verify a site, build reusable journeys, and run browser checks with recorded results." />
    <div className="aj-qa-toolbar">
      <div className="aj-segment" role="tablist" aria-label="QA workspace sections">
        {tabs.map(value => <button key={value} type="button" role="tab" aria-selected={tab === value} className={tab === value ? 'selected' : ''} disabled={!!busy} onClick={() => setTab(value)}>{value}</button>)}
      </div>
      <button className="aj-button small" onClick={() => void refresh()}><RefreshCw size={14} /> Refresh</button>
    </div>
    {connectionError && <p className="aj-notice" role="alert">{connectionError}</p>}
    {snapshot.storageError && <p className="aj-notice" role="alert">The workspace could not write its data. {snapshot.storageError}</p>}
    {error && <p className="aj-notice" role="alert">{error}</p>}
    {(notice || busy) && <p className="aj-notice" role="status">{busy || notice}</p>}
    {!ready && !connectionError && <p role="status">Connecting to the QA runtime…</p>}
    {ready && tab === 'Vision Lab' && <VisionLab />}

    {ready && tab === 'Sites' && <div role="tabpanel" aria-label="Sites" className="aj-grid two">
      <form className="aj-card aj-qa-form" onSubmit={event => {
        event.preventDefault();
        void perform('Registering site…', async () => {
          const added = await qaCommand<Site>('addSite', { name: siteName, origin });
          selectSite(added.id);
          setSiteName('');
          setOrigin('');
          setNotice('Site added. Publish its token to verify control.');
        });
      }}>
        <h3><Globe2 size={18} /> Register a site</h3>
        <label>Site name<input required maxLength={80} value={siteName} onChange={event => setSiteName(event.target.value)} placeholder="Akoriva staging" /></label>
        <label>Site origin<input required type="url" maxLength={400} value={origin} onChange={event => setOrigin(event.target.value)} placeholder="https://staging.example.com" /></label>
        <button className="aj-button primary" disabled={!!busy}><Plus size={15} /> Add site</button>
      </form>
      <section className="aj-card aj-qa-form">
        <h3><ShieldCheck size={18} /> Site verification</h3>
        {site ? <>
          <label>Registered site<select value={site.id} disabled={!!busy} onChange={event => selectSite(event.target.value)}>
            {snapshot.sites.map(item => <option value={item.id} key={item.id}>{item.name}</option>)}
          </select></label>
          <div className="aj-qa-proof">
            <span className={verified(site) ? 'aj-pill success' : 'aj-pill'}>{verified(site) ? 'Verified' : 'Verification required'}</span>
            <p>Publish this token as plain text at <code>/.well-known/ajbot-qa.txt</code> on {site.origin}. Verification lasts 24 hours.</p>
            <label>Verification token<input readOnly value={site.token} onFocus={event => event.target.select()} /></label>
          </div>
          <div className="aj-inline">
            <button className="aj-button" disabled={!!busy} onClick={() => void perform('Checking ownership token…', async () => {
              await qaCommand('verifySite', { siteId: site.id });
              setNotice('Site verified. You can build and run journeys.');
            })}>Verify site</button>
            {verified(site) && <button className="aj-button primary" disabled={!!busy} onClick={() => setTab('Journeys')}>Build journeys</button>}
          </div>
        </> : <Empty icon={<ShieldCheck size={24} />} title="Register a site to get its token" />}
      </section>
    </div>}

    {ready && tab === 'Journeys' && <div role="tabpanel" aria-label="Journeys">
      {!site || !verified(site) ? <Empty icon={<ShieldCheck size={24} />} title="Verify a site to build journeys"><button className="aj-button" onClick={() => setTab('Sites')}>Open Sites</button></Empty> : <>
        <div className="aj-grid two">
          <section className="aj-card aj-qa-form">
            <h3><Globe2 size={18} /> Route discovery</h3>
            <p>{site.origin}</p>
            <button className="aj-button" disabled={!!busy} onClick={() => void perform('Discovering site routes…', async () => {
              const routes = await qaCommand<string[]>('discover', { siteId: site.id });
              setCatalogue(routes);
              setNotice(routes.length + ' routes discovered.');
            })}>Discover routes</button>
            {catalogue.length > 0 && <div className="aj-qa-routes" aria-label="Discovered routes">
              {catalogue.map(path => <button className="aj-button small" key={path} disabled={!!busy || checks.length >= 12 || checks.some(check => check.path === path && check.type === 'page')} onClick={() => appendRoutes([path])}><Plus size={14} /> {path}</button>)}
            </div>}
            {workflows.length > 0 && <div className="aj-qa-form">
              <label>Saved workflow routes<select value={workflowId} disabled={!!busy} onChange={event => setWorkflowId(event.target.value)}>
                <option value="">Choose a workflow</option>
                {workflows.map(flow => <option value={flow.id} key={flow.id}>{flow.name}</option>)}
              </select></label>
              <button className="aj-button small" disabled={!workflowId || !!busy} onClick={importWorkflowRoutes}>Add same-site navigation routes</button>
            </div>}
          </section>
          <section className="aj-card aj-qa-form">
            <h3><Sparkles size={18} /> Build with AI</h3>
            <label>Test goal<textarea maxLength={1000} value={goal} disabled={!!busy} onChange={event => setGoal(event.target.value)} placeholder="Check that the homepage loads and has a visible heading." /></label>
            <ProviderModelFields provider={provider} model={model} onProvider={setProvider} onModel={setModel} loadModels={provider => qaCommand('models', { provider })} />
            <button className="aj-button primary" disabled={!goal.trim() || !!busy} onClick={() => void perform('Generating an AI draft…', async () => {
              const paths = [...new Set([...catalogue, ...checks.map(check => check.path)])].slice(0, 24);
              const draft = await qaCommand<{ checks: Check[]; model: string }>('draft', { siteId: site.id, goal, provider, model: model || defaultModel(provider), paths });
              setChecks(draft.checks);
              setNotice('Draft generated with ' + draft.model + '. Review the checks before saving.');
            })}><Sparkles size={15} /> Draft checks</button>
          </section>
        </div>
        <section className="aj-card aj-qa-form">
          <div className="aj-qa-toolbar">
            <h3><ListChecks size={18} /> Journey checks</h3>
            <button className="aj-button small" disabled={!!busy} onClick={resetSuite}><Plus size={14} /> New suite</button>
          </div>
          {visibleSuites.length > 0 && <label>Saved suite<select value={suiteId} disabled={!!busy} onChange={event => {
            const suite = visibleSuites.find(item => item.id === event.target.value);
            if (!suite) return resetSuite();
            setSuiteId(suite.id);
            setSuiteName(suite.name);
            setRevision(suite.revision || 0);
            setViewport(suite.viewport || 'desktop');
            setChecks(suite.checks);
          }}><option value="">New draft</option>{visibleSuites.map(suite => <option value={suite.id} key={suite.id}>{suite.name}</option>)}</select></label>}
          <label>Suite name<input maxLength={100} disabled={!!busy} value={suiteName} onChange={event => setSuiteName(event.target.value)} placeholder="Homepage smoke test" /></label>
          <label>Browser viewport<select value={viewport} disabled={!!busy} onChange={event => setViewport(event.target.value as Viewport)}>
            <option value="desktop">Desktop · 1440 × 900</option>
            <option value="mobile">Mobile emulation · 390 × 844</option>
          </select></label>
          {checks.map((check, index) => <div className="aj-qa-check" key={index}>
            <label>Route {index + 1}<input value={check.path} maxLength={400} disabled={!!busy} onChange={event => updateCheck(index, { path: event.target.value })} /></label>
            <label>Check {index + 1}<select value={check.type} disabled={!!busy} onChange={event => updateCheck(index, { type: event.target.value as Check['type'] })}>
              {Object.entries(checkNames).map(([value, name]) => <option key={value} value={value}>{name}</option>)}
            </select></label>
            {['text', 'title'].includes(check.type) && <label>Expected text {index + 1}<input maxLength={180} value={check.expected} disabled={!!busy} onChange={event => updateCheck(index, { expected: event.target.value })} /></label>}
            <button className="aj-button small" aria-label={'Remove check ' + (index + 1)} disabled={checks.length === 1 || !!busy} onClick={() => setChecks(current => current.filter((_, at) => at !== index))}><Trash2 size={15} /></button>
          </div>)}
          <div className="aj-inline">
            <button className="aj-button" disabled={checks.length >= 12 || !!busy} onClick={() => setChecks(current => [...current, { ...blankCheck }])}><Plus size={14} /> Add check</button>
            <button className="aj-button primary" disabled={!suiteName.trim() || !!busy} onClick={() => void perform('Saving suite…', async () => {
              const suite = await qaCommand<Suite>('saveSuite', { id: suiteId, siteId: site.id, name: suiteName, checks, viewport, revision });
              setSuiteId(suite.id);
              setRevision(suite.revision || 0);
              setNotice('Suite saved.');
            })}>Save suite</button>
          </div>
          {visibleSuites.length > 0 && <ul className="aj-qa-list">
            {visibleSuites.map(suite => <li key={suite.id}>
              <div><strong>{suite.name}</strong><small>{suite.checks.length} saved checks</small></div>
              <button className="aj-button small" disabled={!!busy} onClick={() => void perform('Queuing suite…', async () => {
                await qaCommand('runSuite', { suiteId: suite.id });
                setTab('Runs');
                setNotice('Run queued.');
              })}><Play size={14} /> Run saved suite</button>
            </li>)}
          </ul>}
        </section>
      </>}
    </div>}

    {ready && tab === 'Runs' && <div role="tabpanel" aria-label="Runs">
      {snapshot.jobs.some(job => !active(job) && job.results.length > 0) && <details className="aj-card aj-qa-model-picker">
        <summary>Model for report analysis</summary>
        <ProviderModelFields provider={provider} model={model} onProvider={setProvider} onModel={setModel} loadModels={provider => qaCommand('models', { provider })} />
      </details>}
      {!snapshot.jobs.length && <Empty icon={<ClipboardCheck size={24} />} title="No QA runs yet" description="Run a saved journey suite to see its results." />}
      {[...snapshot.jobs].reverse().map(job => <article key={job.id} className="aj-card aj-qa-run">
        <div className="aj-qa-toolbar">
          <div><h3>{job.suiteName}</h3><small>{job.origin} · {job.viewport === 'mobile' ? 'Mobile emulation' : 'Desktop'} · {new Date(job.createdAt).toLocaleString()}</small></div>
          <span className={job.status === 'passed' ? 'aj-pill success' : 'aj-pill'}>{job.status}</span>
        </div>
        <p>{job.results.filter(result => result.passed).length} passed · {job.results.length} of {job.checks.length} checked</p>
        {job.error && <p className="aj-notice">{job.error}</p>}
        {job.results.length > 0 && <ul className="aj-qa-list">
          {job.results.map((result, index) => <li key={index}>
            <div><strong>{checkNames[result.type]} · {result.path}</strong><small>{result.detail} · {result.durationMs} ms</small></div>
            <span className={result.passed ? 'aj-pill success' : 'aj-pill'}>{result.passed ? 'Pass' : 'Fail'}</span>
          </li>)}
        </ul>}
        <div className="aj-inline">
          {active(job) && <button className="aj-button small" disabled={!!busy || job.status === 'stopping'} onClick={() => void perform('Stopping run…', async () => {
            await qaCommand('cancel', { jobId: job.id });
          })}><Square size={14} /> Stop run</button>}
          {['failed', 'interrupted', 'cancelled'].includes(job.status) && <button className="aj-button small" disabled={!!busy} onClick={() => void perform('Queuing retry…', async () => {
            await qaCommand('retry', { jobId: job.id });
          })}><RefreshCw size={14} /> Retry run</button>}
          {!active(job) && job.results.length > 0 && <button className="aj-button small" disabled={!!busy} onClick={() => void perform('Analyzing browser results…', async () => {
            const reply = await qaCommand<{ summary: string; model: string }>('explainRun', { jobId: job.id, provider, model: model || defaultModel(provider) });
            setExplanation({ id: job.id, ...reply });
          })}><Sparkles size={14} /> Explain with AI</button>}
          {!active(job) && <button className="aj-button small" onClick={() => downloadJson('qa-' + job.id + '.json', job)}>Export report</button>}
        </div>
        {explanation?.id === job.id && <section className="aj-qa-analysis" aria-label="AI analysis">
          <strong>AI analysis · {explanation.model}</strong>
          <p>{explanation.summary}</p>
        </section>}
      </article>)}
    </div>}
  </div>;
}
