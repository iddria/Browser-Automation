import { type FormEvent, useEffect, useState } from 'react';
import { Download, Pause, Play, ShieldCheck, Square, Upload, Workflow } from 'lucide-react';
import { desktop, invoke, listen } from './bridge';
import { type Flow, type Profile, type Step, uid, validUrl } from './model';

type ProfileEditorProps = {
  profile: Profile | null;
  onClose: () => void;
  onSaved: () => Promise<void>;
};

export function ProfileEditor({ profile, onClose, onSaved }: ProfileEditorProps) {
  const [name, setName] = useState(profile?.name ?? '');
  const [url, setUrl] = useState(profile?.startUrl ?? '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const save = async (event: FormEvent) => {
    event.preventDefault();
    if (saving) return;
    setSaving(true);
    setError('');
    try {
      if (!name.trim()) throw new Error('Enter a profile name.');
      await invoke(profile ? 'update_browser_profile' : 'create_browser_profile', {
        profileId: profile?.id ?? uid('profile'),
        name: name.trim(),
        startUrl: url.trim() ? validUrl(url.trim()) : null,
      });
      await onSaved();
      onClose();
    } catch (problem) {
      setError(String(problem));
    } finally {
      setSaving(false);
    }
  };

  return <div className="aj-modal-backdrop">
    <form className="aj-modal" role="dialog" aria-modal="true" aria-labelledby="profile-editor-title" onSubmit={save}>
      <h2 id="profile-editor-title">{profile ? 'Edit browser profile' : 'Create browser profile'}</h2>
      <label>Profile name<input autoFocus required maxLength={80} value={name} onChange={event => setName(event.target.value)} /></label>
      <label>Starting website<input value={url} placeholder="https://example.com" onChange={event => setUrl(event.target.value)} /></label>
      {error && <p className="aj-notice" role="alert">{error}</p>}
      <footer className="aj-modal-footer">
        <button type="button" className="aj-button" onClick={onClose} disabled={saving}>Cancel</button>
        <button className="aj-button primary" type="submit" disabled={saving}>{saving ? 'Saving…' : profile ? 'Save changes' : 'Create profile'}</button>
      </footer>
    </form>
  </div>;
}

export async function saveProfileArchive(profile: Profile): Promise<string> {
  const result = await invoke<{ cancelled?: boolean; path?: string }>('backup_browser_profile', { profileId: profile.id });
  return result.cancelled ? '' : `Backup saved for ${profile.name || profile.id}${result.path ? ` · ${result.path}` : ''}.`;
}

export function ProfileArchiveControls({ refresh }: { refresh: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const handle = async (kind: 'restore' | 'verify') => {
    const name = kind === 'restore' ? window.prompt('Choose a name for the restored profile.', 'Restored profile')?.trim() : undefined;
    if (kind === 'restore' && !name) return;
    setBusy(true);
    setMessage('');
    try {
      if (kind === 'restore') {
        const result = await invoke<{ cancelled?: boolean; profile?: Profile }>('restore_browser_profile', { name });
        if (!result.cancelled && result.profile) {
          await refresh();
          setMessage(`Restored a new profile named ${result.profile.name || result.profile.id}.`);
        }
      } else {
        const result = await invoke<{ cancelled?: boolean; valid?: boolean; profileName?: string; fileCount?: number; message?: string }>('verify_browser_profile_backup');
        if (!result.cancelled) setMessage(result.valid
          ? `Backup verified for ${result.profileName || 'the selected profile'} · ${result.fileCount ?? 0} files checked.`
          : result.message || 'The selected archive could not be verified.');
      }
    } catch (error) {
      setMessage(String(error));
    } finally {
      setBusy(false);
    }
  };
  return <>
    <button className="aj-button" disabled={!desktop || busy} onClick={() => void handle('verify')}><ShieldCheck size={15} /> Verify backup</button>
    <button className="aj-button" disabled={!desktop || busy} onClick={() => void handle('restore')}><Upload size={15} /> Restore backup</button>
    {message && <p className="aj-notice" role="status">{message}</p>}
  </>;
}

type RecordedAction = Step & { id: string; label?: string };
type Recording = { status: 'recording' | 'paused' | 'stopped'; actions: RecordedAction[] };
type RecorderEvent = { type: string; profileId: string; action?: RecordedAction; status?: Recording['status'] };

export function useProfileRecorder(notify: (message: string) => void) {
  const [recording, setRecording] = useState<(Recording & { profile: Profile }) | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const unsubscribe = listen<RecorderEvent>('recorder-event', ({ payload }) => {
      setRecording(current => {
        if (!current || current.profile.id !== payload.profileId) return current;
        if (payload.type === 'recorder_status' && payload.status) return { ...current, status: payload.status };
        const action = payload.action;
        if (payload.type === 'action_recorded' && action && !current.actions.some(item => item.id === action.id)) {
          return { ...current, actions: [...current.actions, action] };
        }
        return current;
      });
    });
    return () => { void unsubscribe.then(unlisten => unlisten()); };
  }, []);

  const start = async (profile: Profile) => {
    setBusy(true);
    try {
      const result = await invoke<Recording>('start_browser_recording', { profileId: profile.id });
      setRecording({ ...result, profile });
    } catch (error) {
      notify(String(error));
    } finally {
      setBusy(false);
    }
  };

  const control = async (action: 'pauseRecorder' | 'resumeRecorder' | 'stopRecorder') => {
    if (!recording) return;
    setBusy(true);
    try {
      const result = await invoke<Recording>('control_browser_recording', { action, profileId: recording.profile.id });
      setRecording({ ...result, profile: recording.profile });
    } catch (error) {
      notify(String(error));
    } finally {
      setBusy(false);
    }
  };

  const draft = (): Flow | null => {
    if (!recording) return null;
    const steps = recording.actions.flatMap<Step>(item => {
      const action = item.action === 'doubleclick' ? 'doubleClick' : item.action;
      if (action === 'navigate' && item.url) return [{ action, url: item.url }];
      if (['click', 'doubleClick', 'fill', 'select', 'check', 'uncheck'].includes(action) && item.selector) {
        return [{ action, selector: item.selector, ...(item.value !== undefined ? { value: item.value } : {}) }];
      }
      return [];
    });
    if (!steps.length) return null;
    const startUrl = recording.actions.find(action => action.url)?.url || recording.profile.startUrl;
    if (steps[0].action !== 'navigate' && startUrl) steps.unshift({ action: 'navigate', url: startUrl });
    return { id: '', name: `Recording · ${recording.profile.name || recording.profile.id}`, steps };
  };
  return { recording, busy, start, control, draft };
}

export function RecorderPanel({ recorder, onDraft, notify }: {
  recorder: ReturnType<typeof useProfileRecorder>; onDraft: (flow: Flow) => void; notify: (message: string) => void;
}) {
  const { recording, busy, control, draft } = recorder;
  if (!recording) return null;
  return <section className="aj-card" aria-label="Browser recorder">
    <div className="aj-inline">
      <div className="aj-spacer"><h3>Browser recorder</h3><small>{recording.profile.name || recording.profile.id} · {recording.status} · {recording.actions.length} actions</small></div>
      {recording.status === 'recording' && <button className="aj-button" disabled={busy} onClick={() => void control('pauseRecorder')}><Pause size={14} /> Pause recording</button>}
      {recording.status === 'paused' && <button className="aj-button" disabled={busy} onClick={() => void control('resumeRecorder')}><Play size={14} /> Resume recording</button>}
      {recording.status !== 'stopped' ? <button className="aj-button" disabled={busy} onClick={() => void control('stopRecorder')}><Square size={14} /> Stop recording</button>
        : <button className="aj-button primary" disabled={!recording.actions.length} onClick={() => {
          const result = draft();
          if (result) onDraft(result);
          else notify('No supported workflow steps were recorded.');
        }}><Workflow size={14} /> Open in Custom</button>}
    </div>
    {recording.actions.length > 0 && <ol className="aj-step-review">{recording.actions.map(item =>
      <li key={item.id}>{item.action} {item.label || item.selector || item.url}</li>,
    )}</ol>}
  </section>;
}

export function ProfileBackupButton({ profile, notify }: { profile: Profile; notify: (message: string) => void }) {
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      const message = await saveProfileArchive(profile);
      if (message) notify(message);
    } catch (error) {
      notify(String(error));
    } finally {
      setBusy(false);
    }
  };
  return <button className="aj-button small" disabled={!desktop || profile.running || busy} onClick={() => void save()}><Download size={14} /> {busy ? 'Saving…' : 'Backup'}</button>;
}
