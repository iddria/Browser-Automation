import { useState } from 'react';
import { Eye, Play } from 'lucide-react';
import gridImage from '../../browser-worker/vision-lab/sample-grid.jpg';
import { qaCommand } from './qaBridge';

type VisionResult = {
  confidences: number[];
  selected: number[];
  expected: number[];
  threshold: number;
  passed: boolean;
};

export default function VisionLab() {
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<VisionResult>();
  const [error, setError] = useState('');

  async function run() {
    setRunning(true);
    setResult(undefined);
    setError('');
    try {
      setResult(await qaCommand<VisionResult>('runVisionLab'));
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : String(failure));
    } finally {
      setRunning(false);
    }
  }

  return <section role="tabpanel" aria-label="Vision Lab" className="aj-grid two">
    <div className="aj-card aj-qa-form">
      <h3><Eye size={18} /> Local image puzzle</h3>
      <p>Find all tiles that contain a bus.</p>
      <div className="aj-vision-grid" role="list" aria-label="Sample image grid">
        {Array.from({ length: 9 }, (_, index) => {
          const selected = result?.selected.includes(index + 1);
          const confidence = result ? Math.round(result.confidences[index] * 100) : undefined;
          return <div key={index} role="listitem" className={selected ? 'selected' : ''}
            style={{ backgroundImage: `url(${gridImage})`, backgroundPosition: `${(index % 3) * 50}% ${Math.floor(index / 3) * 50}%` }}>
            <span>Tile {index + 1}{confidence !== undefined && ` · ${confidence}%`}{selected && ' ✓'}</span>
          </div>;
        })}
      </div>
      <button type="button" className="aj-button primary" onClick={() => void run()} disabled={running}>
        <Play size={15} /> {running ? 'Analyzing tiles…' : 'Run YOLO demo'}
      </button>
      {error && <p className="aj-notice" role="alert">{error}</p>}
    </div>
    <div className="aj-card aj-qa-form">
      <h3>Model results</h3>
      <p>The model scores each tile locally. AJBOT highlights its selections and checks them against the sample answer.</p>
      {result ? <div role="status" className="aj-qa-form">
        <span className={result.passed ? 'aj-pill success' : 'aj-pill'}>{result.passed ? 'Puzzle solved' : 'Selection did not match'}</span>
        <p>Selected tiles {result.selected.join(', ') || 'none'}</p>
        <p>Expected tiles {result.expected.join(', ')}</p>
        <p>Confidence threshold {Math.round(result.threshold * 100)}%</p>
      </div> : <p role="status">{running ? 'Running the local classifier.' : 'Run the demo to see the tile scores.'}</p>}
      <p>First-time setup requires Python and the ONNX model. See <strong>Vision Lab</strong> in the project README.</p>
    </div>
  </section>;
}
