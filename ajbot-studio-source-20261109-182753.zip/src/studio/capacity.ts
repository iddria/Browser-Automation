export type CapacitySettings = { concurrentSessions: number; profilesPerBatch: number };

// Zero means no fixed application cap. Hardware and provider quotas still apply.
export const defaultCapacity: CapacitySettings = { concurrentSessions: 0, profilesPerBatch: 0 };

export function parseCapacity(value: string, label: string): number {
  const count = Number(value);
  if (!value.trim() || !Number.isSafeInteger(count) || count < 0) {
    throw new Error(`${label}: enter a whole number of 0 or more.`);
  }
  return count;
}

export function normalizeCapacity(raw: unknown): CapacitySettings {
  const data = raw && typeof raw === 'object' ? raw as Partial<CapacitySettings> : {};
  const valid = (n: unknown) => typeof n === 'number' && Number.isSafeInteger(n) && n >= 0;
  return {
    concurrentSessions: valid(data.concurrentSessions) ? data.concurrentSessions! : 0,
    profilesPerBatch: valid(data.profilesPerBatch) ? data.profilesPerBatch! : 0,
  };
}

export function sessionCapacityReached(active: number, configured: number): boolean {
  return configured > 0 && active >= configured;
}

export function profileBatchError(counts: Record<string, number>, configured: number): string {
  const values = Object.values(counts);
  if (values.some(count => !Number.isSafeInteger(count) || count < 0)) return 'Profile counts must be whole numbers of 0 or more.';
  const total = values.reduce((a, b) => a + b, 0);
  if (!Number.isSafeInteger(total)) return 'The total profile count is too large to represent accurately.';
  if (configured > 0 && total > configured) return `Your batch setting allows ${configured} profiles. Adjust it in Settings → Workspace capacity.`;
  return '';
}
