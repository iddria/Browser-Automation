import { invoke as nativeInvoke, isTauri } from '@tauri-apps/api/core';
import { listen as nativeListen, type EventCallback } from '@tauri-apps/api/event';

export const desktop = isTauri();
const prefix = 'ajbot-preview-';
const read = (name: string): any => JSON.parse(localStorage.getItem(prefix + name) || '[]');
const write = (name: string, value: unknown) => localStorage.setItem(prefix + name, JSON.stringify(value));
// A normal browser can edit drafts. Execution and OS operations require the desktop app.
export async function invoke<T = unknown>(command: string, args: Record<string, any> = {}): Promise<T> {
  if (desktop) return nativeInvoke<T>(command, args);
  let result: any;
  switch (command) {
    case 'list_browser_profiles': result = read('profiles'); break;
    case 'list_browser_workflows': result = read('workflows'); break;
    case 'list_proxies': result = read('proxies'); break;
    case 'list_run_history': case 'list_schedule_runs': result = []; break;
    case 'list_schedules': result = read('schedules'); break;
    case 'create_browser_profile': {
      const all = read('profiles');
      if (all.some((p: any) => p.id === args.profileId)) throw new Error('Profile ID already exists.');
      result = { id: args.profileId, name: args.name, startUrl: args.startUrl, deviceClass: args.deviceClass, running: false };
      write('profiles', [...all, result]); break;
    }
    case 'update_browser_profile': write('profiles', read('profiles').map((p: any) => p.id === args.profileId ? { ...p, name: args.name, startUrl: args.startUrl } : p)); break;
    case 'delete_browser_profile': write('profiles', read('profiles').filter((p: any) => p.id !== args.profileId)); break;
    case 'save_browser_workflow':
      result = { id: args.workflowId, name: args.name, steps: args.steps, updatedAt: Date.now() };
      write('workflows', [...read('workflows').filter((w: any) => w.id !== result.id), result]); break;
    case 'delete_browser_workflow': write('workflows', read('workflows').filter((w: any) => w.id !== args.workflowId)); break;
    case 'get_profile_proxy': result = JSON.parse(localStorage.getItem(prefix + 'assignments') || '{}')[args.profileId] || null; break;
    case 'assign_proxy_to_profile': {
      const data = JSON.parse(localStorage.getItem(prefix + 'assignments') || '{}');
      data[args.profileId] = args.proxyId; write('assignments', data); break;
    }
    case 'save_proxy': {
      if (args.password) throw new Error('Use the desktop app to store proxy passwords encrypted.');
      result = { id: args.id, name: args.name, server: args.server, username: args.username, hasPassword: false };
      write('proxies', [...read('proxies').filter((p: any) => p.id !== args.id), result]); break;
    }
    case 'delete_proxy': write('proxies', read('proxies').filter((p: any) => p.id !== args.id)); break;
    case 'get_automatic_backup_settings': result = { settings: { enabled: false, schedule: 'daily', time: '02:00', backupDirectory: '', retentionCount: 7 }, history: [], defaultBackupDirectory: '' }; break;
    case 'list_provider_keys': result = []; break;
    default: throw new Error('This operation requires the AJBOT STUDIO desktop app. Browser mode supports local drafts only.');
  }
  return result as T;
}
export async function listen<T>(name: string, callback: EventCallback<T>): Promise<() => void> {
  return desktop ? nativeListen<T>(name, callback) : () => {};
}
