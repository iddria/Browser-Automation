import type { Flow, Pod, Session } from './model';
export type Period = 'All' | '30d' | '7d';
export function timestamp(value: unknown): number {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
  if (typeof value === 'string') { const n = Date.parse(value); return Number.isFinite(n) ? n : 0; }
  return 0;
}
export function withinPeriod(item: { createdAt?: unknown; updatedAt?: unknown }, period: Period, now = Date.now()): boolean {
  if (period === 'All') return true;
  const time = timestamp(item.createdAt) || timestamp(item.updatedAt);
  return time > 0 && time >= now - (period === '7d' ? 7 : 30) * 86400000 && time <= now;
}
export function activityCounts(flows: Flow[], sessions: Session[], pods: Pod[], period: Period, now = Date.now()) {
  const saved = flows.filter(w => withinPeriod(w, period, now));
  return [
    { label: 'Swarmers', count: saved.filter(w => w.name.startsWith('Swarmer ·')).length },
    { label: 'Warmers', count: saved.filter(w => / · (Google|YouTube|Facebook|Instagram|TikTok|Amazon)$/.test(w.name) && !w.name.startsWith('Swarmer ·')).length },
    { label: 'Sessions', count: sessions.filter(s => withinPeriod(s, period, now)).length },
    { label: 'Workflows', count: saved.length },
    { label: 'Pods', count: pods.filter(p => withinPeriod(p, period, now)).length },
  ];
}
