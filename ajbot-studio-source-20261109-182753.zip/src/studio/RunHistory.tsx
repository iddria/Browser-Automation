import { useState } from 'react';
import { Activity } from 'lucide-react';

type RunStep = { step: number; action: string; status?: string; ok?: boolean; detail?: string };

export type RunRecord = {
  id: string;
  workflowName: string;
  profileId: string;
  source?: string;
  status: string;
  startedAt: number;
  durationMs?: number | null;
  currentStep?: number;
  totalSteps?: number;
  steps?: RunStep[];
  message?: string;
};

export type RunProgress =
  | { type: 'run_started' | 'run_finished'; run: RunRecord }
  | { type: 'step_started' | 'step_completed'; runId: string; currentStep: number; totalSteps: number; step?: RunStep };

export type LiveRun = RunRecord & { currentAction?: string };

const filters = [
  ['all', 'All runs'], ['completed', 'Completed'], ['failed', 'Failed'], ['stopped', 'Stopped'],
  ['needs_approval', 'Needs approval'], ['manual', 'Manual'], ['scheduled', 'Scheduled'],
];

export default function RunHistory({ history, liveRuns, refresh }: {
  history: RunRecord[];
  liveRuns: LiveRun[];
  refresh: () => Promise<void>;
}) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const query = search.trim().toLowerCase();
  const matching = history.filter(run =>
    (filter === 'all' || run.status === filter || run.source === filter) &&
    `${run.workflowName} ${run.profileId} ${run.id}`.toLowerCase().includes(query),
  ).sort((a, b) => b.startedAt - a.startedAt);

  return <section aria-label="Run history">
    {liveRuns.map(run => <article key={run.id} className="aj-card aj-live-run">
      <div className="aj-inline"><Activity size={16} /><strong>{run.workflowName}</strong><span className="aj-pill success">Running</span></div>
      <progress aria-label={`${run.workflowName} execution progress`} value={run.currentStep ?? 0} max={Math.max(1, run.totalSteps ?? 0)} />
      <small>Step {run.currentStep ?? 0} of {run.totalSteps || '—'}{run.currentAction ? ` · ${run.currentAction}` : ''} · {run.profileId}</small>
    </article>)}
    <div className="aj-inline">
      <h3 className="aj-spacer">Run history</h3>
      <button className="aj-button small" onClick={() => void refresh()}>Refresh activity</button>
    </div>
    <div className="aj-grid two aj-run-filters">
      <label>Search run history<input value={search} placeholder="Workflow, profile or run ID…" onChange={event => setSearch(event.target.value)} /></label>
      <label>Filter run history<select value={filter} onChange={event => setFilter(event.target.value)}>
        {filters.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
      </select></label>
    </div>
    {matching.map(run => <details className="aj-run-record" key={run.id}>
      <summary className="aj-activity-row">
        <strong>{run.workflowName}</strong>
        <span className={`aj-pill ${run.status === 'completed' ? 'success' : ''}`}>{run.status.replace(/_/g, ' ')}</span>
        <small>{new Date(run.startedAt).toLocaleString()}</small>
      </summary>
      <p>{[run.profileId, run.source, run.durationMs != null ? `${(run.durationMs / 1000).toFixed(1)}s` : ''].filter(Boolean).join(' · ')}</p>
      {run.message && <p>{run.message}</p>}
      {run.steps?.length ? <ol className="aj-step-review">{run.steps.map(step => <li key={step.step}>
        <strong>{step.action}</strong> · {step.status?.replace(/_/g, ' ') || (step.ok ? 'Completed' : 'Failed')}
        {step.detail && <p>{step.detail}</p>}
      </li>)}</ol> : null}
    </details>)}
    {!matching.length && <p>{history.length ? 'No runs match these filters.' : 'Completed and stopped runs will appear here.'}</p>}
  </section>;
}
