import { desktop, invoke } from './bridge';

export async function qaCommand<T>(operation: string, input: Record<string, unknown> = {}): Promise<T> {
  if (desktop) return invoke<T>('qa_workspace', { operation, input });
  const response = await fetch('/api/qa', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-AJBOT-QA': '1' },
    body: JSON.stringify({ operation, input }),
  });
  if (!response.headers.get('content-type')?.includes('application/json')) {
    throw new Error('Open the desktop app or start the local backend with npm run qa:start.');
  }
  const reply = await response.json();
  if (!response.ok) throw new Error(reply.error || 'The QA request failed.');
  return reply.data as T;
}
