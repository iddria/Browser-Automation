export type Provider = { id: string; name: string; model: string; color: string; kind: string; group: 'text' | 'voice'; presets: string[] };
export type ProviderModel = { id: string; name: string };
export const providers: Provider[] = [
  { id:'anthropic', name:'Anthropic', model:'claude-sonnet-4-5', color:'#d8ac8d', kind:'AI planning', group:'text', presets:['claude-sonnet-4-5','claude-opus-4-1','claude-sonnet-5','claude-fable-5','claude-3-5-sonnet-latest','claude-3-5-haiku-latest'] },
  { id:'openai', name:'OpenAI', model:'gpt-4o-mini', color:'#67d7b1', kind:'AI planning', group:'text', presets:['gpt-4o-mini','gpt-4o','gpt-4.1','gpt-4.1-mini','gpt-4.1-nano','gpt-5.6-sol','gpt-5.6-luna','o3-mini'] },
  { id:'gemini', name:'Google Gemini', model:'gemini-2.5-flash', color:'#67a7ff', kind:'AI planning', group:'text', presets:['gemini-2.5-flash','gemini-2.5-pro','gemini-2.0-flash','gemini-2.5-flash-lite','gemini-3.6-flash','gemini-3.5-flash','gemini-3.5-flash-lite'] },
  { id:'openrouter', name:'OpenRouter', model:'openai/gpt-4o-mini', color:'#ae8afc', kind:'AI planning · model catalogue', group:'text', presets:['openai/gpt-4o-mini','openai/gpt-4o','deepseek/deepseek-v4-flash','deepseek/deepseek-v4-pro','deepseek/deepseek-v3.2','deepseek/deepseek-chat-v3.1','deepseek/deepseek-r1','deepseek/deepseek-chat','google/gemini-3.6-flash','google/gemini-3.5-flash','google/gemini-3.5-flash-lite','google/gemini-2.5-flash','google/gemini-2.0-flash-exp:free','anthropic/claude-sonnet-5','anthropic/claude-fable-5','anthropic/claude-3.5-sonnet','anthropic/claude-3.5-haiku','openai/gpt-5.6-sol','openai/gpt-5.6-luna','google/gemini-2.5-pro','deepseek/deepseek-flash','x-ai/grok-3'] },
  { id:'deepseek', name:'DeepSeek', model:'deepseek-flash', color:'#6594ff', kind:'AI planning', group:'text', presets:['deepseek-flash','deepseek-v4-pro','deepseek-v4-flash','deepseek-chat','deepseek-reasoner','deepseek-v3.2'] },
  { id:'grok', name:'Grok (xAI)', model:'grok-4', color:'#c4c9d9', kind:'AI planning', group:'text', presets:['grok-4','grok-3','grok-3-mini'] },
  { id:'ollama', name:'Ollama (local)', model:'qwen2.5:7b', color:'#a7b8e1', kind:'Local AI planning · no API key', group:'text', presets:['qwen2.5:7b','llama3.2','qwen3:8b'] },
  { id:'native-voice', name:'Google / Native System Voice', model:'', color:'#b2a6ff', kind:'System speech', group:'voice', presets:[] },
  { id:'elevenlabs', name:'ElevenLabs AI Voice', model:'', color:'#f4d373', kind:'Voice adapter required', group:'voice', presets:[] },
  { id:'openai-voice', name:'OpenAI TTS Engine', model:'', color:'#75cdb0', kind:'Voice adapter required', group:'voice', presets:[] },
  { id:'fish', name:'Fish.audio Voice', model:'', color:'#78c7f5', kind:'Voice adapter required', group:'voice', presets:[] },
];
export const plannerProviders = providers.filter(p => p.group === 'text');
export function defaultModel(provider: string) { return plannerProviders.find(p => p.id === provider)?.model || ''; }
export function modelChoices(provider: string, cached: ProviderModel[] = []): ProviderModel[] {
  const config = plannerProviders.find(p => p.id === provider);
  return [...new Map([...cached, ...(config?.presets || []).filter(id => !cached.some(m => m.id === id)).map(id => ({ id, name:id }))].map(m => [m.id, m])).values()];
}
