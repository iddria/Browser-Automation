import { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { invoke } from './bridge';
import { useStored } from './model';
import { type ProviderModel, defaultModel, modelChoices, plannerProviders } from './providerCatalog';
export default function ProviderModelFields({ provider, model, onProvider, onModel, loadModels, labels = { provider: 'AI provider', model: 'AI model' } }: { provider: string; model: string; onProvider: (value: string) => void; onModel: (value: string) => void; loadModels?: (provider: string) => Promise<ProviderModel[]>; labels?: { provider: string; model: string } }) {
  const [cache, setCache] = useStored<Record<string, ProviderModel[]>>('model-catalogues', {});
  const [custom, setCustom] = useState(false); const [busy, setBusy] = useState(false); const [notice, setNotice] = useState('');
  const choices = modelChoices(provider, cache[provider]);
  const useCustom = custom || !!model && !choices.some(m => m.id === model);
  return <div className="aj-provider-model-fields"><div className="aj-grid two"><label>{labels.provider}<select aria-label={labels.provider} value={provider} onChange={e => { setCustom(false); setNotice(''); onProvider(e.target.value); onModel(defaultModel(e.target.value)); }}>{plannerProviders.map(p => <option value={p.id} key={p.id}>{p.name}</option>)}</select></label><label>{labels.model}<select aria-label={labels.model} value={useCustom ? '__custom' : model} onChange={e => { if (e.target.value === '__custom') setCustom(true); else { setCustom(false); onModel(e.target.value); } }}><option value="">Auto / default</option>{choices.map(m => <option key={m.id} value={m.id}>{m.id}</option>)}<option value="__custom">Custom model ID…</option></select></label></div>
    {useCustom && <label>Custom model ID<input aria-label="Custom model ID" value={model} maxLength={120} onChange={e => onModel(e.target.value)} /></label>}
    <button type="button" className="aj-button small" disabled={busy} onClick={async () => { setBusy(true); setNotice(''); try { const list = await (loadModels ? loadModels(provider) : invoke<ProviderModel[]>('list_provider_models', { provider })); setCache(c => ({ ...c, [provider]: list })); setNotice(`${list.length} models loaded from ${plannerProviders.find(p => p.id === provider)?.name}.`); } catch (error) { setNotice(String(error)); } finally { setBusy(false); } }}><RefreshCw size={12} />{busy ? 'Loading models…' : 'Refresh provider models'}</button>
    <small>Presets include model IDs shown in the reference. Refresh to discover the provider’s current catalogue, or enter a custom ID. Availability depends on your key and provider.</small>{notice && <p className="aj-notice" role="status">{notice}</p>}
  </div>;
}
