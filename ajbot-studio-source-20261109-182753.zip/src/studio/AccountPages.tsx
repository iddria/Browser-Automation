import { useEffect, useState, type ReactNode } from 'react';
import { Archive, Coins, Download, KeyRound, ShieldCheck, Upload, Volume2 } from 'lucide-react';
import { desktop, invoke } from './bridge';
import EnginePanel from './EnginePanel';
import AutomaticBackups from '../AutomaticBackups';
import { ProfileArchiveControls } from './ProfileTools';
export { EarnMode, Machines } from './EarnMode';
import { type ProviderModel } from './providerCatalog';
import { type CapacitySettings, parseCapacity } from './capacity';
import { type Flow, type Pod, type Session, downloadJson, normalizeStepActions, providers, uid, useStored } from './model';

export function PageHeading({ title, description, children }: { title: string; description: string; children?: ReactNode }) {
  return <header className="aj-page-heading"><div><h1>{title}</h1><p>{description}</p></div>{children}</header>;
}
export function Empty({ icon, title, description, children }: { icon: ReactNode; title: string; description?: string; children?: ReactNode }) {
  return <div className="aj-empty">{icon}<strong>{title}</strong>{description && <p>{description}</p>}{children}</div>;
}
export function ProviderKeys() {
  const [catalogues, setCatalogues] = useStored<Record<string, ProviderModel[]>>('model-catalogues', {});
  const [saved, setSaved] = useState<string[]>([]); const [values, setValues] = useState<Record<string, string>>({}); const [message, setMessage] = useState('');
  useEffect(() => { invoke<string[]>('list_provider_keys').then(setSaved).catch(e => setMessage(String(e))); }, []);
  const save = async (provider: string) => {
    try {
      await invoke('save_provider_key', { provider, key: values[provider] || '' });
      setValues(v => ({ ...v, [provider]: '' })); setSaved(await invoke<string[]>('list_provider_keys')); setMessage('Key saved using Windows encryption.');
    } catch (e) { setMessage(String(e)); }
  };
  return <div className="aj-narrow"><PageHeading title="Provider Keys" description="Bring your own AI keys. Configure your providers and system voice."><button className="aj-button" onClick={() => document.getElementById('browser-engine-tools')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>Engine tools</button></PageHeading>
    <div className="aj-banner"><KeyRound size={20} /><p>Keys are encrypted for your Windows account and excluded from workspace exports. All six cloud text providers and local Ollama are available to the planner. Voice API cards retain their configuration; system speech is available below.</p></div>
    {message && <p className="aj-notice" role="status">{message}</p>}
    <h2>Text AI &amp; Voice providers</h2><p>7 text providers · 4 voice options. Scroll to see all cards and expand a provider to view its models.</p><div className="aj-grid two">{providers.map(p => <article className="aj-card aj-provider" key={p.id}><div className="aj-card-title"><span className="aj-provider-icon" style={{ color: p.color }}><KeyRound size={20} /></span><div><h3>{p.name}</h3><small>{p.kind}{p.group === 'text' ? ` · ${(catalogues[p.id] || p.presets).length} ${catalogues[p.id] ? 'catalogue models' : 'presets'}` : ''}</small></div><span className="aj-pill">{p.id === 'ollama' ? 'Local' : p.id === 'native-voice' ? 'System' : saved.includes(p.id) ? 'Key saved' : 'Not set'}</span></div>
      {p.id === 'ollama' ? <p>Uses the local Ollama server on this device. No API key is needed.</p> : p.id === 'native-voice' ? <button className="aj-button" onClick={() => { if (!('speechSynthesis' in window)) return setMessage('System speech is unavailable on this device.'); window.speechSynthesis.cancel(); window.speechSynthesis.speak(new SpeechSynthesisUtterance('Welcome to AJBOT Studio. Your workspace is ready.')); }}><Volume2 size={14} /> Test system speech</button> : <div className="aj-inline"><input type="password" autoComplete="off" aria-label={`${p.name} API key`} value={values[p.id] || ''} placeholder={saved.includes(p.id) ? 'Replace key…' : 'API key…'} onChange={e => setValues(v => ({ ...v, [p.id]: e.target.value }))} /><button className="aj-button primary" disabled={!values[p.id]?.trim()} onClick={() => void save(p.id)}>Save</button>{saved.includes(p.id) && <button className="aj-button small" onClick={() => void invoke('delete_provider_key', { provider: p.id }).then(() => setSaved(s => s.filter(id => id !== p.id))).catch(e => setMessage(String(e)))}>Remove</button>}</div>}
    {p.group === 'text' && <details className="aj-provider-model-details"><summary>Models for {p.name}</summary><button type="button" className="aj-button small" onClick={async () => { try { const list = await invoke<ProviderModel[]>('list_provider_models', { provider: p.id }); setCatalogues(c => ({ ...c, [p.id]: list })); setMessage(`${list.length} models loaded for ${p.name}.`); } catch(error) { setMessage(String(error)); } }}>Refresh models</button><p>Presets are editable model choices. Refresh retrieves the provider’s catalogue.</p><ul>{(catalogues[p.id] || p.presets.map(id => ({ id, name:id }))).map(m => <li key={m.id}>{m.id}</li>)}</ul></details>}
    </article>)}</div>
    <EnginePanel />
  </div>;
}
export function Handover({ pods, sessions, onImport, workflows }: { pods: Pod[]; sessions: Session[]; workflows: Flow[]; onImport: (pods: Pod[], sessions: Session[]) => void }) {
  const [tradeId, setTradeId] = useState(''); const [handoverId, setHandoverId] = useState(''); const [message, setMessage] = useState('');
  const exportPackage = () => {
    const id = uid('handover'); setHandoverId(id);
    // Profile data/cookies and secrets stay inside the existing native backup workflow.
    downloadJson('ajbot-handover.json', { format: 'ajbot-handover', version: 1, id, tradeId, createdAt: new Date().toISOString(), workflows, pods, sessions });
    setMessage('Handover file exported. Includes workflows and group/session settings; excludes browser cookies and API keys.');
  };
  return <div className="aj-narrow"><PageHeading title="Handover" description="Move workflow definitions and workspace settings between your own installations." />
    <section className="aj-card"><div className="aj-grid two"><label>Trade ID (optional reference)<input placeholder="TRD-XXXXXXXX" value={tradeId} onChange={e => setTradeId(e.target.value)} /></label><label>Handover ID<input value={handoverId} placeholder="Generated when you export" readOnly /></label></div><p>A local file handover is available. No marketplace or buyer verification service is configured.</p><div className="aj-inline"><button className="aj-button primary" onClick={exportPackage}><Download size={15} /> Export handover file</button><label className="aj-button"><Upload size={15} /> Import handover file<input type="file" accept=".json" hidden onChange={async e => {
      const f = e.target.files?.[0]; e.target.value = ''; if (!f) return;
      try {
        if (f.size > 2 * 1024 * 1024) throw new Error('Maximum file size is 2 MB.');
        const raw = JSON.parse(await f.text());
        if (raw.format !== 'ajbot-handover' || raw.version !== 1 || !Array.isArray(raw.workflows) || !Array.isArray(raw.pods) || !Array.isArray(raw.sessions)) throw new Error('Invalid handover file.');
        // Validate every entry before the first write. Only flow definitions are imported;
        // profile IDs cannot be used to claim another installation's browser data.
        if (raw.workflows.length > 200 || raw.pods.length > 200 || raw.sessions.length > 200) throw new Error('Too many workspace definitions.');
        const allowed = new Set(['navigate','back','forward','reload','newTab','closeTab','switchTab','click','clickText','clickRole','doubleClick','rightClick','hover','fill','fillLabel','type','clear','press','select','check','uncheck','scroll','wait','waitForSelector','waitForURL','waitForText','extractText','extractLinks','screenshot','setVariable','ifText','ifUrl','ifVariable']);
        for (const w of raw.workflows) {
          if (Array.isArray(w.steps)) w.steps = normalizeStepActions(w.steps);
          if (typeof w.name !== 'string' || !w.name.trim() || !Array.isArray(w.steps) || !w.steps.length || w.steps.length > 50 || w.steps.some((s: any) => !s || !allowed.has(s.action))) throw new Error('Invalid workflow definition.');
        }
        for (const p of raw.pods) if (typeof p.id !== 'string' || typeof p.name !== 'string' || !p.name.trim()) throw new Error('Invalid pod definition.');
        for (const s of raw.sessions) if (typeof s.name !== 'string' || typeof s.workflowId !== 'string' || typeof s.podId !== 'string') throw new Error('Invalid session definition.');
        if (!window.confirm(`Import ${raw.workflows.length} workflows, ${raw.pods.length} empty groups and ${raw.sessions.length} sessions as separate copies? Nothing will execute. Assign local profiles after import.`)) return;
        const flowIds = new Map<string,string>();
        for (const w of raw.workflows) { const id=uid('import'); await invoke('save_browser_workflow', { workflowId: id, name: `${w.name} (imported)`, steps: w.steps }); flowIds.set(w.id,id); }
        const podIds = new Map<string,string>();
        const importedPods: Pod[] = raw.pods.map((p: any) => { const id=uid('pod'); podIds.set(p.id,id); return { id, name: `${p.name} (imported)`, profiles: [], devices: {}, workflowId: flowIds.get(p.workflowId), createdAt: Date.now() }; });
        const importedSessions: Session[] = raw.sessions.map((s: any) => ({ id: uid('session'), name: `${s.name} (imported)`, createdAt: Date.now(), type: ['Warmer','Swarmer','Custom'].includes(s.type) ? s.type : 'Custom', podId: podIds.get(s.podId) || '', workflowId: flowIds.get(s.workflowId) || '', proxyId: '', provider: ['openai','anthropic','gemini','openrouter','deepseek','grok','ollama'].includes(s.provider) ? s.provider : 'ollama', model: typeof s.model === 'string' ? s.model.slice(0,120) : 'qwen2.5:7b', incognito: !!s.incognito, vision: false, deviceRanges: s.deviceRanges && typeof s.deviceRanges === 'object' ? s.deviceRanges : undefined }));
        onImport(importedPods, importedSessions); setMessage('Workspace definitions imported as copies. Browser data and keys were excluded. Assign local profiles to the imported groups before running.');
      } catch (err) { setMessage(String(err)); }
    }} /></label></div>{message && <p className="aj-notice" role="status">{message}</p>}</section>
  </div>;
}
export function BackupPage({ openProfiles, refresh, exportWorkspace }: {
  openProfiles: () => void; refresh: () => Promise<void>; exportWorkspace: () => void;
}) {
  const [automatic, setAutomatic] = useState(false);
  return <>
    <PageHeading title="Backup" description="Keep recoverable copies of your profiles and workflow definitions.">
      <div className="aj-segment" role="group" aria-label="Backup tools">
        <button className={!automatic ? 'selected' : ''} aria-pressed={!automatic} onClick={() => setAutomatic(false)}>Manual backups</button>
        <button className={automatic ? 'selected' : ''} aria-pressed={automatic} onClick={() => setAutomatic(true)}>Automatic backups</button>
      </div>
    </PageHeading>
    {automatic ? <AutomaticBackups /> : <section className="aj-card">
      <h3><ShieldCheck size={17} /> Profile archives</h3>
      <p>Stop a profile before backing it up. Profile archives may contain cookies and site sessions.</p>
      <div className="aj-inline aj-wrap">
        <button className="aj-button primary" onClick={openProfiles}><Archive size={15} /> Back up a profile in Solo Mode</button>
        <ProfileArchiveControls refresh={refresh} />
        <button className="aj-button" onClick={exportWorkspace}><Download size={15} /> Export workspace definitions</button>
      </div>
      <p>Workspace exports contain definitions and settings. Browser data is saved in profile archives.</p>
    </section>}
  </>;
}
export function AccessDialog({ close }: { close: () => void }) {
  return <div className="aj-modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) close(); }}><section className="aj-modal aj-license" role="dialog" aria-modal="true" aria-labelledby="access-title"><button className="aj-modal-close" aria-label="Close access dialog" onClick={close}>×</button><span className="aj-pill">EDUCATIONAL EDITION</span><h2 id="access-title">Your workspace access</h2><p>All local tools are available. This project has no paid licensing server or wallet connection.</p><div className="aj-card"><Coins size={22} /><h3>Account-Level License Inheritance</h3><p>The reference app’s license and wallet screens are represented as a local demonstration. No payments are collected.</p></div>{['Fund Your Web Wallet','Select a License Plan','Automatic Instant Sync'].map((s, i) => <div className="aj-license-step" key={s}><span>{i + 1}</span><div><strong>{s}</strong><p>Requires your own authenticated account and billing backend.</p></div></div>)}<button className="aj-button primary" onClick={close}>Continue with local tools</button></section></div>;
}
export function SettingsPage({ capacity, onCapacityChange }: { capacity: CapacitySettings; onCapacityChange: (value: CapacitySettings) => void }) {
  const [name, setName] = useStored('display-name', 'Iddriss'); const [message, setMessage] = useState('');
  const [sessionLimit, setSessionLimit] = useState(String(capacity.concurrentSessions));
  const [batchLimit, setBatchLimit] = useState(String(capacity.profilesPerBatch));
  const [capacityMessage, setCapacityMessage] = useState('');
  return <><PageHeading title="Settings" description="Personalize your local workspace." /><form className="aj-card" onSubmit={e => {
    e.preventDefault();
    try {
      onCapacityChange({ concurrentSessions: parseCapacity(sessionLimit, 'Concurrent sessions'), profilesPerBatch: parseCapacity(batchLimit, 'Profiles per batch') });
      setCapacityMessage('Capacity settings saved. Changes apply to new starts and batches; active sessions keep running.');
    } catch (error) { setCapacityMessage(String(error)); }
  }}><h3>Workspace capacity</h3><p>You control these settings. Use 0 for no fixed application cap. Available memory, CPU, disk space and provider quotas determine practical capacity.</p><div className="aj-grid two"><label>Concurrent sessions (0 = no fixed cap)<input type="number" min="0" step="1" required value={sessionLimit} onChange={e => setSessionLimit(e.target.value)} /></label><label>Profiles per batch (0 = no fixed cap)<input type="number" min="0" step="1" required value={batchLimit} onChange={e => setBatchLimit(e.target.value)} /></label></div><button type="submit" className="aj-button primary">Save capacity settings</button>{capacityMessage && <p className="aj-notice" role="status">{capacityMessage}</p>}</form><section className="aj-card"><label>Display name<input value={name} maxLength={80} onChange={e => setName(e.target.value)} /></label><p>Your changes are saved on this device.</p><button className="aj-button" onClick={() => void invoke<string>('check_node').then(setMessage).catch(e => setMessage(String(e)))}>Check Node.js & worker</button>{message && <p role="status" className="aj-notice">{message}</p>}<p>{desktop ? 'Desktop execution is available through the native browser worker.' : 'Browser preview: drafts can be saved locally. Use the desktop app to run browser automation.'}</p></section></>;
}
