import { useEffect, useRef, useState } from 'react';
import { Activity, Boxes, Flame, Copy, Monitor, Pause, Pencil, Play, Plus, Power, Search, Square, Trash2, Workflow, Zap } from 'lucide-react';
import { desktop, invoke, listen } from './bridge';
import { type Flow, type Pod, type Profile, type ProfileNote, type Session, devices, providers, uid, useStored } from './model';
import { Empty, PageHeading } from './AccountPages';
import { ProfileBackupButton, ProfileEditor, RecorderPanel, useProfileRecorder } from './ProfileTools';
import RunHistory, { type LiveRun, type RunRecord } from './RunHistory';
import WebSearchPanel from '../WebSearchPanel';
import ProviderModelFields from './ProviderModelFields';
import { activityCounts, type Period } from './activity';
import { deviceLabels, deviceTimezone, profileDevice, sessionWaves, validateDeviceRanges } from './sessionDevices';
import { type CapacitySettings, profileBatchError, sessionCapacityReached } from './capacity';

export function Overview({ sessions, pods, workflows, history, liveRuns, openDraft, refresh }: {
  sessions: Session[]; pods: Pod[]; workflows: Flow[]; history: RunRecord[]; liveRuns: LiveRun[];
  openDraft: (flow: Flow) => void; refresh: () => Promise<void>;
}) {
  const [name] = useStored('display-name', 'Iddriss'); const [tab, setTab] = useState('Overview'); const [period, setPeriod] = useState<Period>('All');
  const categories = activityCounts(workflows, sessions, pods, period);
  const maxCategory = Math.max(1, ...categories.map(c => c.count));
  const now = Date.now(); const shown = history.filter(r => period === 'All' || r.startedAt >= now - (period === '7d' ? 7 : 30) * 86400000);
  const byDay = new Map<string, number>(); const hours = new Array(24).fill(0);
  shown.forEach(r => { const d = new Date(r.startedAt); const key = d.toLocaleDateString('en-CA'); byDay.set(key, (byDay.get(key) || 0) + (r.steps?.length || 0)); hours[d.getHours()] += r.steps?.length || 0; });
  const activeDates = [...new Set(history.map(r => new Date(r.startedAt).setHours(0, 0, 0, 0)))].sort((a,b) => a-b);
  let longest = 0, streak = 0, previous = 0;
  activeDates.forEach(day => { streak = previous && Math.round((day-previous)/86400000) === 1 ? streak + 1 : 1; longest = Math.max(longest, streak); previous = day; });
  const today = new Date().setHours(0,0,0,0); const current = previous >= today - 86400000 ? streak : 0;
  const actions = shown.reduce((n, r) => n + (r.steps?.length || 0), 0); const peak = hours.indexOf(Math.max(...hours));
  const cells = Array.from({ length: 364 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - 363 + i); return { date: d.toLocaleDateString('en-CA'), count: byDay.get(d.toLocaleDateString('en-CA')) || 0 }; });
  return <div className="aj-overview"><h1><Zap size={27} /> What’s up next, {name || 'there'}?</h1><div className="aj-overview-tabs"><div className="aj-segment">{['Overview','Activity','Web search'].map(t => <button className={tab === t ? 'selected' : ''} aria-pressed={tab === t} key={t} onClick={() => setTab(t)}>{t}</button>)}</div>{tab !== 'Web search' && <div className="aj-segment">{['All','30d','7d'].map(p => <button className={period === p ? 'selected' : ''} key={p} onClick={() => setPeriod(p as Period)}>{p}</button>)}</div>}</div>
    {tab === 'Overview' ? <section className="aj-analytics"><div className="aj-stat-grid">{[['Sessions', sessions.length],['Total actions', actions],['Active days', byDay.size],['Peak hour', actions ? new Date(2026,0,1,peak).toLocaleTimeString([], { hour: 'numeric' }) : '—'],['Current streak', `${current}d`],['Longest streak', `${longest}d`],['Pods created', pods.length],['Top activity', shown.length ? 'Workflows' : '—']].map(([label, value]) => <div key={label}><small>{label}</small><strong>{value}</strong></div>)}</div><div className="aj-calendar"><div className="aj-months">{Array.from({ length: 12 }, (_, i) => { const d = new Date(); d.setMonth(d.getMonth() - 11 + i); return <span key={i}>{d.toLocaleDateString([], { month: 'short' })}</span>; })}</div><div className="aj-heatmap">{cells.map(c => <span title={`${c.date}: ${c.count} actions`} key={c.date} className={c.count ? 'has-activity' : ''} style={c.count ? { opacity: Math.min(1, .45 + c.count / 25) } : undefined} />)}</div><div className="aj-heat-legend">Less <i /><i /><i className="filled" /> More</div></div><footer>{actions ? `You average ${Math.round(actions / Math.max(1, byDay.size))} actions on an active day.` : 'Your activity will appear here when you run your first workflow.'}</footer></section> : tab === 'Web search' ? <WebSearchPanel onCreateWorkflow={result => openDraft({
      id: '', name: `Search · ${result.title || result.url}`.slice(0, 120), steps: [{ action: 'navigate', url: result.url }],
    })} /> : <section className="aj-activity-panel" aria-label="Workspace activity"><div className="aj-grid two aj-activity-categories">{categories.map(({ label, count }, i) => { const Icon = [Workflow, Flame, Activity, Workflow, Boxes][i]; return <article className="aj-activity-category" key={label}><div><span className="aj-feature-icon"><Icon size={17} /></span><strong>{label}</strong><b>{count}</b></div><progress aria-label={`${label} activity`} value={count} max={maxCategory} /></article>; })}</div><p className="aj-footnote">{period === 'All' ? 'Saved items in this workspace.' : 'Items created or updated in the selected period. Older items without dates appear under All.'}</p><RunHistory history={shown} liveRuns={liveRuns} refresh={refresh} /></section>}

  </div>;
}
type ProxyChoice = { id: string; name: string };
type PodRunRequest = { podId: string; id: string };
type PodSchedule = { id: string; podId?: string; scheduledAt: number; nextRunAt: number; repeat: string; enabled: boolean; members?: { profileId: string }[] };
const podScheduleId = (id: string) => `schedule-for-${id}`;
const trainingPods = Array.from({ length: 100 }, (_, index) => {
  const number = String(index + 1).padStart(3, '0');
  return {
    id: `pod-training-${number}`,
    profileId: `profile-training-${number}`,
    name: `Training Pod ${number}`,
    email: `pod-${number}@example.test`,
    device: deviceLabels[index % deviceLabels.length],
  };
});
const trainingPodById = new Map(trainingPods.map(pod => [pod.id, pod]));

export function Pods({ capacity, pods, setPods, profiles, workflows, refresh, notify, runPod }: {
  capacity: CapacitySettings; pods: Pod[]; setPods: (p: Pod[] | ((current: Pod[]) => Pod[])) => void;
  profiles: Profile[]; workflows: Flow[]; refresh: () => Promise<void>; notify: (s: string) => void; runPod: (id: string) => void;
}) {
  const [counts, setCounts] = useState<Record<string, number>>({ iPhone: 0, Android: 0, Mac: 0, Windows: 0 }); const [name, setName] = useState(''); const [busy, setBusy] = useState(false); const [manage, setManage] = useState(false);
  const [settings, setSettings] = useState<Pod | null>(null);
  const [proxies, setProxies] = useState<ProxyChoice[]>([]);
  const [schedules, setSchedules] = useState<PodSchedule[]>([]);
  const [scheduledAt, setScheduledAt] = useState('');
  const [repeat, setRepeat] = useState('once');
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (!manage) return;
    void Promise.all([
      invoke<ProxyChoice[]>('list_proxies').then(setProxies),
      invoke<PodSchedule[]>('list_schedules').then(setSchedules),
    ]).catch(error => notify(String(error)));
  }, [manage, notify]);
  const configure = (pod: Pod) => {
    const schedule = schedules.find(item => item.podId === pod.id);
    const date = new Date(schedule?.nextRunAt || Date.now() + 3_600_000);
    setScheduledAt(new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16));
    setRepeat(schedule?.repeat || 'once');
    setSettings(pod);
  };
  const saveSettings = (pod: Pod) => {
    setPods(current => current.map(p => p.id === pod.id ? { ...p, workflowId: pod.workflowId, proxyId: pod.proxyId } : p));
    setSettings(null);
  };
  const savePodSchedule = async (pod: Pod) => {
    const members = profiles.filter(profile => pod.profiles.includes(profile.id))
      .map(profile => ({ profileId: profile.id, deviceClass: profileDevice(profile, [pod]) }));
    const timestamp = new Date(scheduledAt).getTime();
    if (!pod.workflowId || !members.length) return notify('Choose a workflow and add local profiles to the pod first.');
    if (!Number.isFinite(timestamp) || timestamp <= Date.now() + 30_000) return notify('Choose a start time at least 30 seconds in the future.');
    setSaving(true);
    try {
      const schedule = await invoke<PodSchedule>('save_schedule', {
        id: podScheduleId(pod.id), name: `Pod · ${pod.name}`.slice(0, 100), podId: pod.id, members,
        workflowId: pod.workflowId, profileId: members[0].profileId, proxyId: pod.proxyId || null, repeat, scheduledAt: timestamp,
      });
      setSchedules(current => [...current.filter(item => item.id !== schedule.id), schedule]);
      saveSettings(pod);
      notify(`Schedule saved for ${members.length} pod ${members.length === 1 ? 'profile' : 'profiles'}. Manage its status in Scheduler.`);
    } catch (error) { notify(String(error)); }
    finally { setSaving(false); }
  };
  const total = Object.values(counts).reduce((a,b) => a+b,0);
  const batchError = profileBatchError(counts, capacity.profilesPerBatch);
  const cancelBatch = useRef(false);
  const [created, setCreated] = useState(0);
  const [trainingBusy, setTrainingBusy] = useState(false);
  const profilesById = new Map(profiles.map(profile => [profile.id, profile]));
  const podsById = new Map(pods.map(pod => [pod.id, pod]));
  const missingTrainingPods = trainingPods.filter(item =>
    !profilesById.has(item.profileId) || !podsById.get(item.id)?.profiles.includes(item.profileId),
  );
  const nextTrainingBatch = missingTrainingPods.slice(0, capacity.profilesPerBatch || trainingPods.length);
  useEffect(() => () => { cancelBatch.current = true; }, []);
  const createTrainingPods = async () => {
    if (busy || !nextTrainingBatch.length) return;
    cancelBatch.current = false;
    setTrainingBusy(true);
    setBusy(true);
    setCreated(0);
    let completed = 0;
    try {
      for (const item of nextTrainingBatch) {
        if (cancelBatch.current) break;
        const profileName = `${item.name} · ${item.device}`;
        const profile = profilesById.get(item.profileId);
        const existingPod = podsById.get(item.id);
        if (profile && !existingPod?.profiles.includes(profile.id) &&
          (profile.name !== profileName || profile.deviceClass !== item.device)) {
          throw new Error(`Profile ID ${item.profileId} is already in use.`);
        }
        if (!profile) await invoke('create_browser_profile', {
          profileId: item.profileId, name: profileName, deviceClass: item.device,
          startUrl: 'https://accounts.google.com/',
        });
        setPods(current => {
          const saved = current.find(pod => pod.id === item.id);
          const next: Pod = {
            ...saved, id: item.id, name: saved?.name ?? item.name, createdAt: saved?.createdAt ?? Date.now(),
            profiles: [...new Set([...(saved?.profiles ?? []), item.profileId])],
            devices: { ...saved?.devices, [item.profileId]: item.device },
          };
          return saved ? current.map(pod => pod.id === item.id ? next : pod) : [...current, next];
        });
        setCreated(++completed);
      }
      const ready = trainingPods.length - missingTrainingPods.length + completed;
      notify(`${ready} of ${trainingPods.length} training pods are ready.${cancelBatch.current ? ' Batch cancelled.' : ''}`);
    } catch (error) {
      notify(`Training setup stopped after ${completed} pods. ${String(error)}`);
    } finally {
      await refresh();
      setTrainingBusy(false);
      setBusy(false);
    }
  };
  const create = async (source?: Pod) => {
    if (busy || !source && (!name.trim() || !total || batchError)) return;
    const originals = source ? profiles.filter(profile => source.profiles.includes(profile.id)) : [];
    if (source && !originals.length) return notify('This pod has no local profiles to clone.');
    if (source && capacity.profilesPerBatch && originals.length > capacity.profilesPerBatch) return notify('This clone exceeds the profile batch setting.');
    let podName = source ? `${source.name} copy` : name.trim();
    if (source) {
      for (let copy = 2; pods.some(pod => pod.name.toLowerCase() === podName.toLowerCase()); copy++) podName = `${source.name} copy ${copy}`;
    }
    function* definitions() {
      if (source) {
        for (const profile of originals) yield { device: profileDevice(profile, [source]), startUrl: profile.startUrl };
        return;
      }
      for (const device of devices) for (let i = 0; i < counts[device]; i++) yield { device, startUrl: 'https://example.com' };
    }
    cancelBatch.current = false; setCreated(0);
    setBusy(true); let next: Pod | undefined; let completed = 0;
    try {
      const existing = !source && pods.find(p => p.name.toLowerCase() === podName.toLowerCase());
      next = existing ? structuredClone(existing) : { id: uid('pod'), name: podName, profiles: [], devices: {}, createdAt: Date.now(), workflowId: source?.workflowId, proxyId: source?.proxyId };
      for (const { device, startUrl } of definitions()) {
        if (cancelBatch.current) break;
        const id = uid('profile'); const number = next.profiles.length + 1;
        await invoke('create_browser_profile', { profileId: id, name: `${podName}_${device.toLowerCase()}-${String(number).padStart(4,'0')}`, startUrl, deviceClass: device });
        next.profiles.push(id); next.devices[id] = device;
        completed++; setCreated(completed);
        const checkpoint = structuredClone(next);
        setPods(current => current.some(p => p.id === checkpoint.id) ? current.map(p => p.id === checkpoint.id ? checkpoint : p) : [...current, checkpoint]);
      }
      if (!source) setCounts({ iPhone: 0, Android: 0, Mac: 0, Windows: 0 }); notify(`${completed} browser profile definitions created in ${next.name}.${cancelBatch.current ? " Batch cancelled; created profiles are retained." : ""}`);
    } catch(e) { notify(`Creation stopped: ${String(e)}. Successfully created profiles are retained.`); }
    finally { await refresh(); setBusy(false); }
  };
  return <div className="aj-pods"><section className="aj-card aj-pod-hero"><div className="aj-card-title"><span className="aj-feature-icon"><Boxes size={26} /></span><div><h1>Create &amp; Append Pods</h1><p>Each slider queues browser profiles. Enter an existing pod name to append profiles.</p></div></div><div className="aj-inline"><button className="aj-button primary" disabled={busy} onClick={() => setManage(v => !v)}><Boxes size={16} /> Manage Pods ({pods.length})</button><div className="aj-queued"><strong>{total}</strong><small>queued</small></div></div></section>
    <div className="aj-banner"><Zap size={22} /><p><strong>LOCAL PROFILE GROUPS</strong><br />Device presets apply viewport, scale and touch settings for testing. Each profile keeps its own local browser data.</p></div>
    <section className="aj-card aj-inline">
      <div className="aj-spacer">
        <h3>100-pod training set</h3>
        <p>25 iPhone, 25 Android, 25 Mac and 25 Windows pods. Each has one local browser profile and a unique practice email label.</p>
        <small>{trainingPods.length - missingTrainingPods.length} of {trainingPods.length} ready. Practice labels are placeholders. Sign in through Solo Mode with authorized Google accounts.</small>
      </div>
      <button className="aj-button" disabled={busy || !nextTrainingBatch.length} onClick={() => void createTrainingPods()}>
        <Boxes size={16} />{trainingBusy ? `Creating ${created}…` : missingTrainingPods.length === trainingPods.length && nextTrainingBatch.length === trainingPods.length ? 'Create 100 training pods' : nextTrainingBatch.length ? `Create next ${nextTrainingBatch.length} training pods` : 'Training pods ready'}
      </button>
      {trainingBusy && <button className="aj-button" onClick={() => { cancelBatch.current = true; }}>Cancel training batch</button>}
    </section>
    {manage && <section className="aj-card"><h3>Manage Pods</h3>{pods.length ? pods.map(p => <div className="aj-pod-row" key={p.id}><Boxes size={18} /><input aria-label={`Pod name ${p.name}`} disabled={busy} value={p.name} onChange={e => setPods(pods.map(x => x.id === p.id ? { ...x, name: e.target.value } : x))} /><span>{p.profiles.filter(id => profiles.some(x => x.id === id)).length} profiles</span><button className="aj-button small" disabled={busy} onClick={() => configure(p)}><Pencil size={14} /> Configure</button><button className="aj-button small" disabled={busy} onClick={() => void create(p)}><Copy size={14} /> Clone</button><button className="aj-button small primary" disabled={busy || !p.workflowId} onClick={() => runPod(p.id)}><Play size={14} /> Run pod</button><button className="aj-button small" disabled={busy} onClick={() => { if (schedules.some(schedule => schedule.podId === p.id)) return notify('Remove the pod schedule in Scheduler before ungrouping.'); if (window.confirm(`Remove group “${p.name}”? Browser profiles will remain in Browser profiles.`)) setPods(pods.filter(x => x.id !== p.id)); }}><Trash2 size={14} /> Ungroup</button></div>) : <p>No pods yet.</p>}
      <details><summary>Group existing browser profiles</summary><p>Create a pod from profiles already present in the project.</p><button className="aj-button" disabled={busy || !profiles.length} onClick={() => { const groupName = window.prompt('Pod name'); if (!groupName?.trim()) return; const existing = pods.find(p => p.name.toLowerCase() === groupName.trim().toLowerCase()); if (existing) return notify('That pod name is already in use.'); setPods([...pods, { id: uid('pod'), name: groupName.trim(), profiles: profiles.map(p => p.id), devices: Object.fromEntries(profiles.map(p => [p.id, profileDevice(p, pods)])), createdAt: Date.now() }]); }}>Group all existing profiles</button></details></section>}
    {settings && <div className="aj-modal-backdrop"><section className="aj-modal" role="dialog" aria-modal="true" aria-label="Configure pod">
      <h2>{settings.name}</h2>
      {trainingPodById.has(settings.id) && <p>Practice email label · <strong>{trainingPodById.get(settings.id)?.email}</strong></p>}
      <label>Pod workflow<select value={settings.workflowId || ''} disabled={saving} onChange={e => setSettings({ ...settings, workflowId: e.target.value })}>
        <option value="">Choose a workflow</option>{workflows.map(flow => <option key={flow.id} value={flow.id}>{flow.name}</option>)}
      </select></label>
      <label>Pod proxy<select value={settings.proxyId || ''} disabled={saving} onChange={e => setSettings({ ...settings, proxyId: e.target.value })}>
        <option value="">Use each profile’s assigned proxy</option>{proxies.map(proxy => <option key={proxy.id} value={proxy.id}>{proxy.name}</option>)}
      </select></label>
      <section className="aj-card">
        <h3>Schedule pod</h3>
        <div className="aj-grid two"><label>Start date and time<input type="datetime-local" value={scheduledAt} disabled={saving} onChange={e => setScheduledAt(e.target.value)} /></label>
          <label>Repeat<select value={repeat} disabled={saving} onChange={e => setRepeat(e.target.value)}><option value="once">One time</option><option value="daily">Daily</option><option value="weekly">Weekly</option></select></label></div>
        <small>Schedules run locally while AJBOT is open. They save the current workflow, proxy and profile list. Review the workflow before scheduling it.</small>
        <button className="aj-button" disabled={!desktop || saving || !settings.workflowId} onClick={() => void savePodSchedule(settings)}>Save pod schedule</button>
      </section>
      <footer className="aj-modal-footer"><button className="aj-button" disabled={saving} onClick={() => setSettings(null)}>Cancel</button><button className="aj-button primary" disabled={saving} onClick={() => saveSettings(settings)}>Save pod settings</button></footer>
    </section></div>}

    <div className="aj-grid two">{devices.map(device => <article className="aj-card aj-device-card" key={device}><div className="aj-card-title"><Monitor size={16} /><h3>{device}</h3><input className="aj-profile-count" aria-label={`${device} profiles to create`} type="number" min="0" step="1" disabled={busy} value={counts[device]} onChange={e => setCounts(v => ({ ...v, [device]: Number(e.target.value) }))} /></div><input aria-label={`${device} profile count`} type="range" min="0" max={capacity.profilesPerBatch || Math.max(100, counts[device] || 0)} disabled={busy} value={counts[device]} onChange={e => setCounts(v => ({ ...v, [device]: Number(e.target.value) }))} /></article>)}</div>
    <section className="aj-card aj-inline"><label className="aj-spacer">Pod name<input placeholder="e.g. classroom_research" value={name} disabled={busy} onChange={e => setName(e.target.value)} /><small>Profiles are labelled Pod_device-0001, Pod_device-0002, …</small></label><button className="aj-button primary" disabled={busy || !name.trim() || !total || !!batchError} onClick={() => void create()}><Boxes size={17} />{busy && !trainingBusy ? `Creating ${created}/${total}…` : 'Create Browsers'}</button>{busy && !trainingBusy && <button className="aj-button" onClick={() => { cancelBatch.current = true; }}>Cancel batch</button>}</section>{batchError && <p role="alert" className="aj-notice">{batchError}</p>}<p className="aj-footnote">{capacity.profilesPerBatch ? `Your batch setting: ${capacity.profilesPerBatch} profiles.` : 'No fixed profile batch cap. Enter a count above the slider range directly in its number field.'} Change capacity in Settings.</p>
  </div>;
}
export function SoloMode({ pods, profiles, refresh, notify, openDraft }: {
  pods: Pod[]; profiles: Profile[]; refresh: () => Promise<void>; notify: (s: string) => void; openDraft: (flow: Flow) => void;
}) {
  const [active, setActive] = useState(false); const [podId, setPodId] = useState(''); const [query, setQuery] = useState(''); const [device, setDevice] = useState(''); const [selected, setSelected] = useState<string[]>([]); const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState<Profile | null | undefined>(undefined);
  const recorder = useProfileRecorder(notify);
  const [notes, setNotes] = useStored<Record<string, ProfileNote>>('profile-notes', {});
  const [timezone, setTimezone] = useState(deviceTimezone);
  useEffect(() => { const update = () => setTimezone(deviceTimezone()); window.addEventListener('focus', update); const timer = window.setInterval(update, 60000); return () => { window.removeEventListener('focus', update); window.clearInterval(timer); }; }, []);
  const pod = pods.find(p => p.id === podId); const inGroup = profiles.filter(p => !pod || pod.profiles.includes(p.id));
  const filtered = inGroup.filter(p => p.running === active && (!device || profileDevice(p, pod ? [pod] : pods) === device) && `${p.name || ''} ${p.id} ${p.startUrl || ''} ${notes[p.id]?.tags || ''} ${notes[p.id]?.note || ''}`.toLowerCase().includes(query.toLowerCase()));
  const chosen = selected.filter(id => filtered.some(p => p.id === id));
  const operate = async (action: 'power' | 'delete') => {
    if (!chosen.length) return;
    if (action === 'delete' && recorder.recording?.status !== 'stopped' && recorder.recording && chosen.includes(recorder.recording.profile.id)) {
      notify('Stop the recording before deleting the selected profile.');
      return;
    }
    if (action === 'delete' && !window.confirm(`Permanently delete ${chosen.length} browser profiles and their local data?`)) return;
    setBusy(true);
    try { for (const id of chosen) {
      const profile = profiles.find(item => item.id === id)!;
      const group = pod || pods.find(item => item.profiles.includes(id));
      await invoke(action === 'delete' ? 'delete_browser_profile' : active ? 'close_browser_profile' : 'launch_browser_profile', {
        profileId: id, ...(!active && action === 'power' && group ? { deviceClass: profileDevice(profile, [group]), proxyId: group.proxyId || null } : {}),
      }); if (action === 'power' && !active) setNotes(n => ({ ...n, [id]: { tags: n[id]?.tags || '', note: n[id]?.note || '', lastUsed: Date.now() } })); } setSelected([]); notify(action === 'delete' ? 'Selected profiles deleted.' : 'Browser state updated.'); }
    catch(e) { notify(String(e)); } finally { await refresh(); setBusy(false); }
  };
  return <><PageHeading title="Solo Mode" description="Browse and manage a pod’s profiles directly, outside of any session."><div className="aj-inline"><button className="aj-button" disabled={busy} onClick={() => setEditing(null)}><Plus size={15} /> Create profile</button><div className="aj-segment">{['Inactive','Active'].map((s, i) => <button className={active === !!i ? 'selected' : ''} key={s} onClick={() => { setActive(!!i); setSelected([]); }}>{s}</button>)}</div></div></PageHeading>
    <div className="aj-grid three aj-solo-summary"><section className="aj-card"><small>TOTAL {active ? 'ACTIVE' : 'INACTIVE'} PROFILES</small><strong className="aj-big-number">{inGroup.filter(p => p.running === active).length}</strong><div className="aj-chips">{devices.map(d => <span className="aj-pill" key={d}>{d} {inGroup.filter(p => profileDevice(p, pod ? [pod] : pods) === d).length}</span>)}</div></section><section className="aj-card"><label>POD<select value={podId} onChange={e => { setPodId(e.target.value); setSelected([]); }}><option value="">All profiles</option>{pods.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label><p>{filtered.length} profiles match the current filter.</p></section><section className="aj-card"><label>PROXY LOCATION<select aria-label="Proxy location" value="default" onChange={() => setTimezone(deviceTimezone())}><option value="default">Default location</option></select></label><p className="aj-device-timezone">Device timezone: <strong>{timezone}</strong></p><small>Default follows this device. Network routing uses the pod proxy when set, otherwise the profile’s assigned proxy.</small></section></div>
    <section className="aj-card aj-solo-toolbar"><label className="aj-search"><Search size={14} /><input aria-label="Search Solo profiles" placeholder="Search by name, tag, note…" value={query} onChange={e => setQuery(e.target.value)} /></label><div className="aj-chips">{devices.map(d => <button key={d} className={`aj-pill ${device === d ? 'selected' : ''}`} onClick={() => setDevice(device === d ? '' : d)}>{d}</button>)}</div><span className="aj-spacer" /><small>{chosen.length} selected</small><button className="aj-button primary" disabled={!chosen.length || busy} onClick={() => void operate('power')}><Power size={14} /> {active ? 'Power down' : 'Power up'}</button><button className="aj-button" disabled={!chosen.length || active || busy} onClick={() => void operate('delete')}><Trash2 size={14} />Delete</button></section>
    <section className="aj-card aj-table-wrap">{filtered.length ? <table className="aj-table"><thead><tr><th><input type="checkbox" aria-label="Select all visible profiles" checked={!!filtered.length && chosen.length === filtered.length} onChange={e => setSelected(e.target.checked ? filtered.map(p => p.id) : [])} /></th><th>NAME</th><th>DEVICE LABEL</th><th>RUNTIME</th><th>TAGS &amp; DESCRIPTION</th><th>LAST USED</th><th>PROFILE TOOLS</th></tr></thead><tbody>{filtered.map(p => <tr key={p.id}><td><input aria-label={`Select ${p.name}`} type="checkbox" checked={chosen.includes(p.id)} onChange={e => setSelected(v => e.target.checked ? [...v, p.id] : v.filter(id => id !== p.id))} /></td><td><Monitor size={14} /> {p.name || p.id}{p.startUrl && <small className="aj-profile-site">{p.startUrl}</small>}</td><td>{profileDevice(p, pod ? [pod] : pods)}</td><td><span className={`aj-pill ${p.running ? 'success' : ''}`}>{p.running ? 'Running' : 'Desktop browser'}</span></td><td><input aria-label={`Tags for ${p.name}`} placeholder="+ tag" value={notes[p.id]?.tags || ''} onChange={e => setNotes(n => ({ ...n, [p.id]: { ...n[p.id], tags: e.target.value, note: n[p.id]?.note || '' } }))} /><input aria-label={`Note for ${p.name}`} placeholder="Add description/note…" value={notes[p.id]?.note || ''} onChange={e => setNotes(n => ({ ...n, [p.id]: { ...n[p.id], tags: n[p.id]?.tags || '', note: e.target.value } }))} /></td><td>{notes[p.id]?.lastUsed ? new Date(notes[p.id].lastUsed!).toLocaleDateString() : '—'}</td><td><div className="aj-inline">
      {p.running ? <button className="aj-button small" disabled={!desktop || recorder.busy || !!recorder.recording && recorder.recording.status !== 'stopped'} onClick={() => void recorder.start(p)}>Record</button>
        : <><button className="aj-button small" disabled={busy} onClick={() => setEditing(p)}><Pencil size={14} /> Edit</button><ProfileBackupButton profile={p} notify={notify} /></>}
    </div></td></tr>)}</tbody></table> : <Empty icon={<Monitor size={26} />} title="No profiles match" description="Create a pod, change the filters, or add profiles with the existing browser tools." />}</section>
    <RecorderPanel recorder={recorder} onDraft={openDraft} notify={notify} />
    {editing !== undefined && <ProfileEditor profile={editing} onClose={() => setEditing(undefined)} onSaved={refresh} />}

  </>;
}

type GroupRun = {
  session: Session;
  stop: boolean;
  paused: boolean;
  profiles: Set<string>;
  waiters: Set<() => void>;
};

export function Sessions({ capacity, sessions, setSessions, pods, profiles, workflows, refresh, notify, podRequest }: {
  capacity: CapacitySettings; sessions: Session[]; setSessions: (s: Session[]) => void; pods: Pod[]; profiles: Profile[];
  workflows: Flow[]; refresh: () => Promise<void>; notify: (s: string) => void; podRequest: PodRunRequest | null;
}) {
  const [editError, setEditError] = useState('');
  const [editing, setEditing] = useState<Session | null>(null); const [review, setReview] = useState<Session | null>(null); const [proxies, setProxies] = useState<{ id: string; name: string }[]>([]);
  const [states, setStates] = useState<Record<string, { status: string; detail: string }>>({});
  const running = useRef<Record<string, GroupRun>>({});
  const reservedProfiles = useRef(new Set<string>());
  useEffect(() => { invoke<{ id: string; name: string }[]>('list_proxies').then(setProxies).catch(e => notify(String(e))); }, [profiles]);
  const fresh = (): Session => ({ id: uid('session'), name: 'Untitled session', type: 'Custom', podId: pods[0]?.id || '', workflowId: pods[0]?.workflowId ? '' : workflows[0]?.id || '', proxyId: '', provider: 'ollama', model: 'qwen2.5:7b', incognito: false, vision: false, deviceRanges: {}, createdAt: Date.now() });
  const setStatus = (id: string, status: string, detail: string) => setStates(s => ({ ...s, [id]: { status, detail } }));
  const podSessions: Session[] = pods.filter(pod => pod.workflowId).map(pod => ({
    id: `pod-run-${pod.id}`, name: pod.name, type: 'Custom', podId: pod.id, workflowId: pod.workflowId || '', proxyId: pod.proxyId || '',
    provider: 'ollama', model: 'qwen2.5:7b', incognito: false, vision: false,
  }));
  for (const { session } of Object.values(running.current)) {
    if (session.id.startsWith('pod-run-') && !podSessions.some(item => item.id === session.id)) podSessions.push(session);
  }
  useEffect(() => {
    if (!podRequest) return;
    const selected = podSessions.find(session => session.podId === podRequest.podId);
    if (selected && !running.current[selected.id]) setReview(selected);
  }, [podRequest]);
  const bound = (session: Session): Session => {
    const pod = pods.find(item => item.id === session.podId);
    return { ...session, workflowId: session.workflowId || pod?.workflowId || '', proxyId: session.proxyId || pod?.proxyId || '' };
  };
  const command = async (profileId: string, action: 'pauseWorkflow' | 'resumeWorkflow' | 'stopWorkflow') => {
    try { await invoke('control_browser_workflow', { action, profileId }); }
    catch (error) {
      if (!String(error).includes('No active workflow run exists')) notify(String(error));
    }
  };
  useEffect(() => {
    let disposed = false;
    let unlisten: (() => void) | undefined;
    void listen<{ type: string; run?: { profileId: string } }>('workflow-progress', ({ payload }) => {
      const id = payload.run?.profileId;
      if (payload.type !== 'run_started' || !id) return;
      const group = Object.values(running.current).find(run => run.profiles.has(id));
      if (group?.stop || group?.paused) void command(id, group.stop ? 'stopWorkflow' : 'pauseWorkflow');
    }).then(off => { if (disposed) off(); else unlisten = off; });
    return () => { disposed = true; unlisten?.(); };
  }, [notify]);

  const start = async (session: Session) => {
    setReview(null);
    if (!desktop) return notify('Run sessions in the desktop app. Browser preview supports local configuration only.');
    if (running.current[session.id]) return;
    if (sessionCapacityReached(Object.keys(running.current).length, capacity.concurrentSessions)) return notify(`Your setting allows ${capacity.concurrentSessions} concurrent sessions. Stop one or adjust Workspace capacity in Settings.`);
    const pod = pods.find(p => p.id === session.podId); const flow = workflows.find(w => w.id === session.workflowId);
    let waves: Profile[][];
    try { waves = pod ? sessionWaves(session, pod, profiles) : []; } catch (error) { return notify(String(error)); }
    const members = waves.flat();
    if (!flow) return notify('Choose an available saved workflow.');
    if (!members.length) return notify('No profiles match this pod and its device ranges. Check the pod and device maxima.');
    if (members.some(p => reservedProfiles.current.has(p.id))) return notify('A selected pod profile is already used by another session.');
    members.forEach(p => reservedProfiles.current.add(p.id));
    const run: GroupRun = { session, stop: false, paused: false, profiles: new Set(), waiters: new Set() };
    running.current[session.id] = run;
    const waitForResume = async () => {
      while (run.paused && !run.stop) await new Promise<void>(resolve => run.waiters.add(resolve));
    };
    setStatus(session.id, 'Running', 'Preparing browser profiles…');
    try {
      const runMember = async (member: Profile) => {
        await waitForResume();
        if (run.stop) return;
        let id = member.id;
        let temporary = false;
        let launched = false;
        const deviceClass = profileDevice(member, [pod!]);
        try {
          if (session.incognito) {
            id = uid('ephemeral');
            await invoke('create_browser_profile', { profileId: id, name: `${session.name} · temporary`, startUrl: member.startUrl || 'https://example.com', deviceClass });
            temporary = true;
          }
          if (session.proxyId && member.running && !temporary) throw new Error('Stop the selected profile before applying a session proxy.');
          if (temporary || !member.running) {
            await invoke('launch_browser_profile', { profileId: id, deviceClass, proxyId: session.proxyId || null });
            launched = true;
          }
          await waitForResume();
          if (run.stop) return;
          run.profiles.add(id);
          setStatus(session.id, 'Running', `${member.name || member.id} · ${members.indexOf(member) + 1}/${members.length}`);
          const result = await invoke<{ ok?: boolean; status?: string; results?: { ok?: boolean; detail?: string }[]; message?: string }>('run_browser_workflow', { workflowId: flow.id, profileId: id, approveConsequential: false });
          if (result.ok === false && !run.stop) throw new Error(result.message || 'Workflow did not complete. Review Run history.');
          const failure = result.results?.find(s => s.ok === false);
          if (failure && !run.stop) throw new Error(failure.detail || 'Workflow stopped. Open the advanced editor to review approval requirements.');
        } finally {
          run.profiles.delete(id);
          const errors: string[] = [];
          const cleanup = async (command: string, args: Record<string, unknown>) => { try { await invoke(command, args); } catch(e) { errors.push(String(e)); } };
          if (launched) await cleanup('close_browser_profile', { profileId: id });
          if (temporary) await cleanup('delete_browser_profile', { profileId: id });
          if (errors.length) throw new Error(`Browser cleanup needs attention: ${errors.join('; ')}`);
        }
      };
      for (const wave of waves) {
        await waitForResume();
        if (run.stop) break;
        const results = await Promise.allSettled(wave.map(runMember));
        const failure = results.find((result): result is PromiseRejectedResult => result.status === 'rejected');
        if (failure) throw failure.reason;
      }
      setStatus(session.id, run.stop ? 'Stopped' : 'Completed', run.stop ? 'Session stopped.' : 'All profiles finished.');
    } catch(e) { setStatus(session.id, 'Failed', String(e)); notify(String(e)); }
    finally { delete running.current[session.id]; members.forEach(p => reservedProfiles.current.delete(p.id)); await refresh(); }
  };
  const control = async (id: string, action: 'pause' | 'resume' | 'stop') => {
    const run = running.current[id];
    if (!run || run.stop) return;
    run.stop = action === 'stop';
    run.paused = action === 'pause';
    const nativeAction = action === 'pause' ? 'pauseWorkflow' : action === 'resume' ? 'resumeWorkflow' : 'stopWorkflow';
    setStatus(id, action === 'pause' ? 'Paused' : action === 'resume' ? 'Running' : 'Stopping',
      action === 'pause' ? 'Pausing at browser action boundaries. New profiles wait for resume.' :
        action === 'resume' ? 'Resuming the session…' : 'Stopping after the current browser action…');
    const controls = [...run.profiles].map(profileId => command(profileId, nativeAction));
    if (!run.paused) { run.waiters.forEach(resolve => resolve()); run.waiters.clear(); }
    await Promise.all(controls);
  };
  return <><PageHeading title="Sessions" description="Configure, manage and run sessions. Each binds a pod, proxy, saved workflow and planner preference."><button className="aj-button primary" onClick={() => { setEditError(''); setEditing(fresh()); }}><Plus size={16} /> New Session</button></PageHeading>
    <div className="aj-banner"><Zap size={23} /><p><strong>LOCAL SESSION EXECUTION</strong><br />{capacity.concurrentSessions ? `Your setting: ${capacity.concurrentSessions} concurrent sessions.` : 'No fixed concurrent session cap.'} Profiles follow the session’s device ranges; blank ranges run sequentially. Adjust capacity in Settings.</p></div>
    <div className="aj-grid two aj-session-grid">{[...sessions, ...podSessions].map(s => <article className="aj-card aj-session-card" key={s.id}><div className="aj-session-body"><div className="aj-card-title"><span className={`aj-feature-icon ${s.type === 'Warmer' ? 'orange' : 'violet'}`}>{s.type === 'Warmer' ? <Flame size={22} /> : <Workflow size={22} />}</span><div><h3>{s.name}</h3><span className="aj-pill">{s.type}</span><small> {pods.find(p => p.id === s.podId)?.name || 'Pod unavailable'}</small></div><span className={`aj-pill ${states[s.id]?.status === 'Running' ? 'success' : ''}`}>{states[s.id]?.status || 'Idle'}</span></div><div className="aj-session-meta"><small>{providers.find(p => p.id === s.provider)?.name || 'Ollama'}</small><small><i className="aj-dot" /> Browser</small></div><p className="aj-session-detail">{states[s.id]?.detail || workflows.find(w => w.id === bound(s).workflowId)?.name || 'Select a saved workflow'}</p></div><footer><button className="aj-button primary" onClick={() => running.current[s.id] ? void control(s.id, 'stop') : setReview(bound(s))}>{running.current[s.id] ? <Square size={15} /> : <Play size={15} />}{running.current[s.id] ? 'Stop' : 'Start'}</button>{running.current[s.id] && <button className="aj-button" disabled={running.current[s.id].stop} onClick={() => void control(s.id, running.current[s.id].paused ? 'resume' : 'pause')}>{running.current[s.id].paused ? <Play size={15} /> : <Pause size={15} />}{running.current[s.id].paused ? 'Resume' : 'Pause'}</button>}{!s.id.startsWith('pod-run-') && <><button className="aj-button" aria-label={`Edit ${s.name}`} disabled={!!running.current[s.id]} onClick={() => { setEditError(''); setEditing(s); }}><Pencil size={16} /></button><button className="aj-button" aria-label={`Delete ${s.name}`} disabled={!!running.current[s.id]} onClick={() => { if (window.confirm(`Delete session “${s.name}”? Profiles and workflows will remain.`)) setSessions(sessions.filter(x => x.id !== s.id)); }}><Trash2 size={16} /></button></>}</footer></article>)}</div>
    {!sessions.length && !podSessions.length && <section className="aj-card"><Empty icon={<Activity size={28} />} title="Create your first session" description="Create a pod and save a workflow, then bind them together in a session." /></section>}
    {editing && <div className="aj-modal-backdrop"><form className="aj-modal" role="dialog" aria-modal="true" aria-labelledby="session-title" onSubmit={e => { e.preventDefault(); try { validateDeviceRanges(editing.deviceRanges); } catch (error) { setEditError(String(error)); return; } setSessions([...sessions.filter(s => s.id !== editing.id), editing]); sessionStorage.setItem("ajbot-planner-preference", JSON.stringify({ provider: editing.provider, model: editing.model })); setEditing(null); }}><header><h2 id="session-title">{sessions.some(s => s.id === editing.id) ? 'Edit Session' : 'New Session'}</h2><button type="button" className="aj-modal-close" aria-label="Close session" onClick={() => setEditing(null)}>×</button></header><div className="aj-grid two"><label>Name<input required maxLength={100} value={editing.name} onChange={e => setEditing({ ...editing, name: e.target.value })} /></label><label>Type<select value={editing.type} onChange={e => setEditing({ ...editing, type: e.target.value })}><option>Warmer</option><option>Swarmer</option><option>Custom</option></select></label><label>Pod<select aria-label="Session pod" required value={editing.podId} onChange={e => setEditing({ ...editing, podId: e.target.value })}><option value="">Choose a pod</option>{pods.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label><label>Proxy<select value={editing.proxyId} onChange={e => setEditing({ ...editing, proxyId: e.target.value })}><option value="">Use pod or profile proxy</option>{proxies.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label></div><label>Saved workflow<select required={!pods.find(pod => pod.id === editing.podId)?.workflowId} value={editing.workflowId} onChange={e => setEditing({ ...editing, workflowId: e.target.value })}><option value="">Use pod workflow</option>{workflows.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}</select></label><section className="aj-card"><h3>AI Provider &amp; Model</h3><ProviderModelFields provider={editing.provider} model={editing.model} onProvider={provider => setEditing(current => current && ({ ...current, provider }))} onModel={model => setEditing(current => current && ({ ...current, model }))} /><small>Planning preference. This session executes its reviewed saved steps; generate new AI steps in Custom → Build with AI.</small></section><section className="aj-card aj-session-devices"><h3>Device range (min / max active)</h3><p>Blank ranges keep sequential execution. With ranges, minimum checks availability at start and maximum controls concurrent profiles per device. Set max to 0 to exclude a category.</p><div className="aj-grid two">{deviceLabels.map(device => <div className="aj-device-range" key={device}><strong>{device}</strong><label>Min<input aria-label={`${device} minimum active`} type="number" min="0" step="1" placeholder="min" value={editing.deviceRanges?.[device]?.min ?? ''} onChange={e => setEditing({ ...editing, deviceRanges: { ...editing.deviceRanges, [device]: { min: e.target.value === '' ? null : Number(e.target.value), max: editing.deviceRanges?.[device]?.max ?? null } } })} /></label><label>Max<input aria-label={`${device} maximum active`} type="number" min="0" step="1" placeholder="max" value={editing.deviceRanges?.[device]?.max ?? ''} onChange={e => setEditing({ ...editing, deviceRanges: { ...editing.deviceRanges, [device]: { min: editing.deviceRanges?.[device]?.min ?? null, max: e.target.value === '' ? null : Number(e.target.value) } } })} /></label></div>)}</div></section><section className="aj-card aj-toggle-row"><div><h3>Incognito mode</h3><p>Run in new temporary profiles; delete them after execution. Original profile cookies are not copied.</p></div><input aria-label="Incognito mode" role="switch" type="checkbox" checked={editing.incognito} onChange={e => setEditing({ ...editing, incognito: e.target.checked })} /></section><section className="aj-card"><h3>Vision mode</h3><p>Page screenshots are supported in saved workflows. Automated vision control and CAPTCHA solving are not included; security challenges require manual review.</p></section><section className="aj-card"><h3>Runs round the clock</h3><p>Use Scheduler to create daily or weekly runs for a saved workflow and profile.</p></section>{editError && <p className="aj-notice" role="alert">{editError}</p>}<footer className="aj-modal-footer"><button type="button" className="aj-button" onClick={() => setEditing(null)}>Cancel</button><button className="aj-button primary" type="submit">Save Session</button></footer></form></div>}
    {review && <div className="aj-modal-backdrop"><section className="aj-modal" role="dialog" aria-modal="true" aria-labelledby="review-title"><h2 id="review-title">Review session: {review.name}</h2><p>{pods.find(p => p.id === review.podId)?.name} · {workflows.find(w => w.id === review.workflowId)?.name}</p><p>This runs the following saved actions on each profile in the pod{review.incognito ? ', using temporary browser data' : ''}.</p><ol className="aj-step-review">{workflows.find(w => w.id === review.workflowId)?.steps.map((s,i) => <li key={i}><strong>{s.action}{Number(s.repeatCount) > 1 ? ` ×${s.repeatCount}` : ''}</strong> {s.url || s.selector || s.value || ''}</li>)}</ol><p>Consequential actions stop at the existing approval gate. Use the advanced editor to approve and run those actions individually.</p><div className="aj-modal-footer"><button className="aj-button" onClick={() => setReview(null)}>Cancel</button><button className="aj-button primary" onClick={() => void start(review)}><Play size={15} /> Confirm &amp; run</button></div></section></div>}
  </>;
}
