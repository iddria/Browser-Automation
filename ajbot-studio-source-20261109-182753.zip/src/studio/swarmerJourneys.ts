import { type Journey, type Step, uid } from './model.ts';

export function buildSwarmerJourneys(pages: string[], maxWorkflows: number, minTasks: number): Journey[] {
  const [target] = pages;
  if (!target) return [];

  const inventory: Step = { action: 'extractLinks', selector: 'a[href]' };
  const screenshot: Step = { action: 'screenshot', fullPage: true };
  if (pages.length === 1) {
    return [{
      id: uid('journey'), name: 'Single-page inspection', startUrl: target, verifyStartHtml: true,
      steps: [inventory, screenshot],
    }];
  }

  const path = (url: string) => new URL(url).pathname;
  const journeys: Journey[] = [];
  for (let offset = 1; offset < pages.length && journeys.length < maxWorkflows; offset++) {
    for (const [index, startUrl] of pages.entries()) {
      const destination = pages[(index + offset) % pages.length];
      const nearby = [...pages.slice(index + 1), ...pages.slice(0, index)];
      const via = nearby.filter(page => page !== destination).slice(0, minTasks - 4);
      const visits: Step[] = [...via, destination].map(url => ({ action: 'navigate', url, verifyHtml: true }));
      // For small sites, use distinct checks at the entry page in place of extra visits.
      const entryChecks = [inventory, screenshot].slice(0, minTasks - visits.length - 3);
      journeys.push({
        id: uid('journey'), name: `${path(startUrl)} → ${path(destination)}`, startUrl, verifyStartHtml: true,
        steps: [...entryChecks, ...visits, inventory, screenshot],
      });
      if (journeys.length === maxWorkflows) break;
    }
  }
  return journeys;
}
