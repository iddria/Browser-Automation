import zones from './timezoneCountries.json' with { type: 'json' };
export function countryHint(timezone:string,languages:readonly string[]=[]){
 const zoned=(zones as Record<string,string>)[timezone];if(zoned)return zoned;
 for(const language of languages){try{const region=new Intl.Locale(language).region;if(region&&/^[A-Z]{2}$/.test(region))return region;}catch{}}
 return '';
}
