import { useState } from 'react';
import { Flame, FolderOpen, Plus, RefreshCw, Search, Store, Trash2, Waves } from 'lucide-react';
import { Empty, PageHeading } from './AccountPages';
import { desktop, invoke } from './bridge';
import { type Flow, type Journey, type CanvasDraft, type Step, MAX_WORKFLOW_STEPS, libraryTopics, uid, useStored, validUrl, validateCanvas, normalizeStepActions } from './model';
import { buildSwarmerJourneys } from './swarmerJourneys';
import ProviderModelFields from './ProviderModelFields';
import { defaultModel } from './providerCatalog';
export const warmerPlatforms = ['Google','YouTube','Facebook','Instagram','TikTok','Amazon'];
export function rememberJourneys(id: string, journeys: Journey[], steps: Flow['steps']) {
  const all=JSON.parse(localStorage.getItem('ajbot-studio-journey-library') || '{}');
  all[id]={journeys,signature:JSON.stringify(steps)};
  localStorage.setItem('ajbot-studio-journey-library',JSON.stringify(all));
}
export function flowDraft(flow: Flow): CanvasDraft {
  const steps=normalizeStepActions(flow.steps);
  let journeys: Journey[]=[];
  try { const entry=JSON.parse(localStorage.getItem('ajbot-studio-journey-library') || '{}')[flow.id]; if(entry?.signature===JSON.stringify(flow.steps)) journeys=entry.journeys; } catch { /* recover from the native definition */ }
  if (!journeys.length) {
    for(const s of steps) {
      if (s.action === 'navigate' && (!journeys.length || s.journeyStart)) {
        journeys.push({
          id: uid('journey'),
          name: typeof s.journeyName === 'string' && s.journeyName ? s.journeyName : `Journey ${journeys.length + 1}`,
          startUrl: s.url || '',
          verifyStartHtml: s.verifyHtml === true,
          scopeOrigin: typeof s.scopeOrigin === 'string' ? s.scopeOrigin : undefined,
          steps: [],
        });
      }
      else { if(!journeys.length) journeys.push({id:uid('journey'),name:'Journey 1',startUrl:'',steps:[]}); journeys[journeys.length-1].steps.push(s); }
    }
  }
  return {id:flow.id,name:flow.name,active:journeys[0]?.id || '',journeys};
}
type Props={workflows:Flow[]; saved:()=>void; notify:(s:string)=>void; openFlow:(w:Flow)=>void};
export function Warmers({workflows,saved,notify,openFlow}:Props) {
  const [tab,setTab]=useState('Store'); const [search,setSearch]=useState(''); const [platform,setPlatform]=useState('All'); const [busy,setBusy]=useState('');
  const [installed,setInstalled]=useStored<Record<string,string>>('installed-warmers',{});
  const templates=warmerPlatforms.flatMap(platform=>libraryTopics.map(topic=>({name:`${topic} · ${platform}`,platform,slug:`${platform.toLowerCase()}-${topic.toLowerCase().replace(/ /g,'-')}-warmer`})));
  const owned=workflows.filter(w=>Object.values(installed).includes(w.id) || templates.some(t=>w.name===t.name));
  const install=async(t:typeof templates[number])=>{setBusy(t.slug);try {
    // Inspection-only draft. The owner sets an authorized target before running.
    const journeys:Journey[]=[{id:uid('journey'),name:`${t.name} inspection`,startUrl:'https://example.com',steps:[{action:'extractText',selector:'body'},{action:'extractLinks',selector:'a'},{action:'screenshot',fullPage:true}]}];
    const steps=validateCanvas(journeys); const id=uid('warmer'); const flow=await invoke<Flow>('save_browser_workflow',{workflowId:id,name:t.name,steps});
    rememberJourneys(flow.id,journeys,flow.steps);setInstalled(v=>({...v,[t.slug]:flow.id}));saved();notify(`${t.name} installed as an editable inspection workflow. Set your authorized target in Custom.`);
  }catch(e){notify(String(e));}finally{setBusy('');}};
  const remove=async(w:Flow)=>{if(!window.confirm(`Remove ${w.name}? Sessions that use it will need another workflow.`))return;setBusy(w.id);try{await invoke('delete_browser_workflow',{workflowId:w.id});setInstalled(v=>Object.fromEntries(Object.entries(v).filter(([,id])=>id!==w.id)));saved();}catch(e){notify(String(e));}finally{setBusy('');}};
  return <><PageHeading title="Warmers" description="Install reusable inspection workflows. Installed warmers appear in your sessions."><div className="aj-segment" role="tablist" aria-label="Warmers library">{['Store','My Warmers'].map(t=><button role="tab" aria-selected={tab===t} className={tab===t?'selected':''} key={t} onClick={()=>setTab(t)}>{t==='Store'?<Store size={14}/>:<Flame size={14}/>} {t}{t==='My Warmers'?` (${owned.length})`:''}</button>)}</div></PageHeading>
    <div className="aj-library-toolbar"><label className="aj-search"><Search size={16}/><input aria-label="Search Warmers" placeholder="Search warmers…" value={search} onChange={e=>setSearch(e.target.value)}/></label><div className="aj-chips">{['All',...warmerPlatforms].map(p=><button key={p} className={`aj-pill ${platform===p?'selected':''}`} onClick={()=>setPlatform(p)}>{p}</button>)}</div></div>
    {tab==='Store'?<div className="aj-grid three aj-template-library">{templates.filter(t=>t.name.toLowerCase().includes(search.toLowerCase())&&(platform==='All'||t.platform===platform)).map(t=>{const flow=owned.find(w=>w.id===installed[t.slug]||w.name===t.name);return <article className="aj-card" key={t.slug}><small className="aj-google">{t.platform}</small><h3>{t.name}</h3><p>Inspect page content, links and screenshots on an authorized test target. Edit this draft in Custom before running.</p><small>{t.slug}</small><button className="aj-button primary" disabled={!!busy} onClick={()=>flow?openFlow(flow):void install(t)}>{flow?<FolderOpen size={14}/>:<Plus size={14}/>} {busy===t.slug?'Installing…':flow?'Open installed':'Install'}</button></article>})}</div>:<div className="aj-grid three aj-installed-library">{owned.filter(w=>w.name.toLowerCase().includes(search.toLowerCase())&&(platform==='All'||w.name.endsWith(` · ${platform}`))).map(w=><article className="aj-card aj-installed-warmer" key={w.id}><button className="aj-flow-link" onClick={()=>openFlow(w)}><strong>{w.name}</strong><small>{w.id}</small></button><button className="aj-button small" disabled={!!busy} aria-label={`Remove ${w.name}`} onClick={()=>void remove(w)}><Trash2 size={16}/></button></article>)}</div>}
    {tab==='My Warmers'&&!owned.length&&<Empty icon={<Flame size={25}/>} title="No installed warmers" description="Install a draft from the Store to see it here."/>}<p className="aj-footnote">Inspection templates do not create browsing histories to impersonate people or generate views and engagement.</p>
  </>;
}
type GuidedPlan = {
  journeys: Omit<Journey, 'id'>[];
  blocked: { goal: number; reason: string }[];
};

function describeSwarmerStep(step: Step) {
  switch (step.action) {
    case 'navigate': return `Open page directly · ${step.url}`;
    case 'click': return `Click link “${step.targetLabel}”${step.expectedUrl ? ` · ${step.expectedUrl}` : ''}`;
    case 'fill': return `Enter “${step.value}” in “${step.targetLabel}”`;
    case 'press': return `Press Enter in “${step.targetLabel}” to search`;
    case 'scroll': return step.targetLabel ? `Scroll to “${step.targetLabel}”` : `Scroll ${step.direction}`;
    case 'waitForURL': return `Verify page · ${step.value}`;
    case 'waitForText': return `Check for visible text “${step.value}”`;
    case 'back': return 'Go back to the previous page';
    case 'extractLinks': return 'List links on this page';
    case 'screenshot': return step.fullPage ? 'Capture a full-page screenshot' : 'Capture a screenshot of the current view';
    default: return step.action;
  }
}

export function Swarmers({workflows,saved,notify,openFlow}:Props) {
  const [url, setUrl] = useState('');
  const [mode, setMode] = useState<'inspect' | 'goals'>('inspect');
  const [goals, setGoals] = useState('');
  const [provider, setProvider] = useStored('swarmer-provider', 'ollama');
  const [model, setModel] = useStored('swarmer-model', '');
  const [count, setCount] = useState(3);
  const [tasks, setTasks] = useState(6);
  const [working, setWorking] = useState<'generate' | 'save' | null>(null);
  const [preview, setPreview] = useState<{ target: string; pageCount?: number; journeys: Journey[]; blocked?: GuidedPlan['blocked'] } | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const guided = mode === 'goals';

  const generate = async () => {
    setWorking('generate');
    setPreview(null);
    setSelected([]);
    try {
      const target = new URL(validUrl(url.trim()));
      let journeys: Journey[];
      if (guided) {
        const plan = await invoke<GuidedPlan>('plan_browser_workflow', {
          startUrl: target.href, task: goals.trim(), provider, model: model.trim() || defaultModel(provider),
          apiKey: null, profileId: null,
        });
        journeys = plan.journeys.map(journey => ({
          ...journey, id: uid('journey'), steps: normalizeStepActions(journey.steps),
        }));
        setPreview({ target: target.href, journeys, blocked: plan.blocked });
        notify(journeys.length ? `${journeys.length} guided ${journeys.length === 1 ? 'journey' : 'journeys'} ready to review.` : 'No journeys could be built. Review the details below.');
      } else {
        target.hash = '';
        const pages = desktop ? await invoke<string[]>('discover_site_pages', { url: target.href }) : [target.href];
        journeys = buildSwarmerJourneys(pages, count, tasks);
        if (!journeys.length) throw new Error('No HTML pages were found.');
        setPreview({ target: pages[0], pageCount: pages.length, journeys });
        const found = desktop ? `${pages.length} ${pages.length === 1 ? 'page' : 'pages'} found` : 'Browser preview';
        notify(`${found} · ${journeys.length} inspection ${journeys.length === 1 ? 'journey' : 'journeys'} generated.`);
      }
      let remaining = MAX_WORKFLOW_STEPS;
      setSelected(journeys.flatMap(journey => {
        const size = journey.steps.length + 1;
        if (size > remaining) return [];
        remaining -= size;
        return [journey.id];
      }));
    } catch (e) {
      notify(String(e));
    } finally {
      setWorking(null);
    }
  };

  const chosen = preview?.journeys.filter(j => selected.includes(j.id)) ?? [];
  const total = chosen.reduce((sum, journey) => sum + journey.steps.length + 1, 0);
  const save = async () => {
    if (!preview || !chosen.length) return;
    setWorking('save');
    try {
      const steps = validateCanvas(chosen);
      const name = `Swarmer · ${new URL(preview.target).hostname}`;
      await invoke<Flow>('save_browser_workflow', { workflowId: uid('swarmer'), name, steps });
      saved();
      notify(`${chosen.length} ${guided ? 'guided' : 'inspection'} ${chosen.length === 1 ? 'journey' : 'journeys'} saved as one swarm. Open it in Custom to review.`);
      setPreview(null);
      setSelected([]);
    } catch (e) {
      notify(String(e));
    } finally {
      setWorking(null);
    }
  };

  return <>
    <PageHeading title="Swarmers" description="Build and review browser journeys for a website you are authorized to test."/>
    <section className="aj-card">
      <div className="aj-segment" role="group" aria-label="Journey builder">
        <button type="button" className={!guided ? 'selected' : ''} aria-pressed={!guided} disabled={!!working} onClick={() => { setMode('inspect'); setPreview(null); }}>Page inspection</button>
        <button type="button" className={guided ? 'selected' : ''} aria-pressed={guided} disabled={!!working} onClick={() => { setMode('goals'); setPreview(null); }}>Build from goals</button>
      </div>
      <label>Target website
        <div className="aj-inline">
          <input value={url} placeholder="https://example.com" disabled={!!working} onChange={e => { setUrl(e.target.value); setPreview(null); }}/>
          <button className="aj-button primary" disabled={!!working || !url.trim() || guided && (!desktop || !goals.trim())} onClick={() => void generate()}>
            {working === 'generate' ? guided ? 'Inspecting and planning…' : 'Discovering…' : guided ? 'Build journeys' : 'Generate'}
          </button>
        </div>
      </label>
      {guided ? <>
        <label>Journey goals
          <textarea rows={4} maxLength={3000} value={goals} disabled={!!working}
            placeholder="Click Demo, verify that the demo page opens, go back, scroll to Pricing, and take a screenshot."
            onChange={e => { setGoals(e.target.value); setPreview(null); }}/>
        </label>
        <p>Enter one journey per line, up to five. Include the exact sample text or search phrase. The selected model receives your goals and the public page controls found on the site.</p>
        {!desktop ? <p>Open the desktop app to inspect the website and build guided journeys.</p> :
          <div inert={!!working}><ProviderModelFields provider={provider} model={model}
            onProvider={value => { setProvider(value); setPreview(null); }}
            onModel={value => { setModel(value); setPreview(null); }}/></div>}
      </> : <>
      <div className="aj-grid two">
        <label>Max workflows <span>{count}</span>
          <input type="range" min="1" max="24" value={count} disabled={!!working} onChange={e => { setCount(Number(e.target.value)); setPreview(null); }}/>
        </label>
        <label>Min tasks each <span>{tasks}</span>
          <input type="range" min="4" max="6" value={tasks} disabled={!!working} onChange={e => { setTasks(Number(e.target.value)); setPreview(null); }}/>
        </label>
      </div>
      <p>Target and inner-page entries · Direct page visits · Link inventories · Screenshots</p>
      </>}
    </section>
    {preview && <>
      <div className="aj-inline aj-swarm-summary">
        <span>{guided ? 'Review guided steps' : desktop ? `${preview.pageCount} HTML ${preview.pageCount === 1 ? 'page' : 'pages'} found` : 'Browser preview'} · {preview.journeys.length} {preview.journeys.length === 1 ? 'journey' : 'journeys'} generated</span>
        <span className="aj-spacer"/>
        <small>{chosen.length} selected · {total}/{MAX_WORKFLOW_STEPS} steps</small>
        <button className="aj-button primary" disabled={!chosen.length || !!working || total > MAX_WORKFLOW_STEPS} onClick={() => void save()}>
          {working === 'save' ? 'Saving…' : 'Save as one swarm'}
        </button>
      </div>
      {!desktop && <p>Open AJBOT STUDIO desktop to discover and verify pages. This draft uses the supplied URL.</p>}
      {desktop && preview.pageCount === 1 && <p>Only one HTML page was verified. The journey has three tasks. Multi-page journeys need another page.</p>}
      {preview.blocked?.map(item => <p role="alert" key={item.goal}>Goal {item.goal} needs more detail · {item.reason}</p>)}
      {total > MAX_WORKFLOW_STEPS && <p role="alert">Select fewer journeys. Each saved swarm supports up to {MAX_WORKFLOW_STEPS} steps.</p>}
      <div className="aj-grid two">
        {preview.journeys.map(j => {
          const visits = j.steps.filter(s => s.action === 'navigate').length + 1;
          return <article className="aj-card" key={j.id}>
            <label className="aj-check">
              <input type="checkbox" disabled={!!working} checked={selected.includes(j.id)} onChange={() => setSelected(ids => ids.includes(j.id) ? ids.filter(id => id !== j.id) : [...ids, j.id])}/>
              <strong>{j.name}</strong>
            </label>
            <p>{!guided && `${visits} ${visits === 1 ? 'page visit' : 'page visits'} · `}{j.steps.length + 1} tasks</p>
            <ol className="aj-route-list">
              <li>{j.startUrl === preview.target ? 'Open target' : 'Open inner page'} · {j.startUrl}</li>
              {j.steps.map((s, index) => <li key={index}>{describeSwarmerStep(s)}</li>)}
            </ol>
          </article>;
        })}
      </div>
    </>}
    <section className="aj-card"><div className="aj-card-title"><h3>Saved workflows</h3><button className="aj-button small" onClick={saved}><RefreshCw size={14}/>Refresh</button></div>{workflows.filter(w=>w.name.startsWith('Swarmer ·')).map(w=><div className="aj-activity-row" key={w.id}><Waves size={18}/><strong>{w.name}</strong><small>{w.steps.length} steps</small><button className="aj-button small" onClick={()=>openFlow(w)}>Open</button><button className="aj-button small" aria-label={`Delete ${w.name}`} onClick={async()=>{if(!window.confirm(`Delete ${w.name}?`))return;try{await invoke('delete_browser_workflow',{workflowId:w.id});saved();}catch(e){notify(String(e));}}}><Trash2 size={14}/></button></div>)}{!workflows.some(w=>w.name.startsWith('Swarmer ·'))&&<Empty icon={<Waves size={25}/>} title="No saved swarmers"/>}</section></>;
}
