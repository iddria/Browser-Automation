import type { Pod, Profile, Session } from './model';
export const deviceLabels = ['iPhone', 'Android', 'Mac', 'Windows'] as const;
export type DeviceLabel = typeof deviceLabels[number];
export type DeviceRange = { min: number | null; max: number | null };
export type DeviceRanges = Partial<Record<DeviceLabel, DeviceRange>>;
export function profileDevice(profile: Profile, pods: Pod[]): DeviceLabel {
  const label = pods.find(pod => pod.devices[profile.id])?.devices[profile.id];
  if (deviceLabels.includes(label as DeviceLabel)) return label as DeviceLabel;
  if (profile.deviceClass && deviceLabels.includes(profile.deviceClass)) return profile.deviceClass;
  const name = profile.name?.toLowerCase() || '';
  if (name.includes('iphone')) return 'iPhone';
  if (name.includes('android')) return 'Android';
  if (name.includes('_mac-')) return 'Mac';
  return 'Windows';
}
export function validateDeviceRanges(ranges?: DeviceRanges): void {
  for (const device of deviceLabels) {
    const range = ranges?.[device]; if (!range) continue;
    for (const value of [range.min, range.max]) {
      if (value != null && (!Number.isSafeInteger(value) || value < 0)) throw new Error(`${device}: use whole numbers of 0 or more.`);
    }
    if ((range.min ?? 0) > (range.max ?? 1)) throw new Error(`${device}: minimum cannot exceed maximum. Blank maximum means 1.`);
  }
}
// With blank ranges preserve the existing one-profile-at-a-time behavior.
// Explicit maxima bound concurrent profiles per device in each finite execution wave.
export function sessionWaves(session: Session, pod: Pod, profiles: Profile[]): Profile[][] {
  const members = profiles.filter(p => pod.profiles.includes(p.id));
  validateDeviceRanges(session.deviceRanges);
  const explicit = deviceLabels.some(d => session.deviceRanges?.[d]?.min != null || session.deviceRanges?.[d]?.max != null);
  if (!explicit) return members.map(p => [p]);
  const queues = deviceLabels.map(device => {
    const range = session.deviceRanges?.[device];
    const list = members.filter(p => profileDevice(p, [pod]) === device);
    if ((range?.min ?? 0) > list.length) throw new Error(`${device}: minimum ${range!.min} requires more profiles in this pod (available: ${list.length}).`);
    return { list, max: range?.max ?? 1 };
  });
  const waves: Profile[][] = [];
  for (let offset = 0; ; offset++) {
    const wave = queues.flatMap(q => q.max > 0 ? q.list.slice(offset * q.max, (offset + 1) * q.max) : []);
    if (!wave.length) break;
    waves.push(wave);
  }
  return waves;
}
export function deviceTimezone(): string {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; }
}
