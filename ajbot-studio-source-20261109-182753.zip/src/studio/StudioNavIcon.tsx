// AJBOT's own orbit-and-node icon family. Each tool has a distinct central glyph.
const glyphs: Record<string,string>={
 'Overview':'M5 5h5v5H5z M14 5h5v5h-5z M5 14h5v5H5z M14 14h5v5h-5z',
 'Sessions':'M8 8a6 6 0 0 0 0 8 M16 8a6 6 0 0 1 0 8 M5 5a10 10 0 0 0 0 14 M19 5a10 10 0 0 1 0 14 M12 10v4',
 'Solo Mode':'M4 5h16v11H4z M9 20h6 M12 16v4 M10 9l5 2-5 3z',
 'Pods':'M12 3l5 3v6l-5 3-5-3V6z M7 12l-4 3v5h7v-4 M17 12l4 3v5h-7v-4',
 'Proxies':'M4 6h6 M14 18h6 M7 6v12h10V6 M14 6h6 M4 18h6',
 'Machines':'M3 4h12v10H3z M7 18h4 M9 14v4 M17 10h4v10h-4z',
 'Warmers':'M12 3c2 5-4 6-3 10 2-1 3-3 3-3 5 4 6 9 1 11-6 2-11-5-7-10-1 6 1 6 1 6-2-7 5-7 5-14z',
 'Swarmers':'M3 7q3-4 6 0t6 0 6 0 M3 12q3-4 6 0t6 0 6 0 M3 17q3-4 6 0t6 0 6 0',
 'Custom':'M3 3h6v6H3z M15 15h6v6h-6z M6 9v9h9 M15 6h6 M18 3v6',
 'QA workspace':'M5 4h14v16H5z M8 9l2 2 5-5 M8 15h8',
 'Store':'M4 9h16l-2-5H6z M5 9v11h14V9 M9 20v-6h6v6',
 'Earn Mode':'M12 4a8 8 0 1 0 8 8 M12 8v8 M15 9h-4a2 2 0 0 0 0 3h2a2 2 0 0 1 0 3H9 M16 3l5 5 M16 8l5-5',
 'Provider Keys':'M14 4a5 5 0 1 0 3 9l4 4-3 3-2-2-2 2-4-4 M14 7h.01',
 'Backup':'M4 6c0-4 16-4 16 0s-16 4-16 0v12c0 4 16 4 16 0V6 M4 12c0 3 9 4 12 2 M12 10v7 M9 14l3 3 3-3',
 'Handover':'M3 8l5-4 4 3 4-3 5 4-3 10-6 3-6-3z M8 10l4-3 5 5-4 5-5-5',
 'Settings':'M12 3v3 M12 18v3 M3 12h3 M18 12h3 M6 6l2 2 M16 16l2 2 M18 6l-2 2 M8 16l-2 2 M8 12a4 4 0 1 0 8 0 4 4 0 1 0-8 0',
 'Help & support':'M9 8a3 3 0 1 1 4 3c-1 0-1 2-1 3 M12 17h.01 M3 12a9 9 0 1 0 18 0 9 9 0 1 0-18 0',
};
export function StudioNavIcon({name}:{name:string}){return <svg className="aj-studio-icon" aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.45" strokeLinecap="round" strokeLinejoin="round"><path d={glyphs[name]||glyphs.Custom}/><circle className="aj-icon-signature" cx="21.5" cy="2.5" r="1.3" fill="currentColor" stroke="none"/></svg>;}
