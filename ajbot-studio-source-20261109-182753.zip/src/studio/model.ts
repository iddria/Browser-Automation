import type { DeviceLabel, DeviceRanges } from './sessionDevices';
import { useState } from 'react';
export type Profile = { id: string; name?: string; startUrl?: string | null; running: boolean; deviceClass?: DeviceLabel | null };
export type Step = { action: string; url?: string; selector?: string; value?: string; durationMs?: number; fullPage?: boolean; amount?: number; direction?: string; [key: string]: unknown };
export type Flow = { id: string; name: string; steps: Step[]; createdAt?: number; updatedAt?: string | number };
export type Pod = { id: string; name: string; profiles: string[]; devices: Record<string, string>; createdAt?: number; workflowId?: string; proxyId?: string };
export type Session = { id: string; name: string; type: string; podId: string; workflowId: string; proxyId: string; provider: string; model: string; incognito: boolean; vision: boolean; deviceRanges?: DeviceRanges; createdAt?: number };
export type ProfileNote = { tags: string; note: string; lastUsed?: number };
export type Journey = { id: string; name: string; startUrl: string; steps: Step[]; verifyStartHtml?: boolean; scopeOrigin?: string };
export type CanvasDraft = { id: string; name: string; active: string; journeys: Journey[] };
export const MAX_WORKFLOW_STEPS = 50;
export const devices = ['iPhone', 'Android', 'Mac', 'Windows'];
export const uid = (kind = 'item') => `${kind}-${crypto.randomUUID()}`;
export function useStored<T>(key: string, fallback: T) {
  const [value, update] = useState<T>(() => {
    try { const raw = localStorage.getItem('ajbot-studio-' + key); return raw ? JSON.parse(raw) : fallback; }
    catch { return fallback; }
  });
  const set = (next: T | ((old: T) => T)) => update(old => {
    const result = typeof next === 'function' ? (next as (old: T) => T)(old) : next;
    localStorage.setItem('ajbot-studio-' + key, JSON.stringify(result));
    return result;
  });
  return [value, set] as const;
}
export function downloadJson(filename: string, data: unknown) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function validUrl(value: string) {
  const url = new URL(/^[a-z][a-z0-9+.-]*:/i.test(value) ? value : `https://${value}`);
  if (!['http:', 'https:'].includes(url.protocol) || !url.hostname || url.username || url.password) throw new Error('Enter an HTTP or HTTPS website without embedded credentials.');
  return url.href;
}
export { providers } from './providerCatalog.ts';
export const libraryTopics = ['Investor', 'Scholarship', 'Forex', 'Music Lover', 'Shopper', 'Gamer', 'Fitness', 'Tech Enthusiast', 'Foodie', 'Traveler', 'Student', 'Entrepreneur'];
// These templates teach navigation and inspection. They never manufacture engagement.
export function learningTemplate(topic: string, platform: string): Omit<Flow, 'id'> {
  const url = platform === 'YouTube' ? 'https://www.youtube.com' : 'https://www.google.com';
  return { name: `${topic} · ${platform}`, steps: [{ action: 'navigate', url }, { action: 'wait', durationMs: 1200 }, { action: 'screenshot', fullPage: false }] };
}
export function validateCanvas(journeys: Journey[]) {
  const steps: Step[] = [];
  for (const j of journeys) {
    steps.push({
      action: 'navigate', url: validUrl(j.startUrl),
      journeyStart: true, journeyName: j.name,
      ...(j.verifyStartHtml ? { verifyHtml: true } : {}),
      ...(j.scopeOrigin ? { scopeOrigin: j.scopeOrigin } : {}),
    });
    for (const [i, s] of j.steps.entries()) {
      if (s.repeatCount != null && (typeof s.repeatCount !== 'number' || !Number.isInteger(s.repeatCount) || s.repeatCount < 1 || s.repeatCount > 10)) {
        throw new Error(`${j.name}, step ${i + 1}: choose a repeat count from 1 to 10.`);
      }
      if (s.action === 'fillAndEnter') {
        if (!s.selector?.trim() || !s.value?.trim()) throw new Error(`${j.name}, step ${i + 1}: enter a selector and text.`);
        steps.push({ action: 'fill', selector: s.selector, value: s.value }, { action: 'press', selector: s.selector, key: 'Enter' }); continue;
      }
      if (['navigate', 'newTab'].includes(s.action)) { steps.push({ ...s, url: validUrl(String(s.url || '')) }); continue; }
      if (['click','fill','hover','select','waitForSelector'].includes(s.action) && !s.selector?.trim()) throw new Error(`${j.name}, step ${i + 1}: enter a selector.`);
      if (['fill','select','clickText','waitForText'].includes(s.action) && !s.value?.trim()) throw new Error(`${j.name}, step ${i + 1}: enter text.`);
      if (s.action === 'wait' && (!Number.isFinite(s.durationMs) || Number(s.durationMs) < 0 || Number(s.durationMs) > 30000)) throw new Error('Wait must be 0–30000 milliseconds.');
      steps.push(s);
    }
  }
  if (steps.length > MAX_WORKFLOW_STEPS) throw new Error(`Maximum ${MAX_WORKFLOW_STEPS} steps across all journeys.`);
  return steps;
}

// Native worker files use lowercase action names; portable UI files use camelCase.
export function normalizeStepActions(steps: Step[]): Step[] {
  const names = ['newTab','closeTab','switchTab','clickText','clickRole','doubleClick','rightClick','fillLabel','waitForSelector','waitForText','waitForURL','extractText','extractLinks','setVariable','ifText','ifUrl','ifVariable'];
  return steps.map(step => {
    const action = names.find(name => name.toLowerCase() === String(step.action).toLowerCase()) || step.action;
    return { ...step, action, ...(Array.isArray(step.thenSteps) ? { thenSteps: normalizeStepActions(step.thenSteps as Step[]) } : {}), ...(Array.isArray(step.elseSteps) ? { elseSteps: normalizeStepActions(step.elseSteps as Step[]) } : {}) };
  });
}
