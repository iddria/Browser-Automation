import { useEffect, useRef, useState } from 'react';
import { Bot, Play, Square, X } from 'lucide-react';
import { desktop, invoke, listen } from './bridge';
import { type Profile, uid, useStored, validUrl } from './model';
import ProviderModelFields from './ProviderModelFields';
import { defaultModel } from './providerCatalog';
type AgentAction={action:string;label?:string;value?:string;key?:string;url?:string;reason?:string};
type Approval={id:string;kind:'manual'|'action';detail:string;action:AgentAction|null};
type Entry={step:number;action:string;detail:string;url:string;at:string};
type Result={runId:string;status:string;summary:string;executed:number;trace:Entry[]};
type Progress={runId:string;seq:number;status:string;detail:string;step:number;entry?:Entry;approval?:Approval;result?:Result};
type History={runId:string;status:string;summary:string;executed:number;startUrl:string;provider:string;model:string;finishedAt:string};
const finalStates=['completed','failed','stopped','blocked','limit_reached'];
const statusLabel:Record<string,string>={idle:'Ready',starting:'Opening browser',observing:'Reading page',thinking:'Choosing next action',running:'Running',needs_approval:'Waiting for you',stopping:'Stopping',completed:'Agent finished',failed:'Failed',stopped:'Stopped',blocked:'Needs manual handling',limit_reached:'Step limit reached'};
export default function LiveAgentDialog({open,profiles,onClose,onOpen}:{open:boolean;profiles:Profile[];onClose:()=>void;onOpen:()=>void}){
 const [settings,setSettings]=useStored('live-agent-settings',{provider:'openrouter',model:'',maxSteps:12});
 const [,setHistory]=useStored<History[]>('live-agent-history',[]);
 const [goal,setGoal]=useState('');const [startUrl,setStartUrl]=useState('https://www.google.com');
 const [profileId,setProfileId]=useState('');
 const [status,setStatus]=useState('idle');const [detail,setDetail]=useState('');const [error,setError]=useState('');const [trace,setTrace]=useState<Entry[]>([]);const [step,setStep]=useState(0);const [approval,setApproval]=useState<Approval|null>(null);const [controlling,setControlling]=useState(false);
 const runRef=useRef('');const sequence=useRef(0);const listener=useRef<Promise<()=>void>|null>(null);const finished=useRef(new Set<string>());const session=useRef({startUrl:'',provider:'',model:''});
 const active=status!=='idle'&&!finalStates.includes(status);
 const finish=(result:Result)=>{if(result.runId!==runRef.current)return;setStatus(result.status);setDetail(result.summary);setStep(result.executed);setTrace(result.trace);setApproval(null);if(!finished.current.has(result.runId)){finished.current.add(result.runId);setHistory(all=>[{runId:result.runId,status:result.status,summary:result.summary,executed:result.executed,...session.current,finishedAt:new Date().toISOString()},...all].slice(0,50));}};
 useEffect(()=>{
  let disposed=false;let unlisten:(()=>void)|undefined;
  listener.current=listen<Progress>('ai-agent-progress',({payload:e})=>{
   if(e.runId!==runRef.current||finished.current.has(e.runId)||e.seq<=sequence.current)return;sequence.current=e.seq;
   if(e.result){finish(e.result);return;}
   setStatus(e.status);setDetail(e.detail);setStep(e.step);setApproval(e.approval||null);if(e.entry)setTrace(t=>[...t,e.entry!]);
  }).then(off=>{if(disposed)off();else unlisten=off;return off;});
  return()=>{disposed=true;unlisten?.();};
 },[]);
 useEffect(()=>{if(!open)return;const key=(e:KeyboardEvent)=>{if(e.key==='Escape')onClose();};window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key);},[open,onClose]);
 const run=async()=>{
  if(active)return;setError('');
  let url:string;try{url=validUrl(startUrl);if(!goal.trim()||goal.length>3000)throw Error('Enter a goal of 1–3000 characters.');if(!Number.isInteger(settings.maxSteps)||settings.maxSteps<1||settings.maxSteps>50)throw Error('Max steps must be a whole number from 1 to 50.');}catch(e){setError(String(e));return;}
  if(profileId&&!profiles.some(profile=>profile.id===profileId&&!profile.running)){setError('Choose a saved profile that is closed in Solo Mode.');return;}
  const runId=uid('agent');runRef.current=runId;sequence.current=0;setTrace([]);setStep(0);setApproval(null);setStatus('starting');setDetail('Starting live agent…');
  const model=settings.model||defaultModel(settings.provider);session.current={startUrl:url,provider:settings.provider,model};
  try{await listener.current;const result=await invoke<Result>('run_ai_agent',{runId,goal:goal.trim(),startUrl:url,maxSteps:settings.maxSteps,provider:settings.provider,model,profileId:profileId||null});finish(result);}catch(e){if(runRef.current===runId&&!finished.current.has(runId)){setStatus('failed');setDetail(String(e));setError(String(e));setApproval(null);}}
 };
 const control=async(action:'stop'|'approve'|'reject')=>{if(controlling)return;setControlling(true);setError('');if(action==='stop'){setStatus('stopping');setDetail('Stopping the agent and closing its browser…');}
  const approvalId=approval?.id||null;const reviewSequence=sequence.current;
  try{await invoke('control_ai_agent',{runId:runRef.current,action,approvalId});if(action!=='stop')setApproval(current=>current?.id===approvalId?null:current);}catch(e){if(action==='stop'||sequence.current===reviewSequence)setError(String(e));}finally{setControlling(false);}
 };
 if(!open)return active?<button className="aj-agent-running-badge" onClick={onOpen}><Bot size={16}/>{statusLabel[status]||status} · Open agent</button>:null;
 return <div className="aj-modal-backdrop"><section className="aj-modal aj-agent-modal" role="dialog" aria-modal="true" aria-labelledby="live-agent-title"><header className="aj-agent-heading"><h2 id="live-agent-title"><Bot size={20}/>Run AI Agent (live)</h2><button className="aj-button small" aria-label="Close live agent dialog" onClick={onClose}><X size={16}/></button></header>
 <p className="aj-agent-intro">The agent opens a visible browser, reads the page’s interactive elements, and uses your AI provider to choose each next action. Watch it work in the browser window.</p>
 <fieldset disabled={active}><label>Goal<textarea rows={4} value={goal} maxLength={3000} onChange={e=>setGoal(e.target.value)} placeholder="Visit my test website, open the demo page and inspect the heading…"/></label><div className="aj-grid two"><label>Start URL<input value={startUrl} onChange={e=>setStartUrl(e.target.value)} placeholder="https://example.com"/></label><label>Max steps<input type="number" min="1" max="50" step="1" value={Number.isFinite(settings.maxSteps)?settings.maxSteps:''} onChange={e=>setSettings({...settings,maxSteps:e.target.value===''?NaN:Number(e.target.value)})}/></label></div>
 <label>Browser profile<select value={profileId} onChange={e=>setProfileId(e.target.value)}>
  <option value="">Fresh session</option>
  {profileId&&!profiles.some(profile=>profile.id===profileId)&&<option value={profileId} disabled>Selected profile unavailable</option>}
  {profiles.map(profile=><option key={profile.id} value={profile.id} disabled={profile.running}>{profile.name||profile.id}{profile.running?' (open in Solo Mode)':''}</option>)}
 </select><small>Choose a closed local profile to reuse its saved site session.</small></label>
 <ProviderModelFields labels={{provider:'Provider',model:'Model'}} provider={settings.provider} model={settings.model} onProvider={provider=>setSettings(s=>({...s,provider}))} onModel={model=>setSettings(s=>({...s,model}))}/></fieldset>
 <p className="aj-agent-disclosure">The selected provider receives visible page text and labels. Choose a profile you use for this test. Data entry, buttons and external links pause for approval. Passwords and security challenges require manual handling; downloads are disabled. Use websites you’re authorized to test.</p>
 {!desktop&&<p className="aj-footnote">Run the desktop app to launch the live browser.</p>}
 {(active||status!=='idle')&&<div className="aj-agent-status" role="status"><strong>{statusLabel[status]||status} · {step} actions</strong><p>{detail}</p></div>}
 {error&&<p className="aj-notice" role="alert">{error}</p>}
 {approval&&<section className="aj-agent-approval" aria-label="Agent approval"><h3>{approval.kind==='manual'?'Manual handoff':'Review next action'}</h3><p>{approval.detail}</p>{approval.action&&<><p>{approval.action.reason}</p>{approval.action.url&&<p>{approval.action.url}</p>}{approval.action.value!==undefined&&<label>Text to enter<textarea aria-label="Text to enter" readOnly value={approval.action.value}/></label>}{approval.action.key&&<p>Key: {approval.action.key}</p>}</>}<div className="aj-inline"><button className="aj-button primary" disabled={controlling} onClick={()=>void control('approve')}>{approval.kind==='manual'?'I completed it — resume':'Approve this action'}</button><button className="aj-button" disabled={controlling} onClick={()=>void control('reject')}>Decline &amp; stop</button></div></section>}
 {!!trace.length&&<details className="aj-agent-trace" open><summary>Activity ({trace.length})</summary><ol>{trace.map((e,i)=><li key={i}><strong>{e.step}. {e.detail}</strong><small>{e.url}</small></li>)}</ol></details>}
 <footer className="aj-modal-footer"><button className="aj-button" onClick={onClose}>{active?'Hide':'Close'}</button>{active?<button className="aj-button primary" disabled={controlling||status==='stopping'} onClick={()=>void control('stop')}><Square size={14}/>{status==='stopping'?'Stopping…':'Stop agent'}</button>:<button className="aj-button primary" disabled={!goal.trim()} onClick={()=>void run()}><Play size={14}/>Run agent</button>}</footer>
 </section></div>;
}
