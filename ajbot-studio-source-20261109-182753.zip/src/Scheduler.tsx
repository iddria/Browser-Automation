import { invoke } from "./studio/bridge";
import { listen } from "./studio/bridge";
import { type FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  CalendarClock,
  CheckCircle2,
  Clock3,
  History,
  Pencil,
  Play,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  X,
} from "lucide-react";
import "./Scheduler.css";

type BrowserProfile = { id: string; name?: string; running: boolean };
type BrowserWorkflow = { id: string; name: string; steps?: unknown[] };
type RepeatMode = "once" | "daily" | "weekly";
type ScheduledJob = {
  id: string;
  name: string;
  workflowId: string;
  profileId: string;
  podId?: string | null;
  members?: { profileId: string }[];
  repeat: RepeatMode;
  scheduledAt: number;
  nextRunAt: number;
  enabled: boolean;
  running: boolean;
  lastRunAt?: number | null;
  lastStatus?: string | null;
  lastMessage?: string | null;
  createdAt: number;
};
type ScheduledRun = {
  id: string;
  scheduleId: string;
  scheduleName: string;
  workflowId: string;
  profileId: string;
  startedAt: number;
  finishedAt: number;
  status: string;
  message: string;
};
type Props = { profiles: BrowserProfile[] };

function toLocalInput(timestamp: number) {
  const date = new Date(timestamp);
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function formatDate(timestamp?: number | null) {
  if (!timestamp) return "—";
  return new Date(timestamp).toLocaleString();
}

function repeatLabel(repeat: RepeatMode) {
  return repeat === "once" ? "One time" : repeat === "daily" ? "Daily" : "Weekly";
}

export default function Scheduler({ profiles }: Props) {
  const [workflows, setWorkflows] = useState<BrowserWorkflow[]>([]);
  const [jobs, setJobs] = useState<ScheduledJob[]>([]);
  const [runs, setRuns] = useState<ScheduledRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [editingId, setEditingId] = useState("");
  const [name, setName] = useState("");
  const [workflowId, setWorkflowId] = useState("");
  const [profileId, setProfileId] = useState("");
  const [repeat, setRepeat] = useState<RepeatMode>("once");
  const [scheduledAt, setScheduledAt] = useState(() => toLocalInput(Date.now() + 60 * 60 * 1000));

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [savedJobs, savedRuns, savedWorkflows] = await Promise.all([
        invoke<ScheduledJob[]>("list_schedules"),
        invoke<ScheduledRun[]>("list_schedule_runs"),
        invoke<BrowserWorkflow[]>("list_browser_workflows"),
      ]);
      setJobs(Array.isArray(savedJobs) ? savedJobs : []);
      setRuns(Array.isArray(savedRuns) ? savedRuns : []);
      setWorkflows(Array.isArray(savedWorkflows) ? savedWorkflows : []);
    } catch (e) {
      setError(`Could not load scheduler data: ${String(e)}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
    let unlisten: (() => void) | undefined;
    void listen("scheduler-updated", () => { void refresh(); }).then((fn) => { unlisten = fn; });
    return () => { unlisten?.(); };
  }, [refresh]);

  useEffect(() => {
    if (!workflows.some((item) => item.id === workflowId)) setWorkflowId(workflows[0]?.id || "");
  }, [workflows, workflowId]);
  useEffect(() => {
    if (!profiles.some((item) => item.id === profileId)) setProfileId(profiles[0]?.id || "");
  }, [profiles, profileId]);

  const activeCount = useMemo(() => jobs.filter((job) => job.enabled).length, [jobs]);

  const resetForm = () => {
    setEditingId("");
    setName("");
    setRepeat("once");
    setScheduledAt(toLocalInput(Date.now() + 60 * 60 * 1000));
    setError("");
    setNotice("");
  };

  const editJob = (job: ScheduledJob) => {
    setEditingId(job.id);
    setName(job.name);
    setWorkflowId(job.workflowId);
    setProfileId(job.profileId);
    setRepeat(job.repeat);
    setScheduledAt(toLocalInput(job.nextRunAt));
    setError("");
    setNotice("");
    document.querySelector(".scheduler-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    setNotice("");
    const timestamp = new Date(scheduledAt).getTime();
    if (!name.trim()) return setError("Enter a name for this schedule.");
    if (!workflowId) return setError("Create or select a saved workflow first.");
    if (!profileId) return setError("Create or select a browser profile first.");
    if (!Number.isFinite(timestamp) || timestamp <= Date.now() + 30_000) return setError("Choose a time at least 30 seconds in the future.");
    setSaving(true);
    try {
      await invoke<ScheduledJob>("save_schedule", {
        id: editingId || null,
        name: name.trim(),
        workflowId,
        profileId,
        repeat,
        scheduledAt: timestamp,
      });
      const savedMessage = editingId ? "Schedule updated." : "Schedule created.";
      resetForm();
      await refresh();
      setNotice(savedMessage);
    } catch (e) {
      setError(`Could not save schedule: ${String(e)}`);
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (job: ScheduledJob) => {
    setError("");
    try {
      await invoke("set_schedule_enabled", { id: job.id, enabled: !job.enabled });
      await refresh();
    } catch (e) { setError(`Could not update schedule: ${String(e)}`); }
  };

  const remove = async (job: ScheduledJob) => {
    if (!window.confirm(`Delete the schedule “${job.name}”? Its run history will be kept.`)) return;
    setError("");
    try {
      await invoke("delete_schedule", { id: job.id });
      if (editingId === job.id) resetForm();
      await refresh();
    } catch (e) { setError(`Could not delete schedule: ${String(e)}`); }
  };

  const workflowName = (id: string) => workflows.find((item) => item.id === id)?.name || id;
  const profileName = (id: string) => profiles.find((item) => item.id === id)?.name || id;

  return (
    <div className="scheduler-page">
      <div className="scheduler-heading">
        <div>
          <div className="scheduler-eyebrow"><CalendarClock size={14} /> AUTOMATION CONTROL</div>
          <h1>Scheduler</h1>
          <p>Plan workflow runs and keep control of what runs automatically.</p>
        </div>
        <button className="scheduler-refresh" type="button" onClick={() => void refresh()} disabled={loading}>
          <RefreshCw size={15} className={loading ? "scheduler-spin" : ""} /> Refresh
        </button>
      </div>

      <div className="scheduler-stats">
        <div><span>Saved schedules</span><strong>{jobs.length}</strong></div>
        <div><span>Enabled schedules</span><strong>{activeCount}</strong></div>
        <div><span>Recorded runs</span><strong>{runs.length}</strong></div>
      </div>

      {error && <div className="scheduler-message error"><AlertCircle size={15} />{error}</div>}
      {notice && <div className="scheduler-message success"><CheckCircle2 size={15} />{notice}</div>}

      <div className="scheduler-grid">
        <section className="scheduler-panel scheduler-form-panel">
          <div className="scheduler-panel-heading">
            <div><h2>{editingId ? "Edit schedule" : "Create a schedule"}</h2><p>Choose a saved workflow, profile and start time.</p></div>
            {editingId && <button className="scheduler-icon-button" type="button" onClick={resetForm} aria-label="Cancel editing"><X size={16}/></button>}
          </div>
          <form className="scheduler-form" onSubmit={save}>
            <label>Schedule name<input value={name} onChange={(e) => setName(e.target.value)} maxLength={100} placeholder="e.g. Morning website check" /></label>
            <label>Workflow<select value={workflowId} onChange={(e) => setWorkflowId(e.target.value)}><option value="">Select a saved workflow</option>{workflows.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <label>Browser profile<select value={profileId} onChange={(e) => setProfileId(e.target.value)}><option value="">Select a browser profile</option>{profiles.map((item) => <option key={item.id} value={item.id}>{item.name || item.id}</option>)}</select></label>
            <div className="scheduler-form-row">
              <label>Start date and time<input type="datetime-local" value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} /></label>
              <label>Repeat<select value={repeat} onChange={(e) => setRepeat(e.target.value as RepeatMode)}><option value="once">One time</option><option value="daily">Daily</option><option value="weekly">Weekly</option></select></label>
            </div>
            <div className="scheduler-safety"><ShieldCheck size={16}/><span>Scheduled runs never auto-approve consequential actions. If a workflow reaches an action requiring approval, it pauses instead of submitting, purchasing, sending or confirming on its own.</span></div>
            <div className="scheduler-form-actions">
              <button className="scheduler-primary" type="submit" disabled={saving || loading || !workflows.length || !profiles.length}><Plus size={15}/>{saving ? "Saving…" : editingId ? "Save changes" : "Create schedule"}</button>
              {editingId && <button className="scheduler-secondary" type="button" onClick={resetForm}>Cancel</button>}
            </div>
            {!workflows.length && <p className="scheduler-empty-hint">Create a workflow before scheduling it.</p>}
            {!profiles.length && <p className="scheduler-empty-hint">Create a browser profile before scheduling a run.</p>}
          </form>
        </section>

        <section className="scheduler-panel scheduler-list-panel">
          <div className="scheduler-panel-heading"><div><h2>Your schedules</h2><p>Upcoming runs and recurring tasks.</p></div><span className="scheduler-count">{jobs.length}</span></div>
          {loading ? <p className="scheduler-empty">Loading schedules…</p> : jobs.length === 0 ? <div className="scheduler-empty"><Clock3 size={24}/><strong>No schedules yet</strong><span>Create your first schedule to see it here.</span></div> : (
            <div className="scheduler-job-list">
              {jobs.map((job) => (
                <article className={`scheduler-job ${!job.enabled ? "disabled" : ""}`} key={job.id}>
                  <div className="scheduler-job-top"><div><strong>{job.name}</strong><span className={`scheduler-status ${job.running ? "running" : job.enabled ? "enabled" : "paused"}`}>{job.running ? "Running" : job.enabled ? "Enabled" : "Paused"}</span></div><span className="scheduler-repeat">{repeatLabel(job.repeat)}</span></div>
                  <div className="scheduler-job-meta"><span><b>Workflow</b>{workflowName(job.workflowId)}</span><span><b>{job.podId ? "Pod members" : "Profile"}</b>{job.podId ? `${job.members?.length ?? 0} ${job.members?.length === 1 ? "profile" : "profiles"}` : profileName(job.profileId)}</span><span><b>Next run</b>{job.enabled ? formatDate(job.nextRunAt) : "Paused"}</span></div>
                  {job.lastMessage && <p className="scheduler-last-message">Last result: {job.lastStatus || "—"} · {job.lastMessage}</p>}
                  <div className="scheduler-job-actions">
                    <button type="button" onClick={() => void toggle(job)} disabled={job.running}>{job.enabled ? <><X size={13}/> Pause</> : <><Play size={13}/> Resume</>}</button>
                    {job.podId ? <small>Edit in Pods</small> : <button type="button" onClick={() => editJob(job)} disabled={job.running}><Pencil size={13}/> Edit</button>}
                    <button type="button" className="danger" onClick={() => void remove(job)} disabled={job.running}><Trash2 size={13}/> Delete</button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>

      <section className="scheduler-panel scheduler-history-panel">
        <div className="scheduler-panel-heading"><div><h2><History size={17}/> Recent scheduled runs</h2><p>Latest results recorded on this device.</p></div></div>
        {runs.length === 0 ? <p className="scheduler-empty-inline">No scheduled runs have been recorded yet.</p> : (
          <div className="scheduler-history-list">{runs.slice(0, 30).map((run) => <div className="scheduler-history-row" key={run.id}><span className={`scheduler-history-dot ${run.status === "completed" ? "good" : run.status === "needs_approval" ? "waiting" : "bad"}`}/><div><strong>{run.scheduleName}</strong><span>{run.status.replace(/_/g, " ")} · {formatDate(run.startedAt)}</span><small>{run.message}</small></div><span className="scheduler-history-duration">{Math.max(0, run.finishedAt - run.startedAt) / 1000 < 1 ? "<1s" : `${((run.finishedAt - run.startedAt) / 1000).toFixed(1)}s`}</span></div>)}</div>
        )}
      </section>
      <p className="scheduler-footnote">Ajbot Studio must be open for scheduled runs to execute. Missed one-time runs are skipped after restart; missed recurring occurrences are skipped and the next future occurrence is retained. Daily and weekly repeats use fixed 24-hour and 7-day intervals, so daylight-saving changes can shift the displayed local clock time.</p>
    </div>
  );
}
