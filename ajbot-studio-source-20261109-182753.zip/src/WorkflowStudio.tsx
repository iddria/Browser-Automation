import ProviderModelFields from './studio/ProviderModelFields';
import { defaultModel, plannerProviders } from './studio/providerCatalog';
import { invoke } from "./studio/bridge";
import { FormEvent, PointerEvent as ReactPointerEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, ArrowUp, CheckCircle2, CirclePlay, Copy, Download, FileJson, Globe, Plus, Save, Search, ShieldAlert, Sparkles, Trash2, Upload, X } from "lucide-react";
import "./WorkflowStudio.css";
import { createPortal } from "react-dom";
type BrowserProfile = { id: string; name?: string; startUrl?: string | null; running: boolean };
type StepAction = "navigate"|"back"|"forward"|"reload"|"newTab"|"closeTab"|"switchTab"|"click"|"clickText"|"clickRole"|"doubleClick"|"rightClick"|"hover"|"fill"|"fillLabel"|"type"|"clear"|"press"|"select"|"check"|"uncheck"|"scroll"|"wait"|"waitForSelector"|"waitForText"|"waitForURL"|"extractText"|"extractLinks"|"screenshot"|"setVariable"|"ifText"|"ifUrl"|"ifVariable";
type WorkflowStep = { action: StepAction; url?: string; selector?: string; value?: string; expectedUrl?: string; key?: string; role?: string; label?: string; direction?: "up"|"down"; durationMs?: number; amount?: number; state?: "attached"|"visible"|"hidden"; index?: number; fullPage?: boolean; requiresApproval?: boolean; riskReason?: string; name?: string; operator?: string; thenSteps?: WorkflowStep[]; elseSteps?: WorkflowStep[]; retryCount?: number; retryDelayMs?: number; repeatCount?: number };
type BrowserWorkflow = { id: string; name: string; steps: WorkflowStep[] };
type RunResult = { message?: string; results?: Array<{step?:number;action?:string;ok?:boolean;detail?:string;url?:string;title?:string;startedAt?:string;durationMs?:number;attempts?:number;requiresApproval?:boolean}> };
type Props = {
  profiles: BrowserProfile[];
  onClose: () => void;
  onProfilesRefresh: () => Promise<void>;
  initialUrl?: string;
  initialTitle?: string;
  initialTemplate?: { name: string; steps: WorkflowStep[] };
};
const actions: {value:StepAction;label:string}[] = [
 {value:"navigate",label:"Navigate to URL"},{value:"back",label:"Go back"},{value:"forward",label:"Go forward"},{value:"reload",label:"Reload page"},{value:"newTab",label:"Open new tab"},{value:"closeTab",label:"Close active tab"},{value:"switchTab",label:"Switch tab"},
 {value:"click",label:"Click CSS selector"},{value:"clickText",label:"Click visible text"},{value:"clickRole",label:"Click accessible role"},{value:"doubleClick",label:"Double-click"},{value:"rightClick",label:"Right-click"},{value:"hover",label:"Hover"},
 {value:"fill",label:"Fill input"},{value:"fillLabel",label:"Fill labelled field"},{value:"type",label:"Type sequentially"},{value:"clear",label:"Clear field"},{value:"press",label:"Press key"},{value:"select",label:"Select dropdown option"},{value:"check",label:"Check checkbox"},{value:"uncheck",label:"Uncheck checkbox"},
 {value:"scroll",label:"Scroll page"},{value:"wait",label:"Wait"},{value:"waitForSelector",label:"Wait for element"},{value:"waitForURL",label:"Verify page URL"},{value:"waitForText",label:"Wait for text"},{value:"extractText",label:"Read page text"},{value:"extractLinks",label:"Extract links"},{value:"screenshot",label:"Take screenshot"},{value:"setVariable",label:"Set variable"},{value:"ifText",label:"Condition: page text"},{value:"ifUrl",label:"Condition: page URL"},{value:"ifVariable",label:"Condition: variable"}
];
const makeStep = (action:StepAction):WorkflowStep => ({action,...(action==="navigate"||action==="newTab"?{url:""}:{}),...(["click","doubleClick","rightClick","hover","fill","type","clear","select","check","uncheck","waitForSelector"].includes(action)?{selector:""}:{}),...(["fill","fillLabel","type","select","clickText","waitForText"].includes(action)?{value:""}:{}),...(action==="press"?{key:"Enter"}:{}),...(action==="scroll"?{direction:"down",durationMs:1200,amount:650}:{}),...(action==="wait"?{durationMs:1000}:{}),...(action==="clickRole"?{role:"button",value:""}:{}),...(action==="fillLabel"?{label:"",value:""}:{}),...(action==="switchTab"?{index:0}:{}),...(action==="setVariable"?{name:"siteUrl",value:"https://example.com"}:{}),...(["ifText","ifUrl","ifVariable"].includes(action)?{value:"",operator:"contains",thenSteps:[],elseSteps:[]}:{}),retryCount:0,retryDelayMs:500});
const risky=(s:WorkflowStep)=>s.requiresApproval===true||(["click","clickText","clickRole","doubleClick","rightClick"].includes(s.action)&&/submit|delete|remove|purchase|buy|pay|payment|send|publish|confirm|checkout|transfer|unsubscribe|cancel|place.?order|save.?changes|download|\.apk\b|\.exe\b|\.msi\b|install/i.test(`${s.value||""} ${s.selector||""} ${s.label||""}`));
function normalizeRecordedAction(action: unknown): StepAction | null {
 const raw = String(action ?? "");
 const aliases: Record<string, StepAction> = {
  doubleclick: "doubleClick",
  double_click: "doubleClick",
  rightclick: "rightClick",
  right_click: "rightClick",
  clicktext: "clickText",
  click_text: "clickText",
  clickrole: "clickRole",
  click_role: "clickRole",
  filllabel: "fillLabel",
  fill_label: "fillLabel",
  waitforselector: "waitForSelector",
  wait_for_selector: "waitForSelector",
  waitfortext: "waitForText",
  waitforurl: "waitForURL",
  wait_for_text: "waitForText",
  extracttext: "extractText",
  extract_text: "extractText",
  extractlinks: "extractLinks",
  extract_links: "extractLinks",
  newtab: "newTab",
  closetab: "closeTab",
  switchtab: "switchTab",
  setvariable: "setVariable",
  set_variable: "setVariable",
 };
 const normalized = aliases[raw.toLowerCase()] || raw;
 return actions.some(item => item.value === normalized) ? normalized as StepAction : null;
}
function normalizeWorkflowSteps(steps: WorkflowStep[]): WorkflowStep[] {
 return steps.map(step => {
  const action = normalizeRecordedAction((step as any)?.action);
  const normalized: WorkflowStep = { ...step, action: action || (step as any).action };
  if (Array.isArray(step.thenSteps)) normalized.thenSteps = normalizeWorkflowSteps(step.thenSteps);
  if (Array.isArray(step.elseSteps)) normalized.elseSteps = normalizeWorkflowSteps(step.elseSteps);
  return normalized;
 });
}
function validateSteps(steps:WorkflowStep[]):WorkflowStep[]{
 steps = normalizeWorkflowSteps(steps);
 if(!steps.length||steps.length>50)throw new Error("A workflow must contain between 1 and 50 steps.");
 return steps.map((s,i)=>{const n=i+1;const out:WorkflowStep={...s};if(s.action==="navigate"||s.action==="newTab"){if(s.url){const u=new URL(/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(s.url)?s.url:`https://${s.url}`);if(!["http:","https:"].includes(u.protocol)||u.username||u.password)throw new Error(`Step ${n}: use a valid HTTP or HTTPS URL.`);out.url=u.href;}else if(s.action==="navigate")throw new Error(`Step ${n}: enter a URL.`);}
 if(s.selector&&s.selector.length>1000)throw new Error(`Step ${n}: selector is too long.`);
 if(["click","doubleClick","rightClick","hover","fill","type","clear","select","check","uncheck","waitForSelector"].includes(s.action)&&!s.selector?.trim())throw new Error(`Step ${n}: enter a CSS selector.`);
 if(["fill","type","select","clickText","waitForText"].includes(s.action)&&s.value===undefined)throw new Error(`Step ${n}: enter a value.`);
 if(s.action==="clickRole"&&(!s.role?.trim()||!s.value?.trim()))throw new Error(`Step ${n}: enter a role and accessible name.`);
 if(s.action==="fillLabel"&&(!s.label?.trim()||s.value===undefined))throw new Error(`Step ${n}: enter a field label and value.`);
 if(s.action==="scroll"){if(!["up","down"].includes(s.direction||"down"))throw new Error(`Step ${n}: choose up or down.`);out.durationMs=Math.min(10000,Math.max(250,Number(s.durationMs)||1200));out.amount=Math.min(3000,Math.max(100,Number(s.amount)||650));}
 if(s.action==="wait")out.durationMs=Math.min(30000,Math.max(0,Number(s.durationMs)||0));
 if(s.action==="press"&&!s.key?.trim())throw new Error(`Step ${n}: choose a key.`);
 if(s.action==="switchTab")out.index=Math.max(0,Math.floor(Number(s.index)||0));
 if(s.action==="setVariable"&&(!s.name?.trim()||!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(s.name)))throw new Error(`Step ${n}: use a simple variable name.`);
 if(["ifText","ifUrl","ifVariable"].includes(s.action)&&!s.value?.trim()&&s.action!=="ifVariable")throw new Error(`Step ${n}: enter condition text.`);
 if(s.action==="ifVariable"&&!s.name?.trim())throw new Error(`Step ${n}: enter a variable name.`);
 out.retryCount=Math.min(3,Math.max(0,Math.floor(Number(s.retryCount)||0)));
 out.retryDelayMs=Math.min(10000,Math.max(0,Math.floor(Number(s.retryDelayMs??500)||0)));
 return out;});
}

type ValidationIssue = { step: number; severity: "error" | "warning"; message: string };
const conditionActions = ["ifText", "ifUrl", "ifVariable"];
const selectorActions = ["click", "doubleClick", "rightClick", "hover", "fill", "type", "clear", "select", "check", "uncheck", "waitForSelector"];
function selectorLooksMalformed(selector: string): boolean {
 const value = selector.trim();
 if (!value || value.length > 1000) return true;
 let quote = ""; let escaped = false; let square = 0; let round = 0;
 for (const ch of value) {
  if (escaped) { escaped = false; continue; }
  if (ch === "\\") { escaped = true; continue; }
  if (quote) { if (ch === quote) quote = ""; continue; }
  if (ch === "\"" || ch === "'") { quote = ch; continue; }
  if (ch === "[") square++;
  if (ch === "]" && --square < 0) return true;
  if (ch === "(") round++;
  if (ch === ")" && --round < 0) return true;
 }
 return !!quote || square !== 0 || round !== 0 || escaped;
}
function collectValidationIssues(steps: WorkflowStep[]): ValidationIssue[] {
 const issues: ValidationIssue[] = [];
 const add = (step: number, severity: "error" | "warning", message: string) => issues.push({ step, severity, message });
 if (!steps.length) add(0, "error", "Add at least one workflow step.");
 if (steps.length > 50) add(0, "error", "A workflow cannot contain more than 50 top-level steps.");
 const walk = (list: WorkflowStep[], prefix = "", nested = false) => list.forEach((s, i) => {
  const n = prefix ? `${prefix}.${i + 1}` : String(i + 1);
  const stepNo = Number(n.split(".")[0]);
  if (!s || typeof s !== "object") { add(stepNo, "error", `Branch step ${n} is not a valid step.`); return; }
  const normalizedAction = normalizeRecordedAction((s as any).action);
  if (!normalizedAction) { add(stepNo, "error", `Step ${n} has an unsupported action.`); return; }
  s = { ...s, action: normalizedAction };
  if (nested && conditionActions.includes(s.action)) add(stepNo, "error", `Nested condition at step ${n} is not supported.`);
  if (s.action === "navigate" && !s.url?.trim()) add(stepNo, "error", `Step ${n}: enter a URL.`);
  if (s.action === "navigate" && s.url?.trim()) {
   try { const u = new URL(/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(s.url) ? s.url : `https://${s.url}`); if (!["http:", "https:"].includes(u.protocol) || u.username || u.password) add(stepNo, "error", `Step ${n}: use a valid HTTP or HTTPS URL without embedded credentials.`); }
   catch { add(stepNo, "error", `Step ${n}: URL is malformed.`); }
  }
  if (selectorActions.includes(s.action)) {
   if (!s.selector?.trim()) add(stepNo, "error", `Step ${n}: CSS selector is required.`);
   else if (selectorLooksMalformed(s.selector)) add(stepNo, "error", `Step ${n}: CSS selector appears malformed (check quotes, brackets and parentheses).`);
  }
  if (["fill", "type", "select", "clickText", "waitForText"].includes(s.action) && !s.value?.trim()) add(stepNo, "error", `Step ${n}: required text or option is missing.`);
  if (s.action === "fillLabel" && (!s.label?.trim() || s.value === undefined || !s.value.trim())) add(stepNo, "error", `Step ${n}: field label and text to fill are required.`);
  if (s.action === "clickRole" && (!s.role?.trim() || !s.value?.trim())) add(stepNo, "error", `Step ${n}: accessible role and name are required.`);
  if (s.repeatCount != null && (!Number.isInteger(s.repeatCount) || s.repeatCount < 1 || s.repeatCount > 10)) add(stepNo, "error", `Step ${n}: repeat count must be 1–10.`);
  if (s.action === "waitForURL" && !s.value?.trim()) add(stepNo, "error", `Step ${n}: enter the URL to verify.`);
  if (s.action === "press" && !s.key?.trim()) add(stepNo, "error", `Step ${n}: keyboard key is required.`);
  if (s.action === "setVariable") {
   if (!s.name?.trim() || !/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(s.name)) add(stepNo, "error", `Step ${n}: enter a valid variable name.`);
   if (s.value === undefined || !s.value.trim()) add(stepNo, "error", `Step ${n}: variable value is required.`);
  }
  if (conditionActions.includes(s.action)) {
   if (!s.operator?.trim()) add(stepNo, "error", `Step ${n}: condition operator is missing.`);
   else if (!["contains", "equals", "notContains", "exists"].includes(s.operator)) add(stepNo, "error", `Step ${n}: condition operator is not supported.`);
   if (s.action === "ifVariable" && (!s.name?.trim() || !/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(s.name))) add(stepNo, "error", `Step ${n}: condition variable name is missing or invalid.`);
   if (s.operator !== "exists" && !s.value?.trim()) add(stepNo, "error", `Step ${n}: condition comparison value is required.`);
   if (!Array.isArray(s.thenSteps) || !Array.isArray(s.elseSteps)) add(stepNo, "error", `Step ${n}: both condition branches must be valid step arrays.`);
   else {
    if (s.thenSteps.length > 20 || s.elseSteps.length > 20) add(stepNo, "error", `Step ${n}: each branch is limited to 20 steps.`);
    if (!s.thenSteps.length && !s.elseSteps.length) add(stepNo, "warning", `Step ${n}: both branches are empty, so this condition has no effect.`);
    walk(s.thenSteps, `${n}.then`, true); walk(s.elseSteps, `${n}.else`, true);
   }
  }
  if (s.action === "newTab" && !s.url?.trim()) add(stepNo, "warning", `Step ${n}: a new tab will open without a specified URL.`);
  if (["extractText", "extractLinks"].includes(s.action) && !s.selector?.trim()) add(stepNo, "warning", `Step ${n}: no selector is set; the action may inspect the whole page.`);
 });
 walk(steps);
 return issues;
}

export default function WorkflowStudio({profiles,onClose,onProfilesRefresh,initialUrl,initialTitle,initialTemplate}:Props){
 const [draggedStepIndex,setDraggedStepIndex]=useState<number|null>(null);const [dragOverStepIndex,setDragOverStepIndex]=useState<number|null>(null);const pointerDragRef=useRef<{from:number;to:number;pointerId:number}|null>(null);const [items,setItems]=useState<BrowserWorkflow[]>([]);const [selectedId,setSelectedId]=useState("");const [workflowSearch,setWorkflowSearch]=useState("");const [name,setName]=useState("");const [steps,setSteps]=useState<WorkflowStep[]>([makeStep("navigate")]);const [profileId,setProfileId]=useState("");const [loading,setLoading]=useState(true);const [saving,setSaving]=useState(false);const [running,setRunning]=useState(false);const [error,setError]=useState("");const [notice,setNotice]=useState("");const [runResult,setRunResult]=useState<RunResult|null>(null);const [taskPrompt,setTaskPrompt]=useState(() => sessionStorage.getItem("ajbot-planner-prompt") || "");const [plannerNotice,setPlannerNotice]=useState("");const [aiProvider,setAiProvider]=useState<string>("ollama");const [aiModel,setAiModel]=useState("qwen2.5:7b");const [openAiKey,setOpenAiKey]=useState("");const [aiPlanning,setAiPlanning]=useState(false);const [importPreview,setImportPreview]=useState<BrowserWorkflow|null>(null);const [importWarning,setImportWarning]=useState("");
 const requestedWorkflowId=useRef(sessionStorage.getItem("ajbot-run-workflow"));
 const [savedKeyIds,setSavedKeyIds]=useState<string[]>([]);
 const savedProviderKey = savedKeyIds.includes(aiProvider);
 useEffect(()=>{void invoke<string[]>("list_provider_keys").then(setSavedKeyIds).catch(()=>{}); const raw=sessionStorage.getItem("ajbot-planner-preference"); if(raw){try{const p=JSON.parse(raw);if(plannerProviders.some(provider=>provider.id===p.provider)){setAiProvider(p.provider);setAiModel(typeof p.model === "string" ? p.model : defaultModel(p.provider));}}catch{ /* ignore invalid preference */ }} },[]);
 const validationIssues=useMemo(()=>collectValidationIssues(steps),[steps]);
 const blockingIssues=validationIssues.filter(issue=>issue.severity==="error");
 const warningIssues=validationIssues.filter(issue=>issue.severity==="warning");
 const runningProfiles=useMemo(()=>profiles.filter(p=>p.running),[profiles]);
 const loadWorkflows=useCallback(async()=>{setLoading(true);try{const result=await invoke<BrowserWorkflow[]>("list_browser_workflows");const list=Array.isArray(result)?result:[];setItems(list);const requestedId=requestedWorkflowId.current;const requested=list.find(w=>w.id===requestedId);if(requested){sessionStorage.removeItem("ajbot-run-workflow");setSelectedId(requested.id);setName(requested.name);setSteps(normalizeWorkflowSteps(requested.steps));setNotice("Canvas workflow loaded. Review the steps and choose a running profile before execution.");}else if(initialTemplate&&!selectedId){setSelectedId("");setName(initialTemplate.name);setSteps(initialTemplate.steps.map(step=>({...step})));setNotice("Template loaded as an unsaved draft. Review the steps, then save when ready.");}else if(initialUrl&&!selectedId){setName(initialTitle?`Workflow: ${initialTitle}`:"New website workflow");setSteps([{action:"navigate",url:initialUrl}]);}else if(list.length&&!selectedId){setSelectedId(list[0].id);setName(list[0].name);setSteps(normalizeWorkflowSteps(list[0].steps||[makeStep("navigate")]));}}catch(e){setError(`Could not load workflows: ${String(e)}`);}finally{setLoading(false);}},[initialTemplate,initialUrl,initialTitle]);
 useEffect(()=>{void loadWorkflows();},[loadWorkflows]);useEffect(()=>{if(!runningProfiles.some(p=>p.id===profileId))setProfileId(runningProfiles[0]?.id||"");},[runningProfiles,profileId]);
 const selectWorkflow=(w:BrowserWorkflow)=>{setSelectedId(w.id);setName(w.name);setSteps(w.steps?.length?normalizeWorkflowSteps(w.steps.map(s=>({...s}))):[makeStep("navigate")]);setError("");setNotice("");setRunResult(null);};
 const newWorkflow=()=>{setSelectedId("");setName("");setSteps([makeStep("navigate")]);setError("");setNotice("");setRunResult(null);};
 const duplicateWorkflow=async()=>{
  if(!selectedId){setError("Save this workflow before duplicating it.");return;}
  setError("");setNotice("");
  try{
   const checked=validateSteps(steps);
   const id=`workflow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
   const copy=await invoke<BrowserWorkflow>("save_browser_workflow",{workflowId:id,name:`${name.trim()||"Workflow"} (copy)`,steps:checked});
   setItems(cur=>[copy,...cur.filter(w=>w.id!==copy.id)]);
   selectWorkflow(copy);
   setNotice("Workflow duplicated. Rename it if needed, then save your changes.");
  }catch(e){setError(`Could not duplicate workflow: ${String(e)}`);}
 };
 const filteredWorkflows=useMemo(()=>{const q=workflowSearch.trim().toLowerCase();return q?items.filter(w=>w.name.toLowerCase().includes(q)):items;},[items,workflowSearch]);
 const updateStep=(i:number,patch:Partial<WorkflowStep>)=>setSteps(cur=>cur.map((s,j)=>i===j?{...s,...patch}:s));
 const moveStep=(i:number,d:-1|1)=>setSteps(cur=>{const t=i+d;if(t<0||t>=cur.length)return cur;const copy=[...cur];[copy[i],copy[t]]=[copy[t],copy[i]];return copy;});
 const handleStepPointerDown=(event:ReactPointerEvent<HTMLButtonElement>,index:number)=>{
  if(event.button!==0)return;
  event.preventDefault();event.stopPropagation();
  pointerDragRef.current={from:index,to:index,pointerId:event.pointerId};
  setDraggedStepIndex(index);setDragOverStepIndex(index);
 };
 useEffect(()=>{
  if(draggedStepIndex===null)return;
  const handlePointerMove=(event:PointerEvent)=>{
   const drag=pointerDragRef.current;if(!drag||event.pointerId!==drag.pointerId)return;
   const element=document.elementFromPoint(event.clientX,event.clientY)?.closest<HTMLElement>("[data-step-index]");
   if(!element)return;
   const target=Number(element.dataset.stepIndex);if(!Number.isInteger(target))return;
   const rect=element.getBoundingClientRect();
   const insertAfter=event.clientY>rect.top+rect.height/2;
   let destination=target+(insertAfter?1:0);
   if(drag.from<destination)destination-=1;
   destination=Math.max(0,Math.min(steps.length-1,destination));
   pointerDragRef.current={...drag,to:destination};
   setDragOverStepIndex(target);
  };
  const handlePointerUp=(event:PointerEvent)=>{
   const drag=pointerDragRef.current;if(!drag||event.pointerId!==drag.pointerId)return;
   if(drag.from!==drag.to){
    setSteps(current=>{const next=[...current];const [moved]=next.splice(drag.from,1);next.splice(drag.to,0,moved);return next;});
   }
   pointerDragRef.current=null;setDraggedStepIndex(null);setDragOverStepIndex(null);
  };
  const handlePointerCancel=()=>{pointerDragRef.current=null;setDraggedStepIndex(null);setDragOverStepIndex(null);};
  window.addEventListener("pointermove",handlePointerMove,{passive:true});
  window.addEventListener("pointerup",handlePointerUp);
  window.addEventListener("pointercancel",handlePointerCancel);
  return()=>{window.removeEventListener("pointermove",handlePointerMove);window.removeEventListener("pointerup",handlePointerUp);window.removeEventListener("pointercancel",handlePointerCancel);};
 },[draggedStepIndex,steps.length]);
 const duplicateStep=(i:number)=>setSteps(cur=>{if(cur.length>=50)return cur;const copy=[...cur];const clone=JSON.parse(JSON.stringify(cur[i])) as WorkflowStep;copy.splice(i+1,0,clone);return copy;});
 const draftFromTask=async()=>{if(!taskPrompt.trim()){setPlannerNotice("Describe the browser task first.");return;}if(aiProvider!=="ollama"&&!openAiKey.trim()&&!savedProviderKey){setPlannerNotice("Enter a key for the selected provider or save it in Provider Keys.");return;}setAiPlanning(true);setPlannerNotice("Planning browser workflow…");try{const response=await invoke<{name?:string;steps?:WorkflowStep[]}>("plan_browser_workflow",{task:taskPrompt.trim(),provider:aiProvider,model:aiModel.trim()||defaultModel(aiProvider),apiKey:aiProvider!=="ollama"?openAiKey.trim():null,profileId:profileId||null});if(!response.steps?.length)throw new Error("The AI returned an empty workflow.");setSelectedId("");setName(response.name||"AI workflow draft");setSteps(response.steps.slice(0,50));setRunResult(null);setPlannerNotice(`Draft created. Review every step. ${response.steps.filter(risky).length} step(s) need extra approval.`);}catch(e){setPlannerNotice(`AI planning failed: ${String(e)}`);}finally{setAiPlanning(false);}};
 const saveWorkflow=async(e?:FormEvent)=>{e?.preventDefault();setError("");setNotice("");if(blockingIssues.length){setError(`Fix ${blockingIssues.length} validation error(s) before saving. Review the Validation panel.`);return;}let checked:WorkflowStep[];try{checked=validateSteps(steps);}catch(e){setError(String(e));return;}if(!name.trim()){setError("Give this workflow a name.");return;}setSaving(true);try{const id=selectedId||`workflow-${Date.now()}`;const saved=await invoke<BrowserWorkflow>("save_browser_workflow",{workflowId:id,name:name.trim(),steps:checked});setItems(cur=>[saved,...cur.filter(w=>w.id!==id)]);setSelectedId(saved.id);setSteps(normalizeWorkflowSteps(saved.steps));setNotice("Workflow saved.");}catch(e){setError(`Could not save workflow: ${String(e)}`);}finally{setSaving(false);}};
 const deleteWorkflow=async()=>{if(!selectedId)return newWorkflow();if(!window.confirm(`Delete "${name}"? This cannot be undone.`))return;try{await invoke("delete_browser_workflow",{workflowId:selectedId});const rest=items.filter(w=>w.id!==selectedId);setItems(rest);if(rest.length)selectWorkflow(rest[0]);else newWorkflow();setNotice("Workflow deleted.");}catch(e){setError(String(e));}};
 const runWorkflow=async()=>{setError("");setNotice("");setRunResult(null);if(blockingIssues.length){setError(`Fix ${blockingIssues.length} validation error(s) before running. Review the Validation panel.`);return;}if(warningIssues.length&&!window.confirm(`Review ${warningIssues.length} validation warning(s) before running?\n\n${warningIssues.map(x=>`Step ${x.step}: ${x.message}`).join("\n")}\n\nContinue only if these warnings are acceptable.`))return;if(!runningProfiles.length||!profileId){setError("Launch and select a browser profile first.");return;}let checked:WorkflowStep[];try{checked=validateSteps(steps);}catch(e){setError(String(e));return;}if(!name.trim()){setError("Give this workflow a name.");return;}const flagged=checked.map((s,i)=>({s,i})).filter(x=>risky(x.s));if(flagged.length&&!window.confirm(`Extra approval required for these steps:\n${flagged.map(x=>`${x.i+1}. ${x.s.action}: ${x.s.value||x.s.selector||x.s.url||""}`).join("\n")}\n\nContinue?`))return;if(!window.confirm(`Run "${name}" on the selected browser profile?`))return;setRunning(true);try{const id=selectedId||`workflow-${Date.now()}`;const saved=await invoke<BrowserWorkflow>("save_browser_workflow",{workflowId:id,name:name.trim(),steps:checked});setSelectedId(saved.id);setItems(cur=>[saved,...cur.filter(w=>w.id!==id)]);const result=await invoke<RunResult>("run_browser_workflow",{workflowId:saved.id,profileId,approveConsequential:flagged.length>0});setRunResult(result);setNotice(result.message||"Workflow finished.");const failed=result.results?.find(r=>r.ok===false);if(failed)setError(`Step ${failed.step||"?"} stopped: ${failed.detail||"Action failed or approval is required."}`);await onProfilesRefresh();}catch(e){setError(`Workflow run failed: ${String(e)}`);}finally{setRunning(false);}};

 const exportWorkflow=()=>{
  setError("");setNotice("");
  if(!name.trim()){setError("Give this workflow a name before exporting.");return;}
  try{
   const checked=validateSteps(steps);
   const payload={format:"ajbot-workflow",version:1,exportedAt:new Date().toISOString(),workflow:{name:name.trim(),steps:checked}};
   const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
   const url=URL.createObjectURL(blob);const a=document.createElement("a");
   a.href=url;a.download=`${name.trim().replace(/[^a-z0-9-_]+/gi,"-").replace(/^-|-$/g,"")||"workflow"}.ajbot-workflow.json`;
   document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
   setNotice("Workflow JSON exported.");
  }catch(e){setError(`Could not export workflow: ${String(e)}`);}
 };
 const readWorkflowFile=async(file:File)=>{
  setError("");setNotice("");setImportWarning("");
  if(file.size>1024*1024){setError("Import file is too large. Maximum size is 1 MB.");return;}
  try{
   const raw=JSON.parse(await file.text());
   const source=raw?.format==="ajbot-workflow"&&raw?.version===1?raw.workflow:raw;
   if(!source||typeof source!=="object"||Array.isArray(source))throw new Error("The file must contain a workflow object.");
   if(typeof source.name!=="string"||!source.name.trim())throw new Error("The workflow name is missing.");
   if(!Array.isArray(source.steps))throw new Error("The workflow steps must be an array.");
   const known=new Set(actions.map(a=>a.value));
   if(source.steps.length<1||source.steps.length>50)throw new Error("A workflow must contain between 1 and 50 steps.");
   for(let i=0;i<source.steps.length;i++){
    const step=source.steps[i];
    if(!step||typeof step!=="object"||Array.isArray(step)||!known.has(step.action))throw new Error(`Step ${i+1} has an unsupported action.`);
   }
   const checked=validateSteps(source.steps as WorkflowStep[]);
   const duplicate=items.some(w=>w.name.trim().toLowerCase()===source.name.trim().toLowerCase());
   setImportPreview({id:"",name:source.name.trim(),steps:checked});
   setImportWarning(duplicate?"A workflow with this name already exists. Import will create a separate draft; it will not overwrite the existing workflow.":"Review the imported steps, then save when ready.");
  }catch(e){setError(`Import rejected: ${e instanceof Error?e.message:String(e)}`);}
 };
 const confirmImport=()=>{
  if(!importPreview)return;
  setSelectedId("");setName(importPreview.name);setSteps(importPreview.steps.map(s=>({...s})));
  setRunResult(null);setImportPreview(null);setNotice("Imported as an unsaved draft. Review it and choose Save workflow to add it.");
  setError("");
 };

 const field=(label:string,value:string|number|undefined,onChange:(v:string)=>void,type="text",placeholder="")=><label className="ws-label">{label}<input className="ws-input" type={type} value={value??""} placeholder={placeholder} onChange={e=>onChange(e.target.value)}/></label>;
 return createPortal(
  <div
    className="workflow-studio-backdrop"
    role="presentation"
    onMouseDown={(event) => {
      if (event.target === event.currentTarget) onClose();
    }}
  ><section className="workflow-studio" role="dialog" aria-modal="true" aria-labelledby="workflow-studio-title"><header className="ws-header"><div><div className="ws-eyebrow">AJBOT STUDIO / AUTOMATION</div><h2 id="workflow-studio-title">Workflow builder</h2><p>Plan, inspect, interact with and read websites using Playwright.</p></div><button className="ws-icon-button" onClick={onClose} aria-label="Close"><X size={18}/></button></header>
 <div className="ws-layout"><aside className="ws-sidebar"><div className="ws-sidebar-heading"><strong>Saved workflows <span className="ws-count">{items.length}</span></strong><button className="ws-small-button" type="button" onClick={newWorkflow}><Plus size={14}/> New</button></div><label className="ws-search"><Search size={14}/><input value={workflowSearch} onChange={e=>setWorkflowSearch(e.target.value)} placeholder="Search workflows…" aria-label="Search saved workflows"/></label>{loading?<p className="ws-muted">Loading…</p>:filteredWorkflows.length?filteredWorkflows.map(w=><button key={w.id} type="button" className={`ws-workflow-choice ${selectedId===w.id?"selected":""}`} onClick={()=>selectWorkflow(w)}><span>{w.name}</span><small>{w.steps?.length||0} steps</small></button>):<p className="ws-muted">{items.length?"No workflows match your search.":"No saved workflows yet. Create one and choose Save workflow."}</p>}</aside>
 <form className="ws-editor" onSubmit={saveWorkflow}><section className="ws-planner"><div className="ws-planner-heading"><Sparkles size={17}/><div><strong>AI Browser Planner</strong><p>Describe the outcome. Review the generated steps before running.</p></div></div><ProviderModelFields provider={aiProvider} model={aiModel} onProvider={provider=>{setAiProvider(provider);setOpenAiKey("");}} onModel={setAiModel} />{aiProvider!=="ollama"&&field(savedProviderKey?"Provider key (saved key used when blank)":"Provider API key (memory only)",openAiKey,setOpenAiKey,"password",savedProviderKey?"Using encrypted saved key":"API key…")}<label className="ws-label">Task instructions<textarea className="ws-input ws-planner-input" rows={3} maxLength={3000} value={taskPrompt} onChange={e=>setTaskPrompt(e.target.value)} placeholder="Search a website, inspect the results, open a relevant page, scroll, read its links, and report what you find."/></label><button type="button" className="ws-small-button" disabled={aiPlanning} onClick={()=>void draftFromTask()}><Sparkles size={14}/>{aiPlanning?"Planning…":"Generate AI draft"}</button>{plannerNotice&&<p className="ws-planner-notice" role="status">{plannerNotice}</p>}<p className="ws-planner-privacy"><ShieldAlert size={13}/> Review all actions. Downloads, submissions, purchases, messages and other consequential actions require explicit approval. Security checks are not bypassed.</p></section>

 <section className="ws-transfer-panel">
  <div><div className="ws-transfer-title"><FileJson size={16}/><strong>Workflow files</strong></div><p>Export this draft as JSON, or import a workflow file for review before saving.</p></div>
  <div className="ws-transfer-actions">
   <button type="button" className="ws-small-button" onClick={exportWorkflow}><Download size={14}/> Export JSON</button>
   <label className="ws-small-button ws-file-button"><Upload size={14}/> Import JSON<input type="file" accept=".json,.ajbot-workflow.json,application/json" onChange={e=>{const f=e.target.files?.[0];if(f)void readWorkflowFile(f);e.currentTarget.value="";}}/></label>
  </div>
  {importPreview&&<div className="ws-import-review"><strong>Review import: {importPreview.name}</strong><span>{importPreview.steps.length} steps · Not saved yet</span><ol>{importPreview.steps.map((s,i)=><li key={i}>{i+1}. {actions.find(a=>a.value===s.action)?.label||s.action}{s.url?` — ${s.url}`:""}{s.selector?` — ${s.selector}`:""}</li>)}</ol><p>{importWarning}</p><div><button type="button" className="ws-secondary-button" onClick={()=>setImportPreview(null)}>Cancel</button><button type="button" className="ws-primary-button" onClick={confirmImport}>Load draft for review</button></div></div>}
 </section>

 {field("Workflow name",name,setName)}<section aria-live="polite" style={{border:"1px solid var(--border, #d8dce3)",borderRadius:12,padding:14,margin:"12px 0",background:"var(--panel, rgba(127,127,127,.06))"}}><div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}><ShieldAlert size={16}/><strong>Workflow validation</strong><span style={{marginLeft:"auto",fontSize:12}}>{blockingIssues.length} error(s) · {warningIssues.length} warning(s)</span></div>{validationIssues.length===0?<p style={{margin:"10px 0 0",fontSize:13}}>No validation issues found. The workflow is ready for review.</p>:<ul style={{margin:"10px 0 0",paddingLeft:22,fontSize:13}}>{validationIssues.map((issue,index)=><li key={`${issue.step}-${index}`} style={{marginBottom:6,color:issue.severity==="error"?"#c0392b":"#a66a00"}}><strong>{issue.severity.toUpperCase()}</strong> · {issue.step?`Step ${issue.step}`:"Workflow"}: {issue.message}</li>)}</ul>}{blockingIssues.length>0&&<p style={{margin:"10px 0 0",fontSize:12}}>Saving and running are disabled until all errors are fixed. Warnings require review before running.</p>}</section><div className="ws-steps-heading"><div><strong>Browser actions</strong><span>{steps.length} / 50</span></div><div className="ws-add-actions"><select className="ws-input" value="" onChange={e=>{if(e.target.value)setSteps(cur=>cur.length<50?[...cur,makeStep(e.target.value as StepAction)]:cur);}}><option value="">+ Add action…</option>{actions.map(a=><option key={a.value} value={a.value}>{a.label}</option>)}</select></div></div>
 <div className="ws-step-list">{steps.map((s,i)=><article data-step-index={i} className={`ws-step-card${dragOverStepIndex===i&&draggedStepIndex!==null&&draggedStepIndex!==i?" ws-step-drag-over":""}`} key={`${i}-${s.action}`} style={{opacity:draggedStepIndex===i?0.55:1,outline:dragOverStepIndex===i&&draggedStepIndex!==null&&draggedStepIndex!==i?"2px dashed var(--accent, #6b7cff)":undefined}}><div className="ws-step-top"><div className="ws-step-title"><button type="button" onPointerDown={event=>handleStepPointerDown(event,i)} aria-label={`Drag to reorder step ${i+1}`} title="Hold and drag to reorder" style={{cursor:draggedStepIndex===i?"grabbing":"grab",border:0,background:"transparent",padding:"6px 9px",fontSize:20,lineHeight:1,touchAction:"none",userSelect:"none"}}>⠿</button><span className="ws-step-number">{i+1}</span><Globe size={15}/><strong>{actions.find(a=>a.value===s.action)?.label||s.action}</strong>{risky(s)&&<span className="ws-risk-badge"><ShieldAlert size={12}/> Approval</span>}</div><div className="ws-step-tools"><button type="button" disabled={!i} onClick={()=>moveStep(i,-1)} aria-label="Move up"><ArrowUp size={14}/></button><button type="button" disabled={i===steps.length-1} onClick={()=>moveStep(i,1)} aria-label="Move down" title="Move down"><ArrowDown size={14}/></button><button type="button" disabled={steps.length>=50} onClick={()=>duplicateStep(i)} aria-label="Duplicate step" title="Duplicate step"><Copy size={14}/></button><button type="button" disabled={steps.length===1} onClick={()=>setSteps(cur=>cur.filter((_,j)=>j!==i))} aria-label="Remove" title="Remove step"><Trash2 size={14}/></button></div></div>
 <label className="ws-label">Action<select className="ws-input" value={s.action} onChange={e=>updateStep(i,makeStep(e.target.value as StepAction))}>{actions.map(a=><option key={a.value} value={a.value}>{a.label}</option>)}</select></label>
 {(["navigate","newTab"].includes(s.action))&&field("URL",s.url,v=>updateStep(i,{url:v}),"text","https://example.com")}
 {(["click","doubleClick","rightClick","hover","fill","type","clear","select","check","uncheck","waitForSelector"].includes(s.action))&&field("CSS selector",s.selector,v=>updateStep(i,{selector:v}),"text","button, input[name='q']")}
 {(["fill","type","select","clickText","waitForText"].includes(s.action))&&field("Text / option / visible text",s.value,v=>updateStep(i,{value:v}))}
 {s.action==="waitForURL"&&field("Expected URL",s.value,v=>updateStep(i,{value:v,...(s.expectedUrl ? {expectedUrl:v} : {})}))}
 {s.action==="fillLabel"&&<>{field("Field label",s.label,v=>updateStep(i,{label:v}))}{field("Text to fill",s.value,v=>updateStep(i,{value:v}))}</>}
 {s.action==="clickRole"&&<>{field("Accessible role",s.role,v=>updateStep(i,{role:v}),"text","button, link, textbox")}{field("Accessible name",s.value,v=>updateStep(i,{value:v}))}</>}
 {s.action==="press"&&field("Keyboard key",s.key,v=>updateStep(i,{key:v}),"text","Enter, Tab, Escape, Control+A")}
 {s.action==="scroll"&&<><label className="ws-label">Direction<select className="ws-input" value={s.direction||"down"} onChange={e=>updateStep(i,{direction:e.target.value as "up"|"down"})}><option value="down">Down</option><option value="up">Up</option></select></label>{field("Duration (milliseconds)",s.durationMs,v=>updateStep(i,{durationMs:Number(v)}),"number")}{field("Scroll amount per movement",s.amount,v=>updateStep(i,{amount:Number(v)}),"number")}</>}
 {s.action==="wait"&&field("Wait duration (milliseconds)",s.durationMs,v=>updateStep(i,{durationMs:Number(v)}),"number")}
 {s.action==="waitForSelector"&&<label className="ws-label">Wait until<select className="ws-input" value={s.state||"visible"} onChange={e=>updateStep(i,{state:e.target.value as WorkflowStep["state"]})}><option value="visible">Visible</option><option value="attached">Attached</option><option value="hidden">Hidden</option></select></label>}
 {s.action==="switchTab"&&field("Tab number (starts at 0)",s.index,v=>updateStep(i,{index:Number(v)}),"number")}
 {s.action==="screenshot"&&<label className="ws-label"><input type="checkbox" checked={!!s.fullPage} onChange={e=>updateStep(i,{fullPage:e.target.checked})}/> Capture full page</label>}
 {s.action==="setVariable"&&<>{field("Variable name",s.name,v=>updateStep(i,{name:v}))}{field("Variable value",s.value,v=>updateStep(i,{value:v}),"text","Use {{otherVariable}} to reuse a value")}</>}
 {["ifText","ifUrl","ifVariable"].includes(s.action)&&<><label className="ws-label">Condition<select className="ws-input" value={s.operator||"contains"} onChange={e=>updateStep(i,{operator:e.target.value})}><option value="contains">Contains</option><option value="equals">Equals</option><option value="notContains">Does not contain</option><option value="exists">Exists (variable only)</option></select></label>{s.action==="ifVariable"&&field("Variable name",s.name,v=>updateStep(i,{name:v}))}{s.operator!=="exists"&&field("Expected text / value",s.value,v=>updateStep(i,{value:v}))}<p className="ws-muted">Branch steps are supplied as JSON arrays. Keep each branch to simple, non-nested actions.</p>{(["thenSteps","elseSteps"] as const).map(k=><label className="ws-label">{k==="thenSteps"?"Then branch (JSON)":"Else branch (JSON)"}<textarea className="ws-input" rows={3} value={JSON.stringify(s[k]||[])} onChange={e=>{try{const parsed=JSON.parse(e.target.value);if(Array.isArray(parsed))updateStep(i,{[k]:parsed} as Partial<WorkflowStep>);}catch{/* keep last valid branch while typing */}}}/></label>)}</>}
 {field("Repeat this step (1–10)",s.repeatCount??1,v=>updateStep(i,{repeatCount:Number(v)}),"number")}
 {![ "setVariable","ifText","ifUrl","ifVariable"].includes(s.action)&&<div className="ws-retry-controls">{field("Retries (0–3)",s.retryCount,v=>updateStep(i,{retryCount:Number(v)}),"number")}{field("Retry delay (ms, max 10000)",s.retryDelayMs,v=>updateStep(i,{retryDelayMs:Number(v)}),"number")}<p className="ws-muted">Retries are disabled for consequential actions to avoid duplicate side effects.</p></div>}
 {risky(s)&&<p className="ws-muted">This step will be included in the extra-approval confirmation.</p>}
 </article>)}</div>
 <section className="ws-run-panel"><div className="ws-run-heading"><CirclePlay size={17}/><strong>Execution</strong><span>Manual approval required</span></div><label className="ws-label">Running browser profile<select className="ws-input" value={profileId} onChange={e=>setProfileId(e.target.value)}>{runningProfiles.length?runningProfiles.map(p=><option key={p.id} value={p.id}>{p.name||p.id}</option>):<option value="">No running profiles</option>}</select></label><p className="ws-safety-note">Ajbot runs only after you press Run and confirm. Use websites where you have permission. Review all steps before execution.</p><div className="ws-footer-actions">{selectedId&&<button type="button" className="ws-secondary-button" onClick={()=>void duplicateWorkflow()} disabled={saving||running}><Copy size={15}/> Duplicate</button>}<button type="button" className="ws-danger-button" onClick={()=>void deleteWorkflow()}><Trash2 size={15}/> Delete</button><div><button type="submit" className="ws-secondary-button" disabled={saving||running||blockingIssues.length>0}><Save size={15}/>{saving?"Saving…":"Save workflow"}</button><button type="button" className="ws-primary-button" disabled={running||saving||loading||!runningProfiles.length||blockingIssues.length>0} onClick={()=>void runWorkflow()}><CirclePlay size={15}/>{running?"Running…":"Run workflow"}</button></div></div></section>
 {error&&<p className="ws-message error" role="alert">{error}</p>}{notice&&<p className="ws-message success" role="status"><CheckCircle2 size={15}/>{notice}</p>}{runResult?.results&&<section className="ws-results"><strong>Step results</strong>{runResult.results.map((r,i)=><div className="ws-result-row" key={i}><span className={`ws-result-dot ${r.ok===false?"fail":""}`}/><span>Step {r.step||i+1}: {r.action}</span><span>{r.detail}{r.url?` · ${r.url}`:""}{r.durationMs!==undefined?` · ${r.durationMs} ms`:""}{r.attempts!==undefined?` · ${r.attempts} attempt(s)`:""}{r.startedAt?` · ${new Date(r.startedAt).toLocaleTimeString()}`:""}</span></div>)}</section>}
 </form></div></section></div>,
document.body
);
}