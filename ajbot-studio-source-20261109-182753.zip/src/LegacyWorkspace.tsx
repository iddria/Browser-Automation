import WorkflowStudio from "./WorkflowStudio";
import WebSearchPanel from "./WebSearchPanel";
import Scheduler from "./Scheduler";
import ProxyManagement from "./ProxyManagement";
import { invoke } from "./studio/bridge";
import { listen } from "./studio/bridge";
import AutomaticBackups from "./AutomaticBackups";
import { type FormEvent, useEffect, useState } from "react";
import {
  Activity, Archive,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Bot,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Command,
  Compass,
  Cpu,
  Ellipsis,
  FolderOpen,
  Globe2,
  LayoutDashboard,
  Play,
  Pause,
  Square,
  CircleDot,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Timer,
  Workflow,
  FilePlus2,
  FileText,
  SearchCheck,
  ClipboardList,
  Zap,
  Pencil,
  Trash2,
  Download,
  Upload,
  Network,
} from "lucide-react";
import "./App.css";
import ajbotLogo from "./assets/ajbot-logo.png";

type RunRecord = {
  id: string; workflowId: string; workflowName: string; profileId: string;
  source: "manual" | "scheduled"; status: string; startedAt: number;
  finishedAt?: number | null; durationMs?: number | null; currentStep?: number;
  totalSteps?: number; steps?: Array<{ step: number; action: string; status?: string; ok?: boolean; detail?: string; durationMs?: number }>;
  message?: string;
};
type LiveRun = { runId: string; workflowName?: string; profileId?: string; source?: string; status: string; currentStep: number; totalSteps: number; stepLabel?: string; message?: string };
type RecordedAction = { id: string; action: string; selector?: string; value?: string; label?: string; text?: string; url?: string; pageTitle?: string; selectorConfidence?: string; selectorCandidates?: string[]; recordedAt?: number };
type RecorderState = { profileId: string; status: "recording" | "paused" | "stopped"; actions: RecordedAction[] };

type BrowserProfile = {
  id: string;
  name?: string;
  startUrl?: string | null;
  running: boolean;
};

const navigation = [
  { label: "Overview", icon: LayoutDashboard, active: true },
  { label: "Browser profiles", icon: Globe2, count: "03" },
  { label: "Proxy Management", icon: Network },
  { label: "Workflows", icon: Workflow, count: "08" },
  { label: "Templates", icon: FilePlus2 },
  { label: "Run history", icon: Activity },
  { label: "Scheduler", icon: Timer },
  { label: "Automatic Backups", icon: Archive },
];

const workflows = [
  {
    name: "Website availability check",
    description: "Open a page and verify its status",
    icon: Compass,
    color: "blue",
    status: "Completed",
    time: "2 min ago",
    duration: "4.2s",
  },
  {
    name: "Product page monitor",
    description: "Check selected page content",
    icon: Search,
    color: "purple",
    status: "Completed",
    time: "18 min ago",
    duration: "8.7s",
  },
  {
    name: "Daily research workflow",
    description: "Collect information from approved pages",
    icon: Sparkles,
    color: "orange",
    status: "Draft",
    time: "Yesterday",
    duration: "—",
  },
];

type WorkflowTemplate = { id: string; name: string; description: string; category: string; icon: typeof FileText; steps: Array<{ action: "navigate" | "back" | "forward" | "reload" | "newTab" | "closeTab" | "switchTab" | "click" | "doubleClick" | "rightClick" | "hover" | "fill" | "select" | "check" | "uncheck" | "wait" | "screenshot"; url?: string; durationMs?: number; selector?: string; value?: string; fullPage?: boolean }> };
const workflowTemplates: WorkflowTemplate[] = [
 { id:"website-check", name:"Website availability check", description:"Open a website, wait for it to load, and capture a page screenshot.", category:"Website checks", icon:SearchCheck, steps:[{action:"navigate",url:"https://example.com"},{action:"wait",durationMs:1500},{action:"screenshot",fullPage:false}] },
 { id:"page-review", name:"Page content review", description:"Visit a page and capture its full page for manual review.", category:"Research", icon:FileText, steps:[{action:"navigate",url:"https://example.com"},{action:"wait",durationMs:1200},{action:"screenshot",fullPage:true}] },
 { id:"search-preview", name:"Search results preview", description:"Open a search page and inspect it without submitting anything.", category:"Research", icon:SearchCheck, steps:[{action:"navigate",url:"https://www.google.com"},{action:"wait",durationMs:1000},{action:"screenshot",fullPage:false}] },
 { id:"form-draft", name:"Form draft helper", description:"Open a form and fill a chosen field. Review it yourself; no submit action is included.", category:"Forms", icon:ClipboardList, steps:[{action:"navigate",url:"https://example.com"},{action:"wait",durationMs:1000},{action:"fill",selector:"input[name=\'name\']",value:"Your text here"}] }
];

function normalizeWebsiteUrl(value: string): string {
  const trimmed = value.trim();

  if (!trimmed) {
    return "";
  }

  const withProtocol = /^[a-zA-Z][a-zA-Z\d+.-]*:/.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;

  const parsed = new URL(withProtocol);

  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    !parsed.hostname.includes(".")
  ) {
    throw new Error("Enter a valid website address, such as https://example.com.");
  }

  return parsed.href;
}

function LegacyWorkspace({ section = "Overview" }: { section?: string }) {
  const [browserProfiles, setBrowserProfiles] = useState<BrowserProfile[]>([]);
  const [profilesLoading, setProfilesLoading] = useState(false);
  const [profileSearch, setProfileSearch] = useState("");
  const [activeSection, setActiveSection] = useState(section);
  useEffect(() => { setActiveSection(section); }, [section]);
  const [workflowStudioOpen, setWorkflowStudioOpen] = useState(false);
  const [workflowStart, setWorkflowStart] = useState<{ url: string; title: string } | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<WorkflowTemplate | null>(null);
  const [runHistory, setRunHistory] = useState<RunRecord[]>([]);
  const [historySearch, setHistorySearch] = useState("");
  const [historyFilter, setHistoryFilter] = useState("all");
  const [liveRun, setLiveRun] = useState<LiveRun | null>(null);
  const [recorder, setRecorder] = useState<RecorderState | null>(null);
  const [recorderBusy, setRecorderBusy] = useState(false);
  const [recorderMessage, setRecorderMessage] = useState("");

  const refreshRunHistory = async () => {
    try { setRunHistory(await invoke<RunRecord[]>("list_run_history")); }
    catch (error) { console.error("Could not load run history", error); }
  };

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    void listen<any>("workflow-progress", (event) => {
      const payload = event.payload;
      if (payload.type === "run_started") {
        const run = payload.run;
        setLiveRun({ runId: run.id, workflowName: run.workflowName, profileId: run.profileId, source: run.source, status: "running", currentStep: 0, totalSteps: run.totalSteps || 0 });
      } else if (payload.type === "step_started") {
        setLiveRun((current) => {
          if (!current || current.runId !== payload.runId) return current;
          return {
            ...current,
            status: "running",
            currentStep: payload.currentStep,
            totalSteps: payload.totalSteps,
            stepLabel: payload.step?.action,
          };
        });
      } else if (payload.type === "step_completed") {
        setLiveRun((current) => {
          if (!current || current.runId !== payload.runId) return current;
          return {
            ...current,
            currentStep: payload.currentStep,
            totalSteps: payload.totalSteps,
            stepLabel: payload.step?.action,
            message: payload.step?.detail,
          };
        });
      } else if (payload.type === "run_finished") {
        const run = payload.run;
        setLiveRun({ runId: run.id, workflowName: run.workflowName, profileId: run.profileId, source: run.source, status: run.status, currentStep: run.currentStep || 0, totalSteps: run.totalSteps || 0, message: run.message });
        void refreshRunHistory();
      }
    }).then((fn) => { unlisten = fn; });
    let unlistenRecorder: (() => void) | undefined;
    void listen<any>("recorder-event", (event) => {
      const payload = event.payload;
      if (payload?.type === "action_recorded" && payload.action) {
        setRecorder((current) => {
          if (!current || current.profileId !== payload.profileId) return current;
          if (current.actions.some((item) => item.id === payload.action.id)) return current;
          return { ...current, actions: [...current.actions, payload.action] };
        });
      } else if (payload?.type === "recorder_status") {
        setRecorder((current) => current && current.profileId === payload.profileId
          ? { ...current, status: payload.status }
          : current);
      }
    }).then((fn) => { unlistenRecorder = fn; });
    void refreshRunHistory();
    return () => { unlisten?.(); unlistenRecorder?.(); };
  }, []);

  const startRecording = async (profile: BrowserProfile) => {
    setRecorderBusy(true); setRecorderMessage("");
    try {
      const result = await invoke<{ status: RecorderState["status"]; actions?: RecordedAction[] }>("start_browser_recording", { profileId: profile.id });
      setRecorder({ profileId: profile.id, status: result.status || "recording", actions: result.actions || [] });
      setRecorderMessage(`Recording started for ${profile.name || profile.id}.`);
    } catch (error) { setRecorderMessage(`Could not start recording: ${String(error)}`); }
    finally { setRecorderBusy(false); }
  };

  const controlRecording = async (action: "pauseRecorder" | "resumeRecorder" | "stopRecorder") => {
    if (!recorder) return;
    setRecorderBusy(true); setRecorderMessage("");
    try {
      const result = await invoke<{ status: RecorderState["status"]; actions?: RecordedAction[] }>("control_browser_recording", { action, profileId: recorder.profileId });
      setRecorder((current) => current && current.profileId === recorder.profileId
        ? { ...current, status: result.status || (action === "stopRecorder" ? "stopped" : action === "pauseRecorder" ? "paused" : "recording"), actions: result.actions || current.actions }
        : current);
      setRecorderMessage(action === "stopRecorder" ? "Recording stopped. Convert it into a workflow when you're ready." : action === "pauseRecorder" ? "Recording paused." : "Recording resumed.");
    } catch (error) { setRecorderMessage(`Recorder control failed: ${String(error)}`); }
    finally { setRecorderBusy(false); }
  };

  const convertRecordingToWorkflow = () => {
    if (!recorder?.actions.length) { setRecorderMessage("There are no recorded actions to convert yet."); return; }
    type WorkflowStep = WorkflowTemplate["steps"][number];

    const converted: WorkflowTemplate["steps"] =
      recorder.actions.flatMap<WorkflowStep>(
        (item): WorkflowStep[] => {
          const action =
            item.action === "doubleclick" ? "doubleClick" : item.action;

          if (action === "navigate") {
            return item.url
              ? [{ action: "navigate", url: item.url }]
              : [];
          }

          if (
            action === "click" ||
            action === "doubleClick" ||
            action === "fill" ||
            action === "select" ||
            action === "check" ||
            action === "uncheck"
          ) {
            if (!item.selector) return [];

            return [{
              action,
              selector: item.selector,
              ...(item.value !== undefined ? { value: item.value } : {}),
            }];
          }

          return [];
        },
      );
    if (!converted.length) { setRecorderMessage("No supported workflow actions were captured. Record a navigation, click, field entry, or selection first."); return; }
    setSelectedTemplate({ id: `recorded-${Date.now()}`, name: `Recorded workflow ${new Date().toLocaleString()}`, description: "Recorded browser actions converted into an editable workflow draft.", category: "Recorded", icon: Workflow, steps: converted });
    setWorkflowStart(null); setWorkflowStudioOpen(true);
    setRecorderMessage(`${converted.length} recorded action(s) loaded as an editable workflow draft. Review before saving or running.`);
  };

  const openWorkflowFromSearch = (result: { url: string; title: string }) => {
    setWorkflowStart({ url: result.url, title: result.title });
    setSelectedTemplate(null);
    setWorkflowStudioOpen(true);
  };

  const closeWorkflowStudio = () => {
    setWorkflowStudioOpen(false);
    setWorkflowStart(null);
    setSelectedTemplate(null);
  };

  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingProfileId, setEditingProfileId] = useState<string | null>(null);
  const [deletingProfileId, setDeletingProfileId] = useState<string | null>(null);
  const [newProfileName, setNewProfileName] = useState("");
  const [newProfileUrl, setNewProfileUrl] = useState("");
  const [creatingProfile, setCreatingProfile] = useState(false);
  const [profileFormError, setProfileFormError] = useState("");
  const [profileBackupBusyId, setProfileBackupBusyId] = useState<string | null>(null);
  const [profileRestoreBusy, setProfileRestoreBusy] = useState(false);
  const [profileVerifyBusy, setProfileVerifyBusy] = useState(false);

  const checkNode = async () => {
    try {
      const version = await invoke<string>("check_node");
      alert(`Node.js is connected: ${version}`);
    } catch (error) {
      alert(`Node.js check failed: ${String(error)}`);
    }
  };

  const refreshBrowserProfiles = async () => {
    setProfilesLoading(true);

    try {
      const profiles = await invoke<BrowserProfile[]>(
        "list_browser_profiles"
      );
      setBrowserProfiles(profiles);
    } catch (error) {
      alert(`Could not load browser profiles: ${String(error)}`);
    } finally {
      setProfilesLoading(false);
    }
  };

  useEffect(() => {
    void refreshBrowserProfiles();
  }, []);

  const openCreateDialog = () => {
    setEditingProfileId(null);
    setNewProfileName("");
    setNewProfileUrl("");
    setProfileFormError("");
    setCreateDialogOpen(true);
  };

  const closeCreateDialog = () => {
    if (creatingProfile) return;

    setCreateDialogOpen(false);
    setEditingProfileId(null);
    setProfileFormError("");
  };

  const openEditDialog = (profile: BrowserProfile) => {
    if (profile.running) {
      setProfileFormError("Stop this browser before editing its profile settings.");
      return;
    }
    setEditingProfileId(profile.id);
    setNewProfileName(profile.name || "");
    setNewProfileUrl(profile.startUrl || "");
    setProfileFormError("");
    setCreateDialogOpen(true);
  };

  const handleDeleteProfile = async (profile: BrowserProfile) => {
    if (profile.running) {
      alert("Stop this browser profile before deleting it.");
      return;
    }
    if (recorder?.profileId === profile.id && recorder.status !== "stopped") {
      alert("Stop the active recording before deleting this profile.");
      return;
    }
    const confirmed = window.confirm(
      `Delete “${profile.name || profile.id}”?\n\nThis permanently removes the profile's local browser data, including cookies, site sessions, saved settings, screenshots, and recorder recovery files. This cannot be undone.`
    );
    if (!confirmed) return;
    setDeletingProfileId(profile.id);
    try {
      await invoke("delete_browser_profile", { profileId: profile.id });
      if (recorder?.profileId === profile.id) setRecorder(null);
      await refreshBrowserProfiles();
    } catch (error) {
      alert(`Could not delete profile: ${String(error)}`);
      await refreshBrowserProfiles();
    } finally {
      setDeletingProfileId(null);
    }
  };

  const handleCreateProfile = async (
    event: FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();
    setProfileFormError("");

    const name = newProfileName.trim();

    if (!name) {
      setProfileFormError("Enter a profile name.");
      return;
    }

    let startUrl: string;

    try {
      startUrl = normalizeWebsiteUrl(newProfileUrl);
    } catch (error) {
      setProfileFormError(
        error instanceof Error
          ? error.message
          : "Enter a valid website address."
      );
      return;
    }

    setCreatingProfile(true);

    try {
      const profileId = `profile-${Date.now()}`;

      if (editingProfileId) {
        await invoke("update_browser_profile", {
          profileId: editingProfileId,
          name,
          startUrl: startUrl || null,
        });
      } else {
        await invoke("create_browser_profile", {
          profileId,
          name,
          startUrl: startUrl || null,
        });
      }

      setCreateDialogOpen(false);
      setEditingProfileId(null);
      setNewProfileName("");
      setNewProfileUrl("");

      await refreshBrowserProfiles();
    } catch (error) {
      setProfileFormError(`Could not save profile: ${String(error)}`);
    } finally {
      setCreatingProfile(false);
    }
  };

  const handleBackupProfile = async (profile: BrowserProfile) => {
  if (profile.running) {
    alert("Stop this browser profile before creating a backup.");
    return;
  }

  setProfileBackupBusyId(profile.id);

  try {
    const result = await invoke<{
      cancelled?: boolean;
      path?: string;
      profileName?: string;
      createdAt?: number;
      bytes?: number;
    }>("backup_browser_profile", {
      profileId: profile.id,
    });

    if (!result.cancelled) {
      const backupName =
        result.profileName || profile.name || profile.id;

      const backupDate = result.createdAt
        ? new Date(result.createdAt).toLocaleString()
        : "Not available";

      const archiveSize =
        typeof result.bytes === "number"
          ? result.bytes < 1024 * 1024
            ? `${(result.bytes / 1024).toFixed(2)} KB`
            : `${(result.bytes / (1024 * 1024)).toFixed(2)} MB`
          : "Not available";

      alert(
        `Profile backup created successfully!\n\n` +
        `Profile: ${backupName}\n` +
        `Backup date: ${backupDate}\n` +
        `Archive size: ${archiveSize}\n\n` +
        `Saved to:\n${result.path || "Unknown location"}`
      );
    }
  } catch (error) {
    alert(`Could not back up profile: ${String(error)}`);
  } finally {
    setProfileBackupBusyId(null);
  }
};

  const handleRestoreProfile = async () => {
    const name = window.prompt("Choose a name for the restored browser profile:", "Restored profile");
    if (name === null) return;
    if (!name.trim()) {
      alert("Enter a name for the restored profile.");
      return;
    }
    setProfileRestoreBusy(true);
    try {
      const result = await invoke<{ cancelled?: boolean; profile?: BrowserProfile }>(
        "restore_browser_profile",
        { name: name.trim() },
      );
      if (!result.cancelled && result.profile) {
        await refreshBrowserProfiles();
        alert(`Profile restored successfully as “${result.profile.name}”.\\nA new profile ID was created, so your existing profiles were not overwritten.`);
      }
    } catch (error) {
      alert(`Could not restore profile: ${String(error)}`);
    } finally {
      setProfileRestoreBusy(false);
    }
  };

  const handleVerifyProfileBackup = async () => {
  setProfileVerifyBusy(true);

  try {
    const result = await invoke<{
      cancelled?: boolean;
      valid?: boolean;
      path?: string;
      profileName?: string;
      createdAt?: number | null;
      archiveBytes?: number;
      uncompressedBytes?: number;
      fileCount?: number;
      directoryCount?: number;
      message?: string;
    }>("verify_browser_profile_backup");

    if (result.cancelled) return;

    if (!result.valid) {
      alert("Backup verification failed. The selected archive could not be verified.");
      return;
    }

    const formatBytes = (bytes?: number) => {
      if (typeof bytes !== "number") return "Not available";

      if (bytes < 1024) return `${bytes} bytes`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;

      return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    };

    const backupDate = result.createdAt
      ? new Date(result.createdAt).toLocaleString()
      : "Not available";

    alert(
      `BACKUP VERIFIED SUCCESSFULLY!\n\n` +
      `Profile: ${result.profileName || "Unknown profile"}\n` +
      `Backup date: ${backupDate}\n` +
      `Files checked: ${result.fileCount ?? 0}\n` +
      `Directories: ${result.directoryCount ?? 0}\n` +
      `Archive size: ${formatBytes(result.archiveBytes)}\n` +
      `Uncompressed size: ${formatBytes(result.uncompressedBytes)}\n\n` +
      `Location:\n${result.path || "Unknown location"}\n\n` +
      `${result.message || "All backup entries passed validation."}`
    );
  } catch (error) {
    alert(
      `BACKUP VERIFICATION FAILED\n\n` +
      `The selected backup may be damaged, incomplete, or unsupported.\n\n` +
      `Details: ${String(error)}`
    );
  } finally {
    setProfileVerifyBusy(false);
  }
};

  const handleBrowserAction = async (profile: BrowserProfile) => {
    try {
      if (profile.running) {
        await invoke("close_browser_profile", {
          profileId: profile.id,
        });
      } else {
        await invoke("launch_browser_profile", {
          profileId: profile.id,
          url: profile.startUrl || null,
        });
      }

      await refreshBrowserProfiles();
    } catch (error) {
      alert(`Browser action failed: ${String(error)}`);
      await refreshBrowserProfiles();
    }
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <img src={ajbotLogo} alt="Ajbot robot logo" />
          </div>
          <div>
            <div className="brand-name">
              ajbot<span>studio</span>
            </div>
            <div className="brand-caption">AUTOMATION WORKSPACE</div>
          </div>
        </div>

        <button className="workspace-switcher">
          <div className="workspace-avatar">O</div>
          <div className="workspace-copy">
            <strong>My workspace</strong>
            <span>Personal workspace</span>
          </div>
          <ChevronDown size={15} />
        </button>

        <div className="nav-label">WORKSPACE</div>
        <nav className="main-nav">
          {navigation.map(({ label, icon: Icon, count }) => (
            <button
              className={`nav-item ${activeSection === label ? "active" : ""}`}
              key={label}
              onClick={() => {
                if (label === "Workflows") {
                  setSelectedTemplate(null);
                  setWorkflowStudioOpen(true);
                  setActiveSection("Overview");
                } else {
                  setActiveSection(label);
                }
              }}
            >
              <Icon size={18} />
              <span>{label}</span>
              {(label === "Browser profiles" || count) && (
                <span className="nav-count">
                  {label === "Browser profiles"
                    ? String(browserProfiles.length).padStart(2, "0")
                    : count}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="nav-label tools-label">PREFERENCES</div>
        <nav className="main-nav">
          <button className="nav-item">
            <Settings2 size={18} />
            <span>Settings</span>
          </button>
          <button
  className={`nav-item ${activeSection === "Automatic backups" ? "active" : ""}`}
  onClick={() => setActiveSection("Automatic backups")}
>
  <Archive size={18} />
  <span>Automatic backups</span>
</button>
          <button className="nav-item">
            <CircleHelp size={18} />
            <span>Help &amp; support</span>
          </button>
        </nav>

        <div className="sidebar-bottom">
          <div className="upgrade-card">
            <div className="upgrade-icon">
              <Zap size={17} />
            </div>
            <strong>Your workspace, your rules.</strong>
            <p>Build reliable automations at your own pace.</p>
            <button
              onClick={() =>
                window.alert("Your workspace settings will be available soon.")
              }
            >
              Explore workspace <ArrowRight size={14} />
            </button>
          </div>

          <div className="user-profile">
            <div className="user-avatar">W</div>
            <div className="user-copy">
              <strong>Workspace owner</strong>
              <span>Local workspace</span>
            </div>
            <Ellipsis size={18} />
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumbs">
            <span>Workspace</span>
            <span className="crumb-slash">/</span>
            <strong>{activeSection}</strong>
          </div>

          <div className="topbar-actions">
            <div className="system-status">
              <span className="status-dot" />
              Local environment
            </div>
            <button className="help-button" onClick={checkNode}>
              Test Node.js
            </button>
            <button
              className="icon-button"
              aria-label="Search"
              onClick={() =>
                document.getElementById("web-search")?.scrollIntoView({ behavior: "smooth", block: "center" })
              }
            >
              <Search size={18} />
            </button>
            <button className="help-button">
              <CircleHelp size={16} /> Help
            </button>
            <div className="top-avatar">W</div>
          </div>
        </header>

        <div className="page-content">
          {activeSection === "Browser profiles" ? (
            <section className="browser-profiles-page">
              <div className="profile-page-heading">
                <div>
                  <div className="eyebrow"><Globe2 size={14} /> BROWSER SESSION MANAGEMENT</div>
                  <h1>Browser profiles</h1>
                  <p className="page-subtitle">
                    Manage isolated browser sessions and start recording from any running profile.
                  </p>
                </div>
                <div className="profile-page-actions">
                  <button
                    className="secondary-button profile-refresh-button"
                    onClick={() => void refreshBrowserProfiles()}
                    disabled={profilesLoading}
                  >
                    <Activity size={15} /> {profilesLoading ? "Refreshing..." : "Refresh"}
                  </button>
                  <button
  className="secondary-button profile-refresh-button"
  onClick={() => void handleVerifyProfileBackup()}
  disabled={profileVerifyBusy}
>
  <ShieldCheck size={15} />
  {profileVerifyBusy ? "Verifying..." : "Verify backup"}
</button>

<button
  className="secondary-button profile-refresh-button"
  onClick={() => void handleRestoreProfile()}
  disabled={profileRestoreBusy}
>
  <Upload size={15} />
  {profileRestoreBusy ? "Restoring..." : "Restore backup"}
</button>
                  <button className="primary-button" onClick={openCreateDialog}>
                    <Plus size={16} /> Create profile
                  </button>
                </div>
              </div>

              <div className="profile-overview-strip">
                <div className="profile-overview-item">
                  <span className="profile-overview-icon"><Globe2 size={17} /></span>
                  <span><strong>{browserProfiles.length}</strong><small>Total profiles</small></span>
                </div>
                <div className="profile-overview-item">
                  <span className="profile-overview-icon running"><Activity size={17} /></span>
                  <span><strong>{browserProfiles.filter((profile) => profile.running).length}</strong><small>Running now</small></span>
                </div>
                <div className="profile-overview-item">
                  <span className="profile-overview-icon stopped"><Square size={16} /></span>
                  <span><strong>{browserProfiles.filter((profile) => !profile.running).length}</strong><small>Stopped</small></span>
                </div>
              </div>

              <p className="profile-backup-safety-note">
                <ShieldCheck size={14} /> Backups contain browser data, including cookies and signed-in sessions. Keep ZIP files private. Profiles must be stopped before backup or restore.
              </p>

              <div className="profile-toolbar">
                <div className="profile-search">
                  <Search size={16} />
                  <input
                    value={profileSearch}
                    onChange={(event) => setProfileSearch(event.target.value)}
                    placeholder="Search profiles by name, ID, or website..."
                    aria-label="Search browser profiles"
                  />
                </div>
                <span className="profile-result-count">
                  {browserProfiles.filter((profile) =>
                    `${profile.name || ""} ${profile.id} ${profile.startUrl || ""}`
                      .toLowerCase()
                      .includes(profileSearch.toLowerCase())
                  ).length} profile(s)
                </span>
              </div>

              {profilesLoading && browserProfiles.length === 0 ? (
                <div className="profile-empty-state">
                  <Activity size={24} />
                  <strong>Loading browser profiles</strong>
                  <span>Retrieving your local browser sessions...</span>
                </div>
              ) : browserProfiles.length === 0 ? (
                <div className="profile-empty-state">
                  <Globe2 size={28} />
                  <strong>No browser profiles yet</strong>
                  <span>Create your first profile to keep browser sessions separate.</span>
                  <button className="primary-button" onClick={openCreateDialog}>
                    <Plus size={16} /> Create your first profile
                  </button>
                </div>
              ) : (
                <div className="browser-profile-grid">
                  {browserProfiles
                    .filter((profile) =>
                      `${profile.name || ""} ${profile.id} ${profile.startUrl || ""}`
                        .toLowerCase()
                        .includes(profileSearch.toLowerCase())
                    )
                    .map((profile, index) => (
                      <article className="browser-profile-card" key={profile.id}>
                        <div className="browser-profile-card-top">
                          <div className={`profile-browser-icon profile-browser-icon-${index % 4}`}>
                            <Globe2 size={24} />
                          </div>
                          <span className={`profile-status-pill ${profile.running ? "is-running" : "is-stopped"}`}>
                            <span />
                            {profile.running ? "Running" : "Stopped"}
                          </span>
                        </div>

                        <div className="browser-profile-card-info">
                          <h3>{profile.name || "Untitled profile"}</h3>
                          <p className="profile-card-id">{profile.id}</p>
                          <div className="profile-card-website">
                            <Globe2 size={13} />
                            <span>{profile.startUrl || "No starting website set"}</span>
                          </div>
                        </div>

                        <div className="browser-profile-card-footer">
                          <button
                            className={profile.running ? "secondary-button profile-stop-button" : "primary-button profile-launch-button"}
                            onClick={() => void handleBrowserAction(profile)}
                            disabled={profilesLoading}
                          >
                            {profile.running ? <Square size={14} /> : <Play size={14} />}
                            {profile.running ? "Stop browser" : "Launch browser"}
                          </button>
                          {profile.running && (
                            <button
                              className="secondary-button profile-record-button"
                              disabled={recorderBusy || (!!recorder && recorder.profileId !== profile.id && recorder.status !== "stopped")}
                              onClick={() => void startRecording(profile)}
                            >
                              <CircleDot size={14} /> Record
                            </button>
                          )}
                          <button
                            className="secondary-button profile-manage-button profile-backup-button"
                            onClick={() => void handleBackupProfile(profile)}
                            disabled={profile.running || profileBackupBusyId === profile.id}
                            title={profile.running ? "Stop the browser before creating a backup" : "Save a ZIP backup of this profile"}
                          >
                            <Download size={14} /> {profileBackupBusyId === profile.id ? "Backing up..." : "Backup"}
                          </button>
                          <button
                            className="secondary-button profile-manage-button"
                            onClick={() => openEditDialog(profile)}
                            disabled={profile.running || deletingProfileId === profile.id}
                            title={profile.running ? "Stop the browser before editing" : "Edit profile"}
                          >
                            <Pencil size={14} /> Edit
                          </button>
                          <button
                            className="secondary-button profile-delete-button"
                            onClick={() => void handleDeleteProfile(profile)}
                            disabled={profile.running || deletingProfileId === profile.id || (recorder?.profileId === profile.id && recorder.status !== "stopped")}
                            title={profile.running ? "Stop the browser before deleting" : "Delete profile and its local browser data"}
                          >
                            <Trash2 size={14} /> {deletingProfileId === profile.id ? "Deleting..." : "Delete"}
                          </button>
                        </div>

                        {recorder?.profileId === profile.id && (
                          <div className="recorder-inline-panel profile-recorder-panel">
                            <div className="profile-recorder-heading">
                              <strong><CircleDot size={13} /> Recorder · {recorder.status}</strong>
                              <span>{recorder.actions.length} action(s)</span>
                            </div>
                            <div className="profile-recorder-controls">
                              {recorder.status === "recording" && (
                                <button className="secondary-button" disabled={recorderBusy} onClick={() => void controlRecording("pauseRecorder")}><Pause size={14} /> Pause</button>
                              )}
                              {recorder.status === "paused" && (
                                <button className="secondary-button" disabled={recorderBusy} onClick={() => void controlRecording("resumeRecorder")}><Play size={14} /> Resume</button>
                              )}
                              {recorder.status !== "stopped" && (
                                <button className="secondary-button" disabled={recorderBusy} onClick={() => void controlRecording("stopRecorder")}><Square size={14} /> Stop</button>
                              )}
                              {recorder.status === "stopped" && (
                                <button className="primary-button" disabled={!recorder.actions.length} onClick={convertRecordingToWorkflow}><Workflow size={14} /> Convert to workflow</button>
                              )}
                            </div>
                            <ol className="profile-recorder-actions">
                              {recorder.actions.map((item) => (
                                <li key={item.id}>
                                  <strong>{item.action}</strong>
                                  {item.label ? ` · ${item.label}` : item.selector ? ` · ${item.selector}` : item.url ? ` · ${item.url}` : ""}
                                </li>
                              ))}
                            </ol>
                            {recorderMessage && <p className="profile-recorder-message" role="status">{recorderMessage}</p>}
                          </div>
                        )}
                      </article>
                    ))}
                </div>
              )}

              {browserProfiles.length > 0 && profileSearch &&
                !browserProfiles.some((profile) =>
                  `${profile.name || ""} ${profile.id} ${profile.startUrl || ""}`
                    .toLowerCase()
                    .includes(profileSearch.toLowerCase())
                ) && (
                  <div className="profile-no-results">
                    No profiles match “{profileSearch}”. Try another search.
                  </div>
                )}
            </section>
) : activeSection === "Proxy Management" ? (
  <ProxyManagement profiles={browserProfiles} />
) : activeSection === "Templates" ? (            <section className="template-page">
              <div className="welcome-row"><div><div className="eyebrow"><FilePlus2 size={14} /> REUSABLE STARTING POINTS</div><h1>Workflow templates</h1><p className="page-subtitle">Choose a starter workflow, customize its steps, then save it as your own.</p></div></div>
              <div className="template-grid">{workflowTemplates.map((template) => { const Icon=template.icon; return <article className="template-card" key={template.id}><div className="template-card-icon"><Icon size={21}/></div><span className="template-category">{template.category}</span><h3>{template.name}</h3><p>{template.description}</p><div className="template-card-footer"><span>{template.steps.length} starter steps</span><button className="primary-button" onClick={()=>{setSelectedTemplate(template);setWorkflowStart(null);setWorkflowStudioOpen(true);setActiveSection("Overview");}}>Customize template <ArrowRight size={14}/></button></div></article>; })}</div>
              <p className="template-safety-note"><ShieldCheck size={15}/> Templates create editable drafts only. Nothing runs until you review the steps, choose a running browser profile, and explicitly press Run.</p>
            </section>
          ) : activeSection === "Automatic backups" ? (
  <AutomaticBackups />
) : activeSection === "Scheduler" ? (
  <Scheduler profiles={browserProfiles} />
          ) : activeSection === "Run history" ? (
            <section className="run-history-page">
              <div className="welcome-row"><div><div className="eyebrow"><Activity size={14} /> EXECUTION RECORDS</div><h1>Run history</h1><p className="page-subtitle">Review actual workflow executions, outcomes, and step details.</p></div><button className="secondary-button" onClick={() => void refreshRunHistory()}><Activity size={15} /> Refresh</button></div>
              <div className="history-toolbar"><input value={historySearch} onChange={(e) => setHistorySearch(e.target.value)} placeholder="Search workflow, profile, or run ID..." aria-label="Search run history" /><select value={historyFilter} onChange={(e) => setHistoryFilter(e.target.value)} aria-label="Filter run history"><option value="all">All runs</option><option value="completed">Completed</option><option value="failed">Failed</option><option value="stopped">Stopped</option><option value="needs_approval">Needs approval</option><option value="manual">Manual</option><option value="scheduled">Scheduled</option></select></div>
              <div className="history-list">{runHistory.filter((run) => { const q = historySearch.toLowerCase(); const matches = `${run.workflowName} ${run.profileId} ${run.id}`.toLowerCase().includes(q); return matches && (historyFilter === "all" || run.status === historyFilter || run.source === historyFilter); }).map((run) => <details className="history-card" key={run.id}><summary><span className={`history-status ${run.status}`}>{run.status.replace(/_/g, " ")}</span><span className="history-main"><strong>{run.workflowName}</strong><small>{run.profileId} · {run.source} · {new Date(run.startedAt).toLocaleString()}</small></span><span className="history-duration">{run.durationMs != null ? `${(run.durationMs / 1000).toFixed(1)}s` : "—"}</span></summary><p>{run.message || "No run summary available."}</p><div className="history-steps">{(run.steps || []).map((step) => <div className="history-step" key={`${run.id}-${step.step}`}><span>#{step.step} · {step.action}</span><span>{step.ok ? "Completed" : step.status || "Failed"}</span><small>{step.detail || ""}</small></div>)}</div></details>)}{runHistory.length === 0 && <div className="history-empty"><Activity size={24} /><strong>No executions recorded yet</strong><span>Run a saved workflow to create your first history record.</span></div>}</div>
            </section>
          ) : (
          <>
          <section className="welcome-row">
            <div>
              <div className="eyebrow">
                <Sparkles size={14} /> YOUR AUTOMATION COMMAND CENTER
              </div>
              <h1>
                Good to see you <span className="wave">✳</span>
              </h1>
              <p className="page-subtitle">
                Everything you need to build, manage, and monitor your
                automations.
              </p>
            </div>

            <button
              className="primary-button"
              onClick={() => setWorkflowStudioOpen(true)}
            >
              <Plus size={17} /> Create workflow
            </button>
          </section>

          <WebSearchPanel onCreateWorkflow={openWorkflowFromSearch} />
          {liveRun && <section className="live-run-panel"><div className="live-run-heading"><div><span className="live-indicator" /><strong>{liveRun.status === "running" ? "Live execution" : `Last run: ${liveRun.status.replace(/_/g, " ")}`}</strong><small>{liveRun.workflowName || "Workflow"} · {liveRun.source || "manual"}</small></div><button className="text-button" onClick={() => setActiveSection("Run history")}>View history <ArrowRight size={14} /></button></div><div className="live-progress-track"><span style={{ width: `${liveRun.totalSteps ? Math.min(100, liveRun.currentStep / liveRun.totalSteps * 100) : 0}%` }} /></div><div className="live-run-meta"><span>Step {liveRun.currentStep} of {liveRun.totalSteps || "—"}{liveRun.stepLabel ? ` · ${liveRun.stepLabel}` : ""}</span><span>{liveRun.profileId || ""}</span></div>{liveRun.message && <p>{liveRun.message}</p>}</section>}

          <section className="hero-banner">
            <div className="hero-content">
              <div className="hero-badge">
                <span /> YOUR WORKSPACE IS READY
              </div>
              <h2>
                Make the repetitive
                <br />
                feel effortless.
              </h2>
              <p>
                Build visual workflows, manage isolated browser profiles, and
                see every run in one place.
              </p>
              <button
                className="hero-button"
                onClick={() => setWorkflowStudioOpen(true)}
              >
                <Play size={15} fill="currentColor" />
                Explore workflow builder
                <ArrowRight size={15} />
              </button>
            </div>

            <div className="hero-art" aria-hidden="true">
              <div className="orbit orbit-one" />
              <div className="orbit orbit-two" />
              <div className="orbit orbit-three" />
              <div className="art-node node-top">
                <Globe2 size={20} />
              </div>
              <div className="art-node node-left">
                <Workflow size={21} />
              </div>
              <div className="art-node node-right">
                <Cpu size={21} />
              </div>
              <div className="art-node node-bottom">
                <ShieldCheck size={20} />
              </div>
              <div className="art-core">
                <Bot size={39} />
              </div>
              <div className="art-connection connection-one" />
              <div className="art-connection connection-two" />
              <div className="art-connection connection-three" />
            </div>

            <div className="hero-decoration">OK / 01</div>
          </section>

          <section className="stats-grid">
            <article className="stat-card">
              <div className="stat-top">
                <span>Browser profiles</span>
                <div className="stat-icon blue">
                  <Globe2 size={18} />
                </div>
              </div>
              <div className="stat-value">
                {String(browserProfiles.length).padStart(2, "0")}{" "}
                <span className="stat-unit">profiles</span>
              </div>
              <div className="stat-foot">
                <span className="neutral-indicator">
                  <FolderOpen size={13} /> Local browser profiles
                </span>
              </div>
            </article>

            <article className="stat-card">
              <div className="stat-top">
                <span>Saved workflows</span>
                <div className="stat-icon purple">
                  <Workflow size={18} />
                </div>
              </div>
              <div className="stat-value">
                08 <span className="stat-unit">workflows</span>
              </div>
              <div className="stat-foot">
                <span className="neutral-indicator">
                  <CheckCircle2 size={13} /> Ready to configure
                </span>
              </div>
            </article>

            <article className="stat-card">
              <div className="stat-top">
                <span>Successful runs</span>
                <div className="stat-icon green">
                  <CheckCircle2 size={18} />
                </div>
              </div>
              <div className="stat-value">
                24 <span className="stat-unit">runs</span>
              </div>
              <div className="stat-foot">
                <span className="trend-positive">
                  <ArrowUpRight size={14} /> Sample dashboard data
                </span>
              </div>
            </article>

            <article className="stat-card">
              <div className="stat-top">
                <span>Failed runs</span>
                <div className="stat-icon red">
                  <Activity size={18} />
                </div>
              </div>
              <div className="stat-value">
                02 <span className="stat-unit">runs</span>
              </div>
              <div className="stat-foot">
                <span className="trend-neutral">
                  <ArrowDownRight size={14} /> Sample dashboard data
                </span>
              </div>
            </article>
          </section>

          <section className="content-grid">
            <article className="panel workflow-panel">
              <div className="panel-heading">
                <div>
                  <h3>Recent workflows</h3>
                  <p>Your latest automation activity</p>
                </div>
                <button
                  className="text-button"
                  onClick={() => setActiveSection("Run history")}
                >
                  View all <ArrowRight size={15} />
                </button>
              </div>

              <div className="workflow-list">
                {workflows.map(
                  ({ name, description, icon: Icon, color, status, time, duration }) => (
                    <div className="workflow-row" key={name}>
                      <div className={`workflow-icon ${color}`}>
                        <Icon size={18} />
                      </div>
                      <div className="workflow-info">
                        <strong>{name}</strong>
                        <span>{description}</span>
                      </div>
                      <div className="workflow-result">
                        <span className={`run-status ${status === "Completed" ? "completed" : "draft"}`}>
                          {status === "Completed" && <CheckCircle2 size={12} />}
                          {status}
                        </span>
                        <span className="workflow-time">{time}</span>
                      </div>
                      <div className="workflow-duration">{duration}</div>
                    </div>
                  )
                )}
              </div>

              <button
                className="create-row-button"
                onClick={() => setWorkflowStudioOpen(true)}
              >
                <Plus size={16} /> Create a new workflow
              </button>
            </article>
          </section>

          <footer className="page-footer">
            <span>
              <Command size={13} /> AJBOT STUDIO{" "}
              <span className="footer-separator">·</span> DESKTOP WORKSPACE
            </span>
            <span>Built for clarity. Designed for control.</span>
          </footer>
          </>
          )}
        </div>
      </main>

      {workflowStudioOpen && (
        <WorkflowStudio
          profiles={browserProfiles}
          onClose={closeWorkflowStudio}
          onProfilesRefresh={refreshBrowserProfiles}
          initialUrl={workflowStart?.url}
          initialTitle={workflowStart?.title}
          initialTemplate={selectedTemplate ? { name: selectedTemplate.name, steps: selectedTemplate.steps } : undefined}
        />
      )}

      {createDialogOpen && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              closeCreateDialog();
            }
          }}
        >
          <section
            className="profile-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="profile-modal-title"
          >
            <div className="profile-modal-heading">
              <div>
                <h2 id="profile-modal-title">{editingProfileId ? "Edit browser profile" : "Create browser profile"}</h2>
                <p>{editingProfileId ? "Update this profile’s name and starting website." : "Set up a separate browser session."}</p>
              </div>
              <button
                type="button"
                className="icon-button"
                aria-label="Close dialog"
                onClick={closeCreateDialog}
                disabled={creatingProfile}
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreateProfile}>
              <label className="profile-form-label" htmlFor="profile-name">
                Profile name
              </label>
              <input
                id="profile-name"
                className="profile-form-input"
                type="text"
                placeholder="e.g. Research Test"
                value={newProfileName}
                onChange={(event) => setNewProfileName(event.target.value)}
                maxLength={80}
                required
                autoFocus
              />

              <label className="profile-form-label" htmlFor="profile-url">
                Starting website <span>(optional)</span>
              </label>
              <input
                id="profile-url"
                className="profile-form-input"
                type="text"
                placeholder="https://example.com"
                value={newProfileUrl}
                onChange={(event) => setNewProfileUrl(event.target.value)}
              />

              <p className="profile-form-hint">
                The browser will open this website when you launch this
                profile. Leave it blank to use the browser's default page.
              </p>

              {profileFormError && (
                <p className="profile-form-error" role="alert">
                  {profileFormError}
                </p>
              )}

              <div className="profile-modal-actions">
                <button
                  type="button"
                  className="secondary-button"
                  onClick={closeCreateDialog}
                  disabled={creatingProfile}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="primary-button"
                  disabled={creatingProfile}
                >
                  <Plus size={16} />
                  {creatingProfile ? (editingProfileId ? "Saving..." : "Creating...") : (editingProfileId ? "Save changes" : "Create profile")}
                </button>
              </div>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}

export default LegacyWorkspace;