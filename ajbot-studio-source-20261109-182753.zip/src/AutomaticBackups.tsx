
import { useEffect, useState } from "react";
import { invoke } from "./studio/bridge";
import {
  Archive,
  CheckCircle2,
  Clock3,
  FolderOpen,
  HardDrive,
  RefreshCw,
  Save,
  ShieldCheck,
  XCircle,
  AlertCircle,
} from "lucide-react";
import "./AutomaticBackups.css";

type BackupRecord = {
  profileId: string;
  profileName: string;
  status: string;
  message: string;
  backupPath?: string | null;
  createdAt: number;
  bytes?: number | null;
};

type BackupSettings = {
  enabled: boolean;
  schedule: "daily" | "weekly";
  time: string;
  backupDirectory: string;
  retentionCount: number;
};

type BackupResponse = {
  settings: BackupSettings;
  history: BackupRecord[];
  defaultBackupDirectory: string;
};

const defaultSettings: BackupSettings = {
  enabled: false,
  schedule: "daily",
  time: "02:00",
  backupDirectory: "",
  retentionCount: 7,
};

function formatDate(timestamp: number) {
  return new Date(timestamp).toLocaleString();
}

function formatBytes(bytes?: number | null) {
  if (bytes == null) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function statusIcon(status: string) {
  if (status === "success") return <CheckCircle2 size={16} />;
  if (status === "skipped") return <AlertCircle size={16} />;
  return <XCircle size={16} />;
}

export default function AutomaticBackups() {
  const [settings, setSettings] = useState<BackupSettings>(defaultSettings);
  const [history, setHistory] = useState<BackupRecord[]>([]);
  const [defaultDirectory, setDefaultDirectory] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const loadSettings = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await invoke<BackupResponse>(
        "get_automatic_backup_settings",
      );

      setSettings({
        ...defaultSettings,
        ...response.settings,
        backupDirectory:
          response.settings.backupDirectory || response.defaultBackupDirectory,
      });
      setHistory(response.history ?? []);
      setDefaultDirectory(response.defaultBackupDirectory ?? "");
    } catch (err) {
      setError(String(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadSettings();
  }, []);

  const updateSetting = <K extends keyof BackupSettings>(
    key: K,
    value: BackupSettings[K],
  ) => {
    setSettings((current) => ({ ...current, [key]: value }));
  };

  const saveSettings = async () => {
    setSaving(true);
    setError("");
    setMessage("");

    try {
      const response = await invoke<BackupResponse>(
        "save_automatic_backup_settings",
        {
          enabled: settings.enabled,
          schedule: settings.schedule,
          time: settings.time,
          backupDirectory: settings.backupDirectory.trim(),
          retentionCount: settings.retentionCount,
        },
      );

      setSettings({
        ...defaultSettings,
        ...response.settings,
        backupDirectory:
          response.settings.backupDirectory || response.defaultBackupDirectory,
      });
      setHistory(response.history ?? []);
      setDefaultDirectory(response.defaultBackupDirectory ?? "");
      setMessage("Automatic backup settings saved successfully.");
    } catch (err) {
      setError(String(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="automatic-backups-page">
        <div className="automatic-backups-loading">
          <RefreshCw size={20} className="backup-spin" />
          Loading automatic backup settings...
        </div>
      </section>
    );
  }

  return (
    <section className="automatic-backups-page">
      <div className="automatic-backups-heading">
        <div>
          <div className="eyebrow">
            <HardDrive size={14} /> PROFILE PROTECTION
          </div>
          <h1>Automatic backups</h1>
          <p className="page-subtitle">
            Schedule verified backups of your browser profiles, even when
            Ajbot Studio is closed.
          </p>
        </div>

        <button
          className="secondary-button"
          onClick={() => void loadSettings()}
          disabled={saving}
        >
          <RefreshCw size={15} /> Refresh
        </button>
      </div>

      {error && (
        <div className="backup-message backup-message-error">
          <AlertCircle size={17} />
          <span>{error}</span>
        </div>
      )}

      {message && (
        <div className="backup-message backup-message-success">
          <CheckCircle2 size={17} />
          <span>{message}</span>
        </div>
      )}

      <div className="backup-settings-grid">
        <div className="backup-panel backup-main-panel">
          <div className="backup-panel-heading">
            <div className="backup-panel-icon">
              <Archive size={19} />
            </div>
            <div>
              <h2>Backup schedule</h2>
              <p>Choose when Ajbot Studio should protect your profiles.</p>
            </div>
          </div>

          <label className="backup-toggle-row">
            <span>
              <strong>Enable automatic backups</strong>
              <small>
                Runs through Windows Task Scheduler while the app is closed.
              </small>
            </span>
            <input
              type="checkbox"
              checked={settings.enabled}
              onChange={(event) =>
                updateSetting("enabled", event.target.checked)
              }
            />
          </label>

          <div className="backup-form-grid">
            <label className="backup-field">
              <span>Backup frequency</span>
              <select
                value={settings.schedule}
                onChange={(event) =>
                  updateSetting(
                    "schedule",
                    event.target.value as "daily" | "weekly",
                  )
                }
                disabled={!settings.enabled}
              >
                <option value="daily">Every day</option>
                <option value="weekly">Every Monday</option>
              </select>
            </label>

            <label className="backup-field">
              <span>Start time</span>
              <input
                type="time"
                value={settings.time}
                onChange={(event) => updateSetting("time", event.target.value)}
                disabled={!settings.enabled}
              />
            </label>
          </div>

          <div className="backup-info-note">
            <Clock3 size={17} />
            <span>
              The schedule uses your Windows account and local system time.
              Profiles with an active browser session will be skipped.
            </span>
          </div>
        </div>

        <div className="backup-panel">
          <div className="backup-panel-heading">
            <div className="backup-panel-icon">
              <ShieldCheck size={19} />
            </div>
            <div>
              <h2>Storage and retention</h2>
              <p>Control where backups are stored and how many are kept.</p>
            </div>
          </div>

          <label className="backup-field">
            <span>Backup destination folder</span>
            <input
              type="text"
              value={settings.backupDirectory}
              onChange={(event) =>
                updateSetting("backupDirectory", event.target.value)
              }
              placeholder={defaultDirectory || "Choose a backup folder"}
            />
            <small>
              Leave this set to the default folder or enter an absolute
              Windows folder path.
            </small>
          </label>

          <label className="backup-field backup-retention-field">
            <span>Backups to retain per profile</span>
            <input
              type="number"
              min={1}
              max={100}
              value={settings.retentionCount}
              onChange={(event) =>
                updateSetting(
                  "retentionCount",
                  Math.min(100, Math.max(1, Number(event.target.value) || 1)),
                )
              }
            />
            <small>
              Older automatic backups are removed after a new backup has been
              created and verified.
            </small>
          </label>

          <div className="backup-info-note">
            <FolderOpen size={17} />
            <span>
              Each backup is verified after creation. A failed verification
              is recorded in backup history.
            </span>
          </div>
        </div>
      </div>

      <div className="backup-save-row">
        <span>
          {settings.enabled
            ? "Automatic backups are configured to run on schedule."
            : "Automatic backups are currently disabled."}
        </span>
        <button
          className="primary-button"
          onClick={() => void saveSettings()}
          disabled={saving}
        >
          <Save size={16} />
          {saving ? "Saving..." : "Save backup settings"}
        </button>
      </div>

      <div className="backup-panel backup-history-panel">
        <div className="backup-history-heading">
          <div>
            <h2>Backup history</h2>
            <p>Recent automatic backup results.</p>
          </div>
          <span className="backup-history-count">{history.length} records</span>
        </div>

        {history.length === 0 ? (
          <div className="backup-empty-state">
            <Archive size={25} />
            <strong>No automatic backups yet</strong>
            <span>
              Backup results will appear here after the scheduled task runs.
            </span>
          </div>
        ) : (
          <div className="backup-history-list">
            {history.map((record, index) => (
              <div
                className="backup-history-item"
                key={`${record.profileId}-${record.createdAt}-${index}`}
              >
                <div
                  className={`backup-status-icon backup-status-${record.status}`}
                >
                  {statusIcon(record.status)}
                </div>
                <div className="backup-history-details">
                  <strong>{record.profileName || record.profileId}</strong>
                  <span>{record.message}</span>
                  <small>{formatDate(record.createdAt)}</small>
                  {record.backupPath && (
                    <code title={record.backupPath}>{record.backupPath}</code>
                  )}
                </div>
                <div className="backup-history-meta">
                  <span>{record.status}</span>
                  <small>{formatBytes(record.bytes)}</small>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
