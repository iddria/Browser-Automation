import { useCallback, useEffect, useState } from 'react';
import { Activity, Bot, Boxes, ChevronLeft, Coins, DatabaseBackup, Flame, Handshake, HelpCircle, KeyRound, LayoutDashboard, Menu, Monitor, Moon, Network, Plus, Search, Settings, Sparkles, Store, Sun, Workflow, X, Zap } from 'lucide-react';
import WorkflowStudio from './WorkflowStudio';
import ProxyManagement from './ProxyManagement';
import Scheduler from './Scheduler';
import CanvasEditor from './studio/CanvasEditor';
import LiveAgentDialog from './studio/LiveAgentDialog';
import QaWorkspace from './studio/QaWorkspace';
import { Warmers, Swarmers, flowDraft } from './studio/WorkflowLibrary';
import { StudioNavIcon } from './studio/StudioNavIcon';
import { AccessDialog, BackupPage, EarnMode, Empty, Handover, Machines, PageHeading, ProviderKeys, SettingsPage } from './studio/AccountPages';
import { Overview, Pods, Sessions, SoloMode } from './studio/WorkspacePages';
import { desktop, invoke, listen } from './studio/bridge';
import { type Flow, type Pod, type Profile, type Session, downloadJson, normalizeStepActions, useStored } from './studio/model';
import { defaultCapacity, normalizeCapacity } from './studio/capacity';
import logo from './assets/ajbot-logo.png';
import { type LiveRun, type RunProgress, type RunRecord } from './studio/RunHistory';
import './App.css';
import './studio/Reference.css';

const groups = [
  { label: '', items: [['Overview', LayoutDashboard], ['Sessions', Activity], ['Solo Mode', Monitor]] },
  { label: 'ASSETS', items: [['Pods', Boxes], ['Proxies', Network], ['Machines', Monitor]] },
  { label: 'WORKFLOWS', items: [['Warmers', Flame], ['Swarmers', Workflow], ['Custom', Workflow], ['QA workspace', Activity], ['Store', Store]] },
  { label: 'EARN', items: [['Earn Mode', Coins]] },
  { label: 'ACCOUNT', items: [['Provider Keys', KeyRound], ['Backup', DatabaseBackup], ['Handover', Handshake], ['Settings', Settings], ['Help & support', HelpCircle]] },
] as const;
export default function App() {
  const [section, setSection] = useState(() => new URLSearchParams(window.location.search).has('qa') ? 'QA workspace' : 'Overview'); const [navOpen, setNavOpen] = useState(false); const [compact, setCompact] = useStored('compact-navigation', false); const [theme, setTheme] = useStored('theme', 'dark');
  const [pods, setPods] = useStored<Pod[]>('pods', []); const [sessions, setSessions] = useStored<Session[]>('sessions', []);
  const [storedCapacity, setCapacity] = useStored('capacity', defaultCapacity);
  const capacity = normalizeCapacity(storedCapacity);
  const [profiles, setProfiles] = useState<Profile[]>([]); const [workflows, setWorkflows] = useState<Flow[]>([]); const [history, setHistory] = useState<RunRecord[]>([]);
  const [liveRuns, setLiveRuns] = useState<Record<string, LiveRun>>({});
  const [agentOpen, setAgentOpen] = useState(false);
  const [canvasKey, setCanvasKey] = useState(0);
  const [notice, setNotice] = useState(''); const [advanced, setAdvanced] = useState(false); const [access, setAccess] = useState(false); const [assistant, setAssistant] = useState(false); const [assistantText, setAssistantText] = useState('');
  const refresh = useCallback(async () => { try { const [p,w,h] = await Promise.all([invoke<Profile[]>('list_browser_profiles'), invoke<Flow[]>('list_browser_workflows'), invoke<RunRecord[]>('list_run_history')]); setProfiles(p); setWorkflows(w); setHistory(h); } catch(e) { setNotice(String(e)); } }, []);
  useEffect(() => {
    void refresh();
    const unsubscribe = listen<RunProgress>('workflow-progress', ({ payload }) => {
      if ('run' in payload) {
        if (payload.type === 'run_started') setLiveRuns(current => ({ ...current, [payload.run.id]: payload.run }));
        else setLiveRuns(current => {
          const next = { ...current };
          delete next[payload.run.id];
          return next;
        });
        void refresh();
      } else {
        const { runId, currentStep, totalSteps, step } = payload;
        setLiveRuns(current => current[runId] ? {
          ...current, [runId]: { ...current[runId], currentStep, totalSteps, currentAction: step?.action },
        } : current);
      }
    });
    return () => { void unsubscribe.then(unlisten => unlisten()); };
  }, [refresh]);
  useEffect(() => { document.documentElement.dataset.ajTheme = theme; }, [theme]);
  useEffect(() => { const handler = (e: KeyboardEvent) => { if(e.key === 'Escape') { setAccess(false); setAssistant(false); setNavOpen(false); } }; window.addEventListener('keydown',handler); return () => window.removeEventListener('keydown',handler); }, []);
  const [podRequest, setPodRequest] = useState<{ podId: string; id: string } | null>(null);
  const openFlow = (w: Flow) => { localStorage.setItem('ajbot-studio-canvas', JSON.stringify(flowDraft(w))); setCanvasKey(k => k + 1); setSection('Custom'); };
  const go = (next: string) => { setSection(next); setNotice(''); setNavOpen(false); void refresh(); };
  const activeSection = section === 'Scheduler' ? 'Sessions' : section;
  const openDraft = (flow: Flow) => {
    if (window.confirm('Open this as a draft in Custom? Unsaved changes in the current canvas will be replaced.')) openFlow(flow);
  };
  const runningProfileCount = profiles.filter(p => p.running).length;
  const profileActivityPercent = profiles.length ? runningProfileCount / profiles.length * 100 : 0;
  const exportWorkspace = () => downloadJson('ajbot-workspace-definitions.json', { format: 'ajbot-workspace', version: 1, exportedAt: new Date().toISOString(), pods, sessions, workflows, capacity });
  return <div className={`aj-shell ${compact ? 'compact' : ''}`}>
    <button className="aj-mobile-menu" aria-label="Open navigation" onClick={() => setNavOpen(v => !v)}><Menu size={20} /></button>
    {navOpen && <div className="aj-nav-overlay" onClick={() => setNavOpen(false)} />}
    <aside className={`aj-sidebar ${navOpen ? 'open' : ''}`}><div className="aj-brand"><img src={logo} alt="AJBOT Studio" /><strong>AJBOT<span>STUDIO</span></strong><button aria-label="Collapse navigation" onClick={() => setCompact(v => !v)}><ChevronLeft size={15} /></button></div>
      <nav aria-label="Main navigation">{groups.map(g => <div className="aj-nav-group" key={g.label}>{g.label && <h2>{g.label}</h2>}{g.items.map(([name]) => <button key={name} title={name} aria-label={name} aria-current={activeSection === name ? 'page' : undefined} className={`aj-nav-item ${activeSection === name ? 'selected' : ''}`} onClick={() => go(name)}><StudioNavIcon name={name} /><span>{name}</span></button>)}</div>)}</nav>
      <div className="aj-sidebar-footer"><button className="aj-access-card" onClick={() => setAccess(true)}><span><Zap size={14} /> Educational Access <small>{profiles.filter(p => p.running).length} live</small></span><i><b style={{ width: `${profileActivityPercent}%` }} /></i><strong>View workspace access <ChevronLeft size={12} /></strong></button><button className="aj-user" onClick={() => go('Settings')}><span>I</span><div><strong>Workspace owner</strong><small>{desktop ? 'Local desktop' : 'Browser preview'}</small></div><Settings size={15} /></button></div>
    </aside>
    <main className={`aj-main ${section === 'Custom' ? 'canvas-mode' : ''}`}>
      {!desktop && section !== 'QA workspace' && <div className="aj-preview-label">Browser preview · Local drafts · Run automations in the desktop app</div>}
      {notice && <div className="aj-global-notice" role="status"><span>{notice}</span><button aria-label="Dismiss notice" onClick={() => setNotice('')}><X size={15} /></button></div>}
      <div className="aj-page">
        {section === 'Overview' && <Overview sessions={sessions} pods={pods} workflows={workflows} refresh={refresh} history={history} liveRuns={Object.values(liveRuns)} openDraft={openDraft} />}
        {activeSection === 'Sessions' && <div className="aj-segment aj-section-tabs" role="group" aria-label="Session tools">
          <button className={section === 'Sessions' ? 'selected' : ''} aria-pressed={section === 'Sessions'} onClick={() => go('Sessions')}>Sessions</button>
          <button className={section === 'Scheduler' ? 'selected' : ''} aria-pressed={section === 'Scheduler'} onClick={() => go('Scheduler')}>Scheduler</button>
        </div>}
        <div hidden={section !== 'Sessions'}><Sessions capacity={capacity} sessions={sessions} setSessions={setSessions} pods={pods} profiles={profiles} workflows={workflows} refresh={refresh} notify={setNotice} podRequest={podRequest} /></div>
        {section === 'Pods' && <Pods capacity={capacity} pods={pods} setPods={setPods} profiles={profiles} workflows={workflows} refresh={refresh} notify={setNotice} runPod={podId => { setPodRequest({ podId, id: crypto.randomUUID() }); go('Sessions'); }} />}
        <div hidden={section !== 'Solo Mode'}><SoloMode pods={pods} profiles={profiles} refresh={refresh} notify={setNotice} openDraft={openDraft} /></div>
        {section === 'Proxies' && <ProxyManagement profiles={profiles} />}
        {section === 'Machines' && <Machines />}
        {section === 'Warmers' && <Warmers openFlow={openFlow} workflows={workflows} saved={() => void refresh()} notify={setNotice} />}
        {section === 'Swarmers' && <Swarmers openFlow={openFlow} workflows={workflows} saved={() => void refresh()} notify={setNotice} />}
        {section === 'Custom' && <CanvasEditor key={canvasKey} onRunAgent={() => setAgentOpen(true)} workflows={workflows} onAdvanced={() => setAdvanced(true)} onSaved={() => void refresh()} />}
        {section === 'QA workspace' && <QaWorkspace workflows={workflows} />}
        {section === 'Store' && <WorkflowStore workflows={workflows} openAdvanced={() => setAdvanced(true)} />}
        {section === 'Earn Mode' && <EarnMode pods={pods} profiles={profiles} />}
        {section === 'Provider Keys' && <ProviderKeys />}
        {section === 'Backup' && <BackupPage openProfiles={() => go('Solo Mode')} refresh={refresh} exportWorkspace={exportWorkspace} />}
        {section === 'Handover' && <Handover pods={pods} sessions={sessions} workflows={workflows} onImport={(newPods, newSessions) => { setPods([...pods,...newPods]); setSessions([...sessions,...newSessions]); void refresh(); }} />}
        {section === 'Scheduler' && <Scheduler profiles={profiles} />}
        {section === 'Settings' && <SettingsPage capacity={capacity} onCapacityChange={setCapacity} />}
        {section === 'Help & support' && <Help />}
      </div>
    </main>
    <div className="aj-floating-tools"><button className="aj-theme-button" aria-label="Toggle color theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? <Sun size={21} /> : <Moon size={21} />}</button><button className="aj-bot-button" aria-label="Open assistant" onClick={() => setAssistant(v => !v)}><Bot size={23} /></button></div>
    {assistant && <section className="aj-assistant" role="dialog" aria-labelledby="assistant-title"><header><h3 id="assistant-title"><Bot size={18} /> AJBOT Assistant</h3><button aria-label="Close assistant" onClick={() => setAssistant(false)}><X size={16} /></button></header><p>Describe a browser task to open it in the AI planner. You’ll review the draft before running it.</p><textarea aria-label="Assistant task" value={assistantText} onChange={e => setAssistantText(e.target.value)} placeholder="Open a website and inspect its page…" /><button className="aj-button primary" disabled={!assistantText.trim()} onClick={() => { sessionStorage.setItem('ajbot-planner-prompt', assistantText); setAssistant(false); setAdvanced(true); }}><Sparkles size={15} /> Open in AI planner</button></section>}
    <LiveAgentDialog open={agentOpen} profiles={profiles} onClose={() => setAgentOpen(false)} onOpen={() => setAgentOpen(true)} />
    {advanced && <WorkflowStudio profiles={profiles} onClose={() => { setAdvanced(false); void refresh(); }} onProfilesRefresh={refresh} />}
    {access && <AccessDialog close={() => setAccess(false)} />}
  </div>;
}
function WorkflowStore({ workflows, openAdvanced }: { workflows: Flow[]; openAdvanced: () => void }) {
  const [search, setSearch] = useState('');
  return <><PageHeading title="Workflow store" description="Browse your saved workflows and publish portable workflow files for educational sharing."><button className="aj-button" onClick={openAdvanced}><Plus size={15} /> Import a workflow</button></PageHeading><label className="aj-search aj-store-search"><Search size={16} /><input placeholder="Search the store…" aria-label="Search workflow store" value={search} onChange={e => setSearch(e.target.value)} /></label><section className="aj-card">{workflows.length ? workflows.filter(w => w.name.toLowerCase().includes(search.toLowerCase())).map(w => <div className="aj-activity-row" key={w.id}><Workflow size={18} /><strong>{w.name}</strong><small>{w.steps.length} steps</small><button className="aj-button small" onClick={() => downloadJson(`${w.id}.ajbot-workflow.json`, { format: 'ajbot-workflow', version: 1, workflow: { name: w.name, steps: normalizeStepActions(w.steps) } })}>Publish as file</button></div>) : <Empty icon={<Store size={28} />} title="Nothing in the store yet" description="Install a learning template or save a custom workflow. A remote marketplace has not been configured." />}</section></>;
}
function Help() {
  return <><PageHeading title="Help & support" description="Getting started with AJBOT STUDIO." /><section className="aj-card"><h3>Build your first session</h3><ol><li>Create a Pod or group your existing browser profiles.</li><li>Install a Warmer template, generate a Swarmer inspection draft, or build a Custom workflow.</li><li>Create a Session and select its pod and saved workflow.</li><li>Review its actions, then run it in the desktop app.</li></ol><h3>Find workspace tools</h3><p>Overview has activity, detailed run history, and Web search. Use Solo Mode for profiles and recording, Sessions for Scheduler, Custom Workflows for templates, and Backup for profile archives and automatic backups.</p><h3>Provider keys</h3><p>Keys for all six cloud text providers can be stored using Windows account encryption. Ollama runs locally. Refresh provider models to load available choices. Voice API adapters remain configuration only.</p><h3>Educational service screens</h3><p>Machine registration, Earn Mode, access, and file handover run locally. Paid jobs, wallets, remote rental, license servers, and a public workflow marketplace require a backend. Vision-driven control and automated security-challenge solving are not implemented.</p><h3>Browser preview</h3><p>In a normal web browser, configuration and workflow drafts are stored locally. Browser execution, profile archives, and scheduling require the desktop app.</p></section></>;
}
