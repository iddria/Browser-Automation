import { useEffect, useRef, useState } from "react";
import { invoke } from "./studio/bridge";
import {
  Network,
  Plus,
  Trash2,
  Pencil,
  RefreshCw,
  Upload,
  Download,
  ShieldCheck,
  Globe2,
  LockKeyhole,
  Users,
  X,
} from "lucide-react";
import "./ProxyManagement.css";

type ProxyRecord = {
  id: string;
  name: string;
  server: string;
  username: string;
  hasPassword: boolean;
};

type BrowserProfile = {
  id: string;
  name?: string;
  startUrl?: string | null;
  running: boolean;
};

type Props = {
  profiles: BrowserProfile[];
};

type ProxyGroupFile = {
  format: "ajbot-proxy-group";
  version: 1;
  proxies: Array<{
    name: string;
    server: string;
    username?: string | null;
    password?: string | null;
  }>;
};

const createId = () =>
  `proxy-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

function validateServer(value: string) {
  let parsed: URL;

  try {
    parsed = new URL(value.trim());
  } catch {
    throw new Error("Enter a valid proxy server address.");
  }

  if (!["http:", "https:", "socks5:"].includes(parsed.protocol)) {
    throw new Error("Only HTTP, HTTPS, and SOCKS5 proxies are supported.");
  }

  if (!parsed.hostname) {
    throw new Error("The proxy server must include a hostname.");
  }

  return value.trim();
}

export default function ProxyManagement({ profiles }: Props) {
  const [proxies, setProxies] = useState<ProxyRecord[]>([]);
  const [assignments, setAssignments] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [activeTab, setActiveTab] = useState<"manual" | "bulk">("manual");

  const [editingProxy, setEditingProxy] = useState<ProxyRecord | null>(null);
  const [proxyName, setProxyName] = useState("");
  const [proxyServer, setProxyServer] = useState("");
  const [proxyUsername, setProxyUsername] = useState("");
  const [proxyPassword, setProxyPassword] = useState("");
  const [bulkText, setBulkText] = useState("");

  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [assignmentBusy, setAssignmentBusy] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const refreshData = async () => {
    setLoading(true);
    setError("");

    try {
      const records = await invoke<ProxyRecord[]>("list_proxies");
      setProxies(records);

      const entries = await Promise.all(
        profiles.map(async (profile) => {
          const proxyId = await invoke<string | null>("get_profile_proxy", {
            profileId: profile.id,
          });

          return [profile.id, proxyId || ""] as const;
        })
      );

      setAssignments(Object.fromEntries(entries));
    } catch (err) {
      setError(`Could not load proxy information: ${String(err)}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void refreshData();
  }, [profiles]);

  const resetForm = () => {
    setEditingProxy(null);
    setProxyName("");
    setProxyServer("");
    setProxyUsername("");
    setProxyPassword("");
    setError("");
  };

  const handleEdit = (proxy: ProxyRecord) => {
    setEditingProxy(proxy);
    setProxyName(proxy.name);
    setProxyServer(proxy.server);
    setProxyUsername(proxy.username || "");
    setProxyPassword("");
    setActiveTab("manual");
    setError("");
    setMessage("");
  };

  const handleSave = async () => {
    setError("");
    setMessage("");

    const name = proxyName.trim();

    if (!name) {
      setError("Enter a name for this proxy.");
      return;
    }

    let server: string;

    try {
      server = validateServer(proxyServer);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      return;
    }

    setSaving(true);

    try {
      await invoke("save_proxy", {
        id: editingProxy?.id || createId(),
        name,
        server,
        username: proxyUsername.trim() || null,
        password: proxyPassword || null,
      });

      resetForm();
      setMessage(editingProxy ? "Proxy updated successfully." : "Proxy added successfully.");
      await refreshData();
    } catch (err) {
      setError(`Could not save proxy: ${String(err)}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (proxy: ProxyRecord) => {
    const confirmed = window.confirm(
      `Delete proxy "${proxy.name}"?\n\nAny browser profiles assigned to this proxy will be unassigned.`
    );

    if (!confirmed) return;

    setError("");
    setMessage("");

    try {
      await invoke("delete_proxy", { id: proxy.id });

      if (editingProxy?.id === proxy.id) {
        resetForm();
      }

      setMessage("Proxy deleted.");
      await refreshData();
    } catch (err) {
      setError(`Could not delete proxy: ${String(err)}`);
    }
  };

  const handleAssignment = async (profileId: string, proxyId: string) => {
    setAssignmentBusy(profileId);
    setError("");
    setMessage("");

    try {
      await invoke("assign_proxy_to_profile", {
        profileId,
        proxyId: proxyId || null,
      });

      setAssignments((current) => ({
        ...current,
        [profileId]: proxyId,
      }));

      setMessage(
        proxyId
          ? "Proxy assignment saved. It will be used the next time this profile launches."
          : "Proxy removed from this browser profile."
      );
    } catch (err) {
      setError(`Could not update profile assignment: ${String(err)}`);
    } finally {
      setAssignmentBusy(null);
    }
  };

  const handleBulkImport = async () => {
    setError("");
    setMessage("");

    const lines = bulkText
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);

    if (!lines.length) {
      setError("Enter at least one proxy.");
      return;
    }

    const parsed: Array<{
      name: string;
      server: string;
      username: string | null;
      password: string | null;
    }> = [];

    try {
      for (let index = 0; index < lines.length; index++) {
        const fields = lines[index].split("|").map((field) => field.trim());

        if (fields.length < 2 || fields.length > 4) {
          throw new Error(
            `Line ${index + 1}: use name|server|username|password.`
          );
        }

        const [name, rawServer, username = "", password = ""] = fields;

        if (!name || !rawServer) {
          throw new Error(`Line ${index + 1}: name and server are required.`);
        }

        parsed.push({
          name,
          server: validateServer(rawServer),
          username: username || null,
          password: password || null,
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      return;
    }

    setSaving(true);

    let imported = 0;

    try {
      for (const item of parsed) {
        await invoke("save_proxy", {
          id: createId(),
          name: item.name,
          server: item.server,
          username: item.username,
          password: item.password,
        });

        imported++;
      }

      setBulkText("");
      setMessage(`${imported} proxy/proxies added successfully.`);
      await refreshData();
    } catch (err) {
      setError(
        `${imported} of ${parsed.length} proxies were imported. Import stopped: ${String(err)}`
      );
      await refreshData();
    } finally {
      setSaving(false);
    }
  };

  const handleSaveGroup = () => {
    const group: ProxyGroupFile = {
      format: "ajbot-proxy-group",
      version: 1,
      proxies: proxies.map((proxy) => ({
        name: proxy.name,
        server: proxy.server,
        username: proxy.username || null,
      })),
    };

    const blob = new Blob([JSON.stringify(group, null, 2)], {
      type: "application/json",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "ajbot-proxies.json";
    link.click();

    URL.revokeObjectURL(url);

    setMessage("Proxy group exported. Passwords are not included in the export.");
  };

  const handleLoadGroup = async (file?: File) => {
    if (!file) return;

    setError("");
    setMessage("");

    try {
      if (file.size > 1024 * 1024) {
        throw new Error("The proxy group file must be smaller than 1 MB.");
      }

      const data = JSON.parse(await file.text()) as ProxyGroupFile;

      if (
        data.format !== "ajbot-proxy-group" ||
        data.version !== 1 ||
        !Array.isArray(data.proxies)
      ) {
        throw new Error("This is not a valid Ajbot proxy group file.");
      }

      setSaving(true);

      let imported = 0;

      try {
        for (const proxy of data.proxies) {
          if (!proxy.name?.trim() || !proxy.server?.trim()) {
            throw new Error("Every imported proxy needs a name and server.");
          }

          await invoke("save_proxy", {
            id: createId(),
            name: proxy.name.trim(),
            server: validateServer(proxy.server),
            username: proxy.username?.trim() || null,
            password: proxy.password || null,
          });

          imported++;
        }

        setMessage(`${imported} proxy/proxies loaded successfully.`);
      } catch (err) {
        setError(
          `${imported} of ${data.proxies.length} proxies loaded. Import stopped: ${String(err)}`
        );
      }

      await refreshData();
    } catch (err) {
      setError(`Could not load proxy group: ${String(err)}`);
    } finally {
      setSaving(false);

      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  return (
    <section className="proxy-page">
      <div className="proxy-page-heading">
        <div>
          <div className="eyebrow">
            <Network size={14} /> CONNECTION CONFIGURATION
          </div>
          <h1>Proxy Management</h1>
          <p className="page-subtitle">
            Manage proxy servers and assign them to your browser profiles.
          </p>
        </div>

        <button
          className="secondary-button"
          onClick={() => void refreshData()}
          disabled={loading}
        >
          <RefreshCw size={15} />
          {loading ? "Refreshing..." : "Refresh"}
        </button>
      </div>

      {error && (
        <div className="proxy-message proxy-error" role="alert">
          <X size={16} />
          {error}
        </div>
      )}

      {message && (
        <div className="proxy-message proxy-success" role="status">
          <ShieldCheck size={16} />
          {message}
        </div>
      )}

      <div className="proxy-layout">
        <section className="proxy-panel proxy-editor-panel">
          <div className="proxy-panel-heading">
            <div>
              <h2>Proxy Details</h2>
              <p>Add a proxy server to your local proxy list.</p>
            </div>
            <Network size={20} />
          </div>

          <div className="proxy-tabs">
            <button
              className={activeTab === "manual" ? "active" : ""}
              onClick={() => {
                setActiveTab("manual");
                setError("");
              }}
            >
              Manual Entry
            </button>
            <button
              className={activeTab === "bulk" ? "active" : ""}
              onClick={() => {
                setActiveTab("bulk");
                setError("");
              }}
            >
              Bulk Import
            </button>
          </div>

          {activeTab === "manual" ? (
            <div className="proxy-form">
              <label htmlFor="proxy-name">Proxy name</label>
              <input
                id="proxy-name"
                value={proxyName}
                onChange={(event) => setProxyName(event.target.value)}
                placeholder="e.g. Office Proxy"
                maxLength={80}
              />

              <label htmlFor="proxy-server">Proxy server</label>
              <input
                id="proxy-server"
                value={proxyServer}
                onChange={(event) => setProxyServer(event.target.value)}
                placeholder="http://127.0.0.1:8080"
                autoComplete="off"
              />
              <small>Supported protocols: HTTP, HTTPS and SOCKS5.</small>

              <label htmlFor="proxy-username">Username <span>(optional)</span></label>
              <input
                id="proxy-username"
                value={proxyUsername}
                onChange={(event) => setProxyUsername(event.target.value)}
                placeholder="Proxy username"
                autoComplete="off"
              />

              <label htmlFor="proxy-password">Password <span>(optional)</span></label>
              <input
                id="proxy-password"
                type="password"
                value={proxyPassword}
                onChange={(event) => setProxyPassword(event.target.value)}
                placeholder={
                  editingProxy?.hasPassword
                    ? "Leave blank to keep the existing password"
                    : "Proxy password"
                }
                autoComplete="new-password"
              />

              <div className="proxy-form-actions">
                {editingProxy && (
                  <button
                    className="secondary-button"
                    onClick={resetForm}
                    type="button"
                  >
                    Cancel edit
                  </button>
                )}

                <button
                  className="primary-button"
                  onClick={() => void handleSave()}
                  disabled={saving}
                  type="button"
                >
                  <Plus size={16} />
                  {saving
                    ? "Saving..."
                    : editingProxy
                      ? "Save Changes"
                      : "Add to Proxy List"}
                </button>
              </div>
            </div>
          ) : (
            <div className="proxy-form">
              <label htmlFor="proxy-bulk">Proxy entries</label>
              <textarea
                id="proxy-bulk"
                value={bulkText}
                onChange={(event) => setBulkText(event.target.value)}
                placeholder={
                  "Office Proxy|http://127.0.0.1:8080|username|password\nResearch Proxy|socks5://127.0.0.1:1080"
                }
                rows={8}
              />

              <small>
                One proxy per line. Format: name|server|username|password.
                Username and password are optional. Do not use the | character
                inside a field.
              </small>

              <button
                className="primary-button"
                onClick={() => void handleBulkImport()}
                disabled={saving}
                type="button"
              >
                <Upload size={16} />
                {saving ? "Importing..." : "Import Proxies"}
              </button>
            </div>
          )}

          <div className="proxy-security-note">
            <LockKeyhole size={16} />
            <span>
              Proxy passwords are protected using Windows user-level encryption.
              They are not displayed in the proxy list.
            </span>
          </div>
        </section>

        <section className="proxy-panel proxy-list-panel">
          <div className="proxy-panel-heading">
            <div>
              <h2>Proxy List</h2>
              <p>Your saved proxy servers.</p>
            </div>
            <span className="proxy-count">{proxies.length}</span>
          </div>

          {loading && proxies.length === 0 ? (
            <div className="proxy-empty-state">
              <RefreshCw size={25} />
              <strong>Loading proxies...</strong>
            </div>
          ) : proxies.length === 0 ? (
            <div className="proxy-empty-state">
              <Network size={30} />
              <strong>No proxies yet.</strong>
              <span>Add them manually or in bulk.</span>
            </div>
          ) : (
            <div className="proxy-list">
              {proxies.map((proxy) => (
                <article className="proxy-list-item" key={proxy.id}>
                  <div className="proxy-list-icon">
                    <Globe2 size={19} />
                  </div>

                  <div className="proxy-list-info">
                    <strong>{proxy.name}</strong>
                    <span>{proxy.server}</span>
                    <small>
                      {proxy.username ? `User: ${proxy.username}` : "No username"}
                      {proxy.hasPassword ? " · Password saved" : ""}
                    </small>
                  </div>

                  <div className="proxy-list-actions">
                    <button
                      className="proxy-icon-button"
                      title="Edit proxy"
                      aria-label={`Edit ${proxy.name}`}
                      onClick={() => handleEdit(proxy)}
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      className="proxy-icon-button danger"
                      title="Delete proxy"
                      aria-label={`Delete ${proxy.name}`}
                      onClick={() => void handleDelete(proxy)}
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}

          <div className="proxy-group-actions">
            <button
              className="secondary-button"
              onClick={() => fileInputRef.current?.click()}
              disabled={saving}
            >
              <Upload size={15} /> Load Group
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              hidden
              onChange={(event) =>
                void handleLoadGroup(event.target.files?.[0])
              }
            />

            <button
              className="secondary-button"
              onClick={handleSaveGroup}
              disabled={proxies.length === 0}
            >
              <Download size={15} /> Save Proxies
            </button>
          </div>
          <p className="proxy-export-note">
            Group exports contain proxy addresses and usernames, but never passwords.
          </p>
        </section>
      </div>

      <section className="proxy-panel proxy-assignments-panel">
        <div className="proxy-panel-heading">
          <div>
            <h2>Browser Profile Assignments</h2>
            <p>
              Choose which proxy each browser profile should use. A proxy can
              be shared between profiles.
            </p>
          </div>
          <Users size={21} />
        </div>

        {profiles.length === 0 ? (
          <div className="proxy-empty-state compact">
            <Globe2 size={25} />
            <strong>No browser profiles available.</strong>
            <span>Create a browser profile before assigning a proxy.</span>
          </div>
        ) : (
          <div className="proxy-assignment-list">
            {profiles.map((profile) => (
              <div className="proxy-assignment-row" key={profile.id}>
                <div className="proxy-assignment-profile">
                  <Globe2 size={18} />
                  <div>
                    <strong>{profile.name || "Untitled profile"}</strong>
                    <small>{profile.id}</small>
                  </div>
                </div>

                <div className="proxy-assignment-control">
                  <select
                    value={assignments[profile.id] || ""}
                    disabled={profile.running || assignmentBusy === profile.id || loading}
                    onChange={(event) =>
                      void handleAssignment(profile.id, event.target.value)
                    }
                    aria-label={`Proxy for ${profile.name || profile.id}`}
                  >
                    <option value="">No proxy</option>
                    {proxies.map((proxy) => (
                      <option key={proxy.id} value={proxy.id}>
                        {proxy.name} — {proxy.server}
                      </option>
                    ))}
                  </select>

                  {profile.running && (
                    <small>Stop browser to change assignment</small>
                  )}
                  {assignmentBusy === profile.id && (
                    <small>Saving assignment...</small>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </section>
  );
}