'use strict';

const { createServer } = require('node:http');
const { homedir } = require('node:os');
const { createReadStream, existsSync, statSync } = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const { createQaWorkspace } = require('../browser-worker/qa-workspace.cjs');
const { askPlanner } = require('../browser-worker/planner-providers.cjs');

const providerVariables = {
  openai: 'OPENAI_API_KEY', anthropic: 'ANTHROPIC_API_KEY', gemini: 'GEMINI_API_KEY',
  openrouter: 'OPENROUTER_API_KEY', deepseek: 'DEEPSEEK_API_KEY', grok: 'XAI_API_KEY',
};
const mime = {
  '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.html': 'text/html; charset=utf-8',
};

function sendJson(response, status, body) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  response.end(JSON.stringify(body));
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 65536) throw new Error('Request exceeds 64 KB.');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function startQaServer({
  port = 4173,
  directory = path.join(homedir(), '.ajbot-studio', 'qa-web'),
  dist = path.join(__dirname, '..', 'dist'),
  launchOptions = {},
  ask = askPlanner,
} = {}) {
  if (!existsSync(path.join(dist, 'index.html'))) throw new Error('Run npm run build before starting the QA server.');
  let workspace;
  const server = createServer(async (request, response) => {
    const address = server.address();
    const host = `127.0.0.1:${address.port}`;
    const origin = `http://${host}`;
    if (request.headers.host !== host) return sendJson(response, 403, { error: `Use ${origin}.` });
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'no-referrer');
    response.setHeader('X-Frame-Options', 'DENY');
    response.setHeader('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'");

    if (request.url === '/api/qa') {
      if (request.method !== 'POST') return sendJson(response, 405, { error: 'Use POST.' });
      if (request.headers.origin !== origin || request.headers['x-ajbot-qa'] !== '1') {
        return sendJson(response, 403, { error: 'Open the workspace from the local QA server.' });
      }
      if (!/^application\/json(?:;|$)/i.test(request.headers['content-type'] || '')) {
        return sendJson(response, 415, { error: 'Use application/json.' });
      }
      try {
        const { operation, input } = await readJson(request);
        if (typeof operation !== 'string' || !input || typeof input !== 'object' || Array.isArray(input)) {
          throw new Error('Send a QA operation and an input object.');
        }
        const keyVariable = ['draft', 'models', 'explainRun'].includes(operation) && Object.hasOwn(providerVariables, input.provider)
          ? providerVariables[input.provider] : undefined;
        workspace ||= createQaWorkspace({
          directory, chromium, launchOptions, ask,
          blockedOrigins: [origin, `http://localhost:${address.port}`, `http://[::1]:${address.port}`],
        });
        const data = await workspace.command(operation, input, keyVariable ? process.env[keyVariable] : undefined);
        return sendJson(response, 200, { data });
      } catch (error) {
        return sendJson(response, 400, { error: String(error.message).slice(0, 500) });
      }
    }

    const pathname = request.url.split('?')[0];
    const relative = pathname === '/' ? 'index.html' : pathname.slice(1);
    if (!['GET', 'HEAD'].includes(request.method) || !/^(?:index\.html|assets\/[\w.-]+|[\w-]+\.(?:svg|png|ico))$/.test(relative)) {
      return sendJson(response, 404, { error: 'Page not found.' });
    }
    const filename = path.join(dist, relative);
    if (!existsSync(filename) || !statSync(filename).isFile()) return sendJson(response, 404, { error: 'File not found.' });
    response.writeHead(200, {
      'Content-Type': mime[path.extname(filename)] || 'application/octet-stream',
      'Cache-Control': relative.startsWith('assets/') ? 'public, max-age=86400' : 'no-cache',
    });
    if (request.method === 'HEAD') return response.end();
    const stream = createReadStream(filename);
    stream.on('error', () => response.destroy());
    stream.pipe(response);
  });

  return {
    server,
    listen: () => new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, '127.0.0.1', () => resolve(`http://127.0.0.1:${server.address().port}`));
    }),
    close: async () => {
      await workspace?.close();
      if (server.listening) await new Promise(resolve => server.close(resolve));
    },
  };
}

if (require.main === module) {
  const runtime = startQaServer({ port: Number(process.env.AJBOT_QA_PORT || 4173) });
  runtime.listen().then(url => console.log(`AJBOT Studio QA is available at ${url}/?qa=1`)).catch(error => {
    console.error(error.message);
    process.exitCode = 1;
  });
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => { void runtime.close(); });
}

module.exports = { startQaServer };
