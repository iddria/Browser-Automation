# AJBOT STUDIO — video-reference update

Prepared 8 November 2026 from the uploaded source ZIP and 3 minute 52 second video.

## What changed

The main workspace now follows the reference's navy canvas, blue buttons, slim grouped navigation, outlined cards, session grid, centered analytics panel, profile table, workflow library, canvas editor and floating theme/assistant controls. AJBOT STUDIO's existing logo, application identity, browser engine and data files are retained.

The original source paths remain in the project. The duplicate dashboard and its sample metrics have been removed. Overview contains Web search and Activity with live progress and run details. Solo Mode contains profile editing, recording, and manual backup creation. Starter templates open in Custom Workflows. Scheduler is under Sessions, and archive verification, restoration, and automatic backups are under Backup.

## Feature status

| Reference feature | Included behavior |
| --- | --- |
| Overview / Activity | Actual execution-history metrics, activity calendar, 7-day/30-day/all filters, streaks and peak hour. Activity now always renders the five reference-style summary cards (Swarmers, Warmers, Sessions, Workflows, Pods), plus recent executions and refresh. |
| Sessions | Create/edit/delete, pod/workflow/proxy binding, review before run, per-device minimum/maximum controls and bounded concurrent waves (sequential when blank), owner-controlled concurrent-session capacity (no fixed cap by default), same-profile exclusion, Stop, state retained across navigation, temporary/incognito profiles and proxy restoration. |
| Pod builder | Four device-category sliders and numeric counts, create/append named groups without the former 50-profile batch cap, rename/ungroup, group existing profiles, real browser-profile creation, progress and cancellation. Categories are labels; they do not create physical mobile devices or change fingerprints. |
| Solo Mode | Active/inactive filtering, pod/device/search filters, selection, tags, notes, last-used date, profile power controls and deletion through the existing native worker. Default location detects and displays the device timezone; Chromium inherits the host timezone. Proxy routing retains the assigned profile proxy. |
| Proxies | Original complete manual/bulk import, saved proxies, assignments, export and Windows-encrypted password handling retained; styled within the new shell. |
| Machines / Earn Mode | Local capability registration and machine record. No paid-job network, remote rental, wallet, traffic sales or earnings are connected. |
| Warmers | 24 installable Google/YouTube learning templates. They navigate, wait and capture a screenshot for inspection. No automated watching, engagement, account warming or fake traffic. |
| Swarmers | Generate site inspection routes or build guided browser steps from plain-language goals. Select and save journeys as one editable workflow. |
| Custom | Persistent canvas with multiple task journeys, URLs, editable action nodes, add/duplicate/remove/reorder, zoom, compile/save and JSON export. Each journey compiles in visible order into one workflow. |
| AI builder / agent | OpenAI, Anthropic, Google Gemini, OpenRouter, DeepSeek, Grok and local Ollama planning, plus the existing execution engine. Encrypted saved keys, per-provider model discovery, reference presets, custom model IDs, assistant-to-planner task handoff and session planner preferences. Planning creates a draft for review; saved sessions execute the reviewed steps. |
| Store | Search local saved workflows, publish portable JSON files and import via the existing editor. A shared online marketplace is not connected. |
| Provider Keys | All six cloud text-provider cards, local Ollama and all four voice options are visible. Windows DPAPI key save/delete and encrypted saved-key planning work through the native bridge. Each text card can refresh and display its model catalogue. ElevenLabs, Fish and API voice adapters remain configuration only; native system speech has a working test button. |
| Backup | Original native backup/restore/verification and automatic backups retained; workspace-definition export added. No cloud backup subscription/server is supplied. |
| Handover | Export/import workflows, empty groups and linked session definitions as separate copies; secrets and browser cookies excluded. Reassign local profiles after import. No remote buyer/trade verification. |
| Access / license screen | Reference-style educational access dialog. No payment collection or license server. |
| Vision mode | Workflows support screenshots. The QA workspace Vision Lab uses local YOLO inference on a bundled sample grid. Live browser security challenges require manual verification. |
| Around-the-clock runs | Existing daily/weekly/one-time Scheduler remains connected to the native worker. This is distinct from continuous session execution. |
| Theme / assistant / mobile | Persistent dark/light setting, collapsible navigation, narrow-screen drawer and task handoff to the planner. |

## Run on Windows

Use the same Node.js, Rust, Visual Studio C++ Build Tools and WebView2 setup as the existing project. Node 24 is used by the included tests; the existing Vite 8 setup requires a modern Node version.

Extract this ZIP into a separate project folder first. Do not overwrite or delete your live `browser-worker/profiles`, profile locks, screenshots, workflow/history files or app-data folder. Compare the source with your live project before applying it. The package retains the uploaded workflow/history files unchanged; avoid copying those data files over newer live data.

```powershell
npm.cmd ci
npx.cmd playwright install chromium
npm.cmd run build
npm.cmd run tauri dev
```

To build the Windows desktop installer:

```powershell
npm.cmd run tauri build
```

The existing Tauri configuration uses `pnpm` for its before-dev/build hooks. If it is not already installed, use your normal pnpm setup, or change those two hooks to `npm run dev` and `npm run build`. Do not disable PowerShell security settings; the `.cmd` commands work without changing execution policy.

Browser preview only:

```powershell
npm.cmd run dev
```

Open the localhost URL printed by Vite. Browser mode saves editable drafts locally and clearly reports that execution, native backups, credentials and OS scheduling need the desktop application. Preview data is separate from desktop data; use workflow JSON files to move draft definitions.

## Persistence and compatibility

- Same Tauri identifier (`com.ajbot.studio`), worker protocol and native browser-data locations.
- New UI metadata uses `ajbot-studio-*` local storage keys. Browser-preview mock definitions use a separate `ajbot-preview-*` namespace.
- Provider credentials are stored in `provider-keys.json` beside existing native proxy data, as DPAPI-encrypted values encoded in hex. They are tied to the Windows user; do not copy them as a portable handover. No plaintext credential fallback is used on other operating systems.
- Original backup archives retain their original protection. Workspace exports are plain JSON and contain definitions only, without API keys or browser cookies.
- Incognito sessions create fresh temporary profiles rather than copying logged-in profile state. Failed cleanup is reported. If the process is terminated mid-run, review leftover temporary profiles in Browser profiles.
- Session execution is moved onto a native background task so Stop and UI events can be processed while the worker is running.
- Native run results now expose success/status/error as well as their original message and steps, so a failed run cannot be shown as successful merely because its results list was empty.
- Native worker lowercase actions are normalized in portable workflow exports/imports.

## Verification completed here

- `npm run build`: passed (TypeScript + Vite production bundle).
- `npm test`: 20 workflow/model/capacity/provider/worker-protocol checks passed.
- `npm run test:ui`: passed in headless Chromium. Covers profile groups, tags/search, learning templates, multi-journey compilation, session persistence, all reference screens, all original tools, a 60-profile batch, saved optional capacity limits and narrow-screen document width.
- `npm run test:sessions`: passed through a mocked Tauri boundary. Covers actual React session command order, Stop, navigation during a run, profile exclusion, proxy restoration, temporary-profile cleanup, preservation of the approval gate, the API-key/local-storage boundary, four simultaneous sessions, live capacity changes and batch cancellation checkpoints.
- `node --check browser-worker/worker.cjs` and `node --check browser-worker/planner-providers.cjs`: passed. The worker retains its original browser/recording/approval engine and now delegates additional provider requests to the new companion module.
- Desktop and mobile screenshots were inspected internally during layout verification.

The Rust/Windows executable and real Windows DPAPI operations have **not** been compiled or executed in this Linux environment (no Rust/Windows build toolchain). A Windows native build and acceptance test remain necessary. Mocked boundary tests do not prove Windows integration or the behavior of external websites/providers.

The test scripts accept `AJBOT_TEST_BROWSER` as an optional Chromium executable path. On a normal development machine, install the Playwright browser and omit it.

## Suggested Windows acceptance check

1. Launch with your current profile data, open Original tools → Browser profiles, and confirm the existing profiles remain.
2. Create a small test pod, save a website-inspection workflow, and run it as a session.
3. Navigate away and back during the run, then Stop it.
4. Run a temporary-profile session and confirm the original profile data remains and the temporary profile disappears afterward.
5. Verify a session proxy is restored after a normal run and a failed run.
6. Save an OpenAI key in Provider Keys and generate a draft with an empty key field in the planner. Review the generated actions.
7. Exercise original recording, backup/restore, scheduling and run-history tools on test data.

This package contains updated source and a built browser frontend; it is not a signed Windows executable or installer.

## Capacity update — no paid upgrade restrictions

The previous fixed three-session gate and 50-profile creation-batch gate are removed. Both controls are now owned by the workspace user in **Settings → Workspace capacity**:

| Setting | Default | Effect |
| --- | --- | --- |
| Concurrent sessions | `0` | No fixed application cap. Set a positive whole number to bound new session starts. Changing it does not stop active sessions. |
| Profiles per batch | `0` | No fixed application cap. Set a positive whole number to limit each new creation batch. Existing profiles are unaffected. |

Numeric profile-count inputs support values above the sliders' display range. Creation stays sequential. Each successfully created profile is checkpointed into its Pod, so cancelling or leaving the Pod page retains completed work. Cancel stops after the in-flight profile finishes. Pod order and existing assignments remain unchanged.

There is no paid upgrade required to change these settings. CPU, RAM, disk space and external provider quotas still determine practical capacity. The existing workflow schema's 50-step limit, bounded waits, validation and approval gates are technical execution controls and remain in place. Cloud wallets, paid jobs and remote marketplace services remain unconnected. Text AI adapters are implemented in the later video refinement below.

Verified: a 60-profile batch appended to an existing two-profile Pod, a chosen two-session limit rejected a third start, changing that setting to `0` allowed four concurrent sessions, and cancelling a blocked batch retained its first completed profile and group association. Session execution tests use a mocked Tauri boundary; Windows native compilation remains unverified here.

## Windows compile correction

Fixed Rust E0308 in `write_provider_key_store`: the final `fs::rename` error now explicitly returns an owned `String` using `.to_string()`. Other literal-error mappings use `?` for error conversion. No frontend, profile data, capacity setting or browser-worker behavior changed. The native Windows build must be rerun to verify compilation.

## Second-video refinements

- **Activity:** The tab displays all five summary cards even when there are no executions. Counts come from saved workspace data; recent executions remain below. Date filters apply to known creation/update timestamps, with undated legacy items counted under All.
- **Session devices:** The modal includes iPhone, Android, Mac and Windows minimum/maximum active fields. Blank fields preserve sequential execution. A category maximum of zero excludes that category. Minimum validates the initial number of available profiles; maximum bounds each category in concurrent, finite execution waves. As a finite run drains, active counts can fall below the startup minimum. This is not a continuous traffic or account-warming loop. Stop addresses every active profile in the session. Ranges persist and are included in handover definitions.
- **Default timezone:** Solo Mode starts at Default location and obtains the timezone from this device using `Intl.DateTimeFormat`. It updates when the window regains focus or its periodic timezone check runs. Existing profile proxy assignments remain available. A timezone setting does not change the network exit IP.
- **Providers/models:** The reference has six cloud text providers and multiple models under each provider. Those six plus local Ollama now appear in the session and advanced-planner selectors. The key page displays all text and voice cards, preset counts and expandable model lists. Refresh retrieves the provider catalogue using the native worker and saved credentials; custom model IDs remain editable. Reference presets may be unavailable or renamed at the provider, so use Refresh or a valid account-specific model ID. Live model access and quotas depend on that provider account.
- **Actual adapters:** Added Anthropic Messages, Gemini generateContent, and compatible OpenRouter/DeepSeek/xAI chat-planning adapters. The existing OpenAI and Ollama calls remain intact. Model discovery supports all seven text providers, including pagination for Anthropic/Gemini. New API requests use fixed provider endpoints, bounded timeouts and no redirect credential forwarding. API errors redact the supplied key.
- **Testing:** Unit/request tests use mocked HTTP. A spawned copy of the actual worker handles model discovery and validated OpenRouter planning over its normal JSON protocol, with mocked HTTP and no external provider calls. UI tests check the empty and populated Activity panels, timezone `Africa/Accra`, all 11 provider/voice cards, saved ranges and model selections. Native-boundary tests check two Windows-labelled profiles running together while excluded categories do not run, Stop across active profiles, invalid minima, model refresh and non-OpenAI planner routing.

To apply this version, update the complete source in a separate project folder and keep live profile/data folders. In particular, keep **both** `browser-worker/worker.cjs` and its new `browser-worker/planner-providers.cjs` companion together. The native `src-tauri/src/lib.rs` update is also required for provider model discovery and saved-key support. The prior `.to_string()` Rust return-type correction and the complete closing function brace are included.

Windows native compilation, real DPAPI encryption and live credential-backed provider calls still require acceptance testing on Windows. Voice API synthesis, live autonomous vision control and cloud service features retain their previously documented limitations.

### Provider implementation references

- Anthropic: https://platform.claude.com/docs/en/api/overview and https://platform.claude.com/docs/en/api/models/list
- Gemini: https://ai.google.dev/api/generate-content and https://ai.google.dev/api/models
- OpenRouter: https://openrouter.ai/docs/api/api-reference/chat/create-a-chat-completion and https://openrouter.ai/docs/api/api-reference/models/list-all-models-and-their-properties
- DeepSeek: https://api-docs.deepseek.com/ and https://api-docs.deepseek.com/api/list-models/
- xAI: https://docs.x.ai/developers/rest-api-reference/inference/chat-completions
- OpenAI model discovery: https://developers.openai.com/api/reference/resources/models/methods/list

The complete Rust source also passed a Rust grammar parse with no syntax errors or missing delimiters. This does not replace Rust type checking or a Windows build.

## Warmers, Swarmers, Custom and engine follow-up (2026-11-08)

Reviewed the supplied second video again at its Warmers Store/My Warmers, Swarmers generation, Custom canvas and Earn Mode transitions. This update brings those layouts and local controls closer to the recording. It is **not feature-identical** to the recorded service: the recording's artificial browsing-history/traffic behaviour, cloud reviewing, paid jobs and payouts are not reproduced.

- **Warmers:** Store and My Warmers tabs, installed count, Google/YouTube/Facebook/Instagram/TikTok/Amazon filters, search, duplicate-safe installation, open in Custom and confirmed removal. The 72 topic/platform entries install editable **inspection drafts** pointed at example.com; set an authorized target before running. They extract page text/links and take a screenshot. They do not mimic people, create account histories or generate social/video engagement. Existing installed topic workflows remain recognizable.
- **Swarmers.** The desktop app checks the target, its same-origin page links and up to three nested sitemaps. It probes up to 48 candidate URLs within 15 seconds and keeps up to 24 verified HTML pages. A journey opens the target or an inner page, visits other verified pages, then lists links and captures a screenshot. Single-page sites get a three-task inspection. Preview cards show the saved order and the selection's step count. Saved journey boundaries are stored with the native workflow, and the runner checks the page URL, HTTP status and HTML content type during execution. Browser mode creates a single-page draft from the supplied URL. The existing 50-step limit applies to each saved swarm.
- **Guided journeys.** In Swarmers, choose Build from goals and enter up to five goals, one per line. The desktop browser inspects the target and up to five other verified pages in a fresh context. The selected AI model receives the goals and observed page controls. Review the action list, select journeys and save them as one swarm. Open the swarm in Custom or select it in Sessions. Searches use a search field on the target site. A result can be clicked by an exact link name supplied in the goal. Unresolved goals show a reason beside the preview.
- **Custom:** Reference-style toolbar, task-project tabs, journey settings, duplicate/remove, small connected nodes, node side editor, zoom/fit/minimap, Add step dialog and searchable Custom Workflows drawer with Load/Delete. Type & Enter compiles to the actual native fill and Enter actions. Build with AI uses the selected provider to place a reviewed draft directly on the canvas. AI Type/Type & Enter/Click Object/Analyze Page launch selector-based AI step drafting, not live vision control. Run AI Agent saves the selected canvas and loads that exact workflow into the original runner for profile selection, review and consequential-action approval. Advanced editor and JSON export remain reachable. New saves include journey names and boundaries in the native definition. Older grouped workflows also use this device's local editor library. Custom JSON exports include journeys. Workflows edited elsewhere fall back to their native step definition when loaded.
- **Earn Mode:** Country starts empty with an editable suggested two-letter placeholder. Windows uses the operating system's region when available; browser fallback uses a timezone-to-country table or an explicitly regional locale. This is a device-region hint, not verified physical geolocation, and ambiguous settings can require manual entry. Registration, Change/Cancel, Pause/Resume, local refresh, pod/capability selection, export consent, local application preparation/export/withdrawal and Machines status work. New applications retain a snapshot of the selected definitions. There is no automatic reviewer access to profiles. Applications are labelled Prepared locally, remote approval stages remain inactive, and no earnings are invented. A separately authenticated, authorized testing-service backend is required for actual approvals, jobs and payouts.
- **Provider Keys / engine:** Engine tools shortcut and separate Verify Engine / Repair Engine controls. Verification checks Node.js, Playwright, worker companions, Chromium's binary and an actual headless launch/page check. Repair invokes the installed Playwright CLI through Node to install Chromium, then repeats verification. It does not delete profiles, reinstall the app, disable security software or alter PowerShell policy. Missing packages, install/network errors and launch failures are shown in the engine panel. Browser preview reports that native operations require the desktop app. Node.js 20+ and installed project dependencies are prerequisites. Repair has a five-minute download timeout.
- **Navigation:** Original AJBOT SVG icons for all 22 destinations, each with a distinct glyph and branded node accent. Collapsed navigation retains these icons, accessible names and tooltips. Fixed the compact navigation drawer reopening after switching to a mobile-width window.

### Applying and checking this source

Keep your existing profile, workflow, run-history, encrypted-key and backup data. Unzip into a separate folder first, then copy the updated source files into your project without replacing your live data files with the sample `browser-worker/workflows.json` or `run-history.json` from the archive. Keep all browser-worker companion scripts together. This source checkout is the supported development/runtime layout; these changes do not add a self-contained Node/worker bundle to a Windows installer.

From the project root on Windows:

```powershell
pnpm install
pnpm build
pnpm tauri dev
```

In Provider Keys, choose **Engine tools**, then **Verify Engine**. If Chromium is missing, choose **Repair Engine** and verify again. Command-line equivalents are `pnpm engine:verify` and `pnpm engine:repair` (they print structured diagnostic JSON). Native command changes require restarting `tauri dev`.

Validation: 26 automated unit/request/engine/discovery checks; real headless Chromium launch through the new verification helper; browser UI tests covering library/platform tabs, installation, canvas editing and grouped reload, country placeholder, registration/change/pause/resume/application persistence, engine preview errors, all original screens and mobile compact drawer; mocked Tauri tests covering engine verify/repair dispatch, AI canvas drafts and runner handoff, site-discovery journeys and native workflow loading, plus existing sessions/proxy/Stop/credential boundaries. Production TypeScript/Vite build and Rust grammar parsing pass. The repair download success path, Windows Rust type checking/linking, Windows region/DPAPI operations and live provider credentials still require testing on the target Windows installation.


## Live AI Agent correction (2026-11-08)

The preceding version's **Run AI Agent** button opened the saved-workflow runner. That was not the behaviour shown in the recording. Reviewed the video again around 5:35–6:30, including the actual Run AI Agent (live) dialog and the navigation-context error visible at the end of that demonstration.

- **Run AI Agent (live)** now has the demonstrated Goal, Start URL, Max steps (default 12), Provider and Model controls. Its starting URL defaults to Google as in the video, and can be changed to an authorized test site. All seven configured text-provider adapters remain available. Auto/default resolves to the selected provider's default preset; an actual available model and saved API key (or local Ollama) are required.
- It opens a new, visible Chromium browser with a fresh, temporary context, reads main-document text and interactive elements, requests **one next action**, executes it, and observes again. It does not save a static workflow before launching or open the legacy runner. Existing profiles/cookies are not reused or modified. The context/browser close when the run finishes, fails or stops.
- Added action progress, activity trace, Stop, per-action review, private local run summaries and a persistent status button when the dialog is hidden. Navigation between AJBOT pages does not unmount the controller. Stale progress/approval events cannot revive a completed run. Hiding the dialog keeps it running; Stop closes its browser. During initial browser launch, Stop takes effect as soon as launch returns, before navigation.
- Same-origin, non-destructive observed links can be followed automatically. Data entry, button activation and external navigation require explicit approval of that individual action. Approval IDs are tied to the pending action, and the target's URL/identity fields are checked again before execution. Cross-origin document navigation is blocked unless its origin was approved. Model output cannot execute JavaScript or arbitrary selectors/URLs. A page snapshot excludes input values, and no password values or API keys are sent as page context. Visible page text/labels are sent to the chosen provider; use authorized test sites.
- Security challenges and password fields pause for manual handling in the browser. Downloads are disabled in this live-agent implementation; it reports a manual-handling limitation instead of downloading or executing files. It does not provide human impersonation, artificial engagement, security-challenge solving, iframe/vision-driven control, or unattended consequential transactions.
- Navigation can destroy a page's JavaScript execution context. Observation waits for DOM readiness and retries that transient error with a fresh DOM. Failure still produces a visible error; completion is not fabricated. Completion means the model reported the goal finished; the user can inspect the trace. Exhausting the user-selected decision limit (1–50) is reported separately, and a ten-minute deadline also bounds a run.
- **Build with AI** still creates an editable canvas draft. The old reviewed runner remains available as **Run saved workflow**, and the advanced editor remains available. No original tool was removed.
- Engine verification now also checks the new `live-agent.cjs` companion. Keep it beside `worker.cjs` and `planner-providers.cjs`. Restart `tauri dev` after updating the native source.
- Corrected Activity's Warmer count to include all six library platforms.

Validation includes real headless Chromium interactions against a local HTTP fixture with controlled AI decisions: navigation and re-observation, approval/decline, stale approvals, changed targets, Stop during an unresolved model request, step exhaustion, manual password/challenge handling and error/key redaction. A subprocess running the actual JSON-line worker also launches the browser agent and processes Stop while AI is pending. UI tests exercise the video-style form, native command dispatch, approval, hide/reopen across navigation, Stop, stale-event rejection, numeric validation and private-input persistence boundaries. Existing session and screen checks remain in the suite. Real provider responses, native Windows compilation/linking and visible-browser acceptance on Windows remain unverified in this environment.

Final validation for this correction: 39 automated checks pass, plus the browser UI suite, session/native-boundary suite and dedicated live-agent UI suite. Stop also aborts the live provider HTTP request through its cancellation signal. Production build and Rust grammar/native-call argument checks pass; this is not a Windows Rust type/link check.

### Pod controls and workflow limits

Use **Pods → Manage Pods → Configure** to attach a saved workflow and a saved proxy. Run pod opens the existing session review. Start, pause, resume and stop apply to the group. Cloning creates fresh profile directories and copies the device choices and pod bindings. Pod schedules keep a snapshot of the members and selected workflow and proxy IDs, run members in sequence while AJBOT is open, and appear in Scheduler. Update the schedule in Pods after changing its membership. Solo Mode uses the selected pod’s proxy when configured.

New profiles store the device preset in their local metadata. The preset controls viewport, screen, device scale and touch in Chromium. Use Repeat this step in Custom or the advanced editor to set 1–10 executions. Expanded runs are capped at 100 actions, including their branches.
