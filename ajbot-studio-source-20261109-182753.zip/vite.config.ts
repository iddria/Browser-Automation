import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    watch: {
      ignored: [
        "**/browser-worker/profiles/**",
        "**/browser-worker/workflows.json",
        "**/node_modules/**",
        "**/src-tauri/target/**",
      ],
    },
  },
});